const express = require('express');
const cors = require('cors');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const path = require('path');
const { initDatabase, query, run, saveDatabase } = require('./database');

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'odyssey-secret-key-change-in-production';

// Middleware
app.use(cors());
app.use(express.json({ limit: '10mb' })); // Increased limit for map image uploads
app.use(express.static('public'));

// Initialize database
let dbReady = false;
initDatabase().then(() => {
  dbReady = true;
  console.log('✅ Database initialized');
}).catch(err => {
  console.error('❌ Database initialization failed:', err);
  process.exit(1);
});

// Middleware to check if database is ready
function requireDbReady(req, res, next) {
  if (!dbReady) {
    return res.status(503).json({ error: 'Server is starting up, please wait...' });
  }
  next();
}

// Apply database check to all API routes
app.use('/api', requireDbReady);

// Auth middleware
function authenticateToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'No token provided' });
  }

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({ error: 'Invalid token' });
    }
    req.user = user;
    next();
  });
}

// ====================
// ACHIEVEMENT TRACKING HELPERS
// ====================

// Ensure student has an achievement progress record
function ensureAchievementProgress(student_id) {
  const existing = query('SELECT * FROM student_achievement_progress WHERE student_id = ?', [student_id]);
  if (existing.length === 0) {
    run('INSERT INTO student_achievement_progress (student_id) VALUES (?)', [student_id]);
  }
}

// Update achievement progress when a submission is approved
function updateAchievementProgress(student_id, category, points_earned, max_points) {
  ensureAchievementProgress(student_id);
  
  const progress = query('SELECT * FROM student_achievement_progress WHERE student_id = ?', [student_id])[0];
  
  if (category === 'quiz' && max_points) {
    // Update quiz tracking
    const newQuizCount = progress.quiz_count + 1;
    const newQuizEarned = progress.quiz_total_earned + points_earned;
    const newQuizPossible = progress.quiz_total_possible + max_points;
    
    run(`UPDATE student_achievement_progress 
         SET quiz_count = ?, quiz_total_earned = ?, quiz_total_possible = ?
         WHERE student_id = ?`,
        [newQuizCount, newQuizEarned, newQuizPossible, student_id]);
    
    // Check for Coeus unlock (8+ quizzes with 80%+ average)
    if (newQuizCount >= 8 && !progress.coeus_unlocked) {
      const avgPercent = (newQuizEarned / newQuizPossible) * 100;
      if (avgPercent >= 80) {
        run(`UPDATE student_achievement_progress 
             SET coeus_unlocked = 1, coeus_unlocked_at = CURRENT_TIMESTAMP
             WHERE student_id = ?`, [student_id]);
        console.log(`🏆 Student ${student_id} unlocked Curiosity of Coeus!`);
      }
    }
  } else if ((category === 'myth_comp_conn' || category === 'comp_conn') && max_points) {
    // Update comp conn tracking
    const newCompCount = progress.comp_conn_count + 1;
    const newCompEarned = progress.comp_conn_total_earned + points_earned;
    const newCompPossible = progress.comp_conn_total_possible + max_points;
    
    run(`UPDATE student_achievement_progress 
         SET comp_conn_count = ?, comp_conn_total_earned = ?, comp_conn_total_possible = ?
         WHERE student_id = ?`,
        [newCompCount, newCompEarned, newCompPossible, student_id]);
    
    // Check for Metis unlock (8+ comp conns with 80%+ average)
    if (newCompCount >= 8 && !progress.metis_unlocked) {
      const avgPercent = (newCompEarned / newCompPossible) * 100;
      if (avgPercent >= 80) {
        run(`UPDATE student_achievement_progress 
             SET metis_unlocked = 1, metis_unlocked_at = CURRENT_TIMESTAMP
             WHERE student_id = ?`, [student_id]);
        console.log(`🏆 Student ${student_id} unlocked Mind of Metis!`);
      }
    }
  } else if (category === 'mural') {
    // Update mural count
    const newMuralCount = progress.mural_count + 1;
    
    run(`UPDATE student_achievement_progress SET mural_count = ? WHERE student_id = ?`,
        [newMuralCount, student_id]);
    
    // Check for Apollo unlock (5+ murals)
    if (newMuralCount >= 5 && !progress.apollo_unlocked) {
      run(`UPDATE student_achievement_progress 
           SET apollo_unlocked = 1, apollo_unlocked_at = CURRENT_TIMESTAMP
           WHERE student_id = ?`, [student_id]);
      console.log(`🏆 Student ${student_id} unlocked Apollo's Blessing!`);
    }
  } else if (category === 'video') {
    // Update video count
    const newVideoCount = progress.video_count + 1;
    
    run(`UPDATE student_achievement_progress SET video_count = ? WHERE student_id = ?`,
        [newVideoCount, student_id]);
    
    // Check for Delphi unlock (3+ videos)
    if (newVideoCount >= 3 && !progress.delphi_unlocked) {
      run(`UPDATE student_achievement_progress 
           SET delphi_unlocked = 1, delphi_unlocked_at = CURRENT_TIMESTAMP
           WHERE student_id = ?`, [student_id]);
      console.log(`🏆 Student ${student_id} unlocked Oracle of Delphi!`);
    }
  }
}

// Update achievement progress for RESUBMISSIONS (adjust totals without incrementing count)
function updateAchievementProgressForResubmission(student_id, category, points_diff, max_points_diff) {
  ensureAchievementProgress(student_id);
  
  const progress = query('SELECT * FROM student_achievement_progress WHERE student_id = ?', [student_id])[0];
  
  if (category === 'quiz' && max_points_diff !== undefined) {
    // Adjust quiz totals (don't increment count)
    const newQuizEarned = progress.quiz_total_earned + points_diff;
    const newQuizPossible = progress.quiz_total_possible + max_points_diff;
    
    run(`UPDATE student_achievement_progress 
         SET quiz_total_earned = ?, quiz_total_possible = ?
         WHERE student_id = ?`,
        [newQuizEarned, newQuizPossible, student_id]);
    
    console.log(`Resubmission: Adjusted quiz totals by ${points_diff}/${max_points_diff}`);
    
    // Recheck for Coeus unlock
    if (progress.quiz_count >= 8 && !progress.coeus_unlocked) {
      const avgPercent = (newQuizEarned / newQuizPossible) * 100;
      if (avgPercent >= 80) {
        run(`UPDATE student_achievement_progress 
             SET coeus_unlocked = 1, coeus_unlocked_at = CURRENT_TIMESTAMP
             WHERE student_id = ?`, [student_id]);
        console.log(`🏆 Student ${student_id} unlocked Curiosity of Coeus!`);
      }
    }
  } else if ((category === 'myth_comp_conn' || category === 'comp_conn') && max_points_diff !== undefined) {
    // Adjust comp conn totals (don't increment count)
    const newCompEarned = progress.comp_conn_total_earned + points_diff;
    const newCompPossible = progress.comp_conn_total_possible + max_points_diff;
    
    run(`UPDATE student_achievement_progress 
         SET comp_conn_total_earned = ?, comp_conn_total_possible = ?
         WHERE student_id = ?`,
        [newCompEarned, newCompPossible, student_id]);
    
    console.log(`Resubmission: Adjusted comp_conn totals by ${points_diff}/${max_points_diff}`);
    
    // Recheck for Metis unlock
    if (progress.comp_conn_count >= 8 && !progress.metis_unlocked) {
      const avgPercent = (newCompEarned / newCompPossible) * 100;
      if (avgPercent >= 80) {
        run(`UPDATE student_achievement_progress 
             SET metis_unlocked = 1, metis_unlocked_at = CURRENT_TIMESTAMP
             WHERE student_id = ?`, [student_id]);
        console.log(`🏆 Student ${student_id} unlocked Mind of Metis!`);
      }
    }
  }
  // Note: Murals and videos don't typically have resubmissions that change points
}

// Get achievement bonus multiplier for a category
function getAchievementBonus(student_id, category) {
  const progress = query('SELECT * FROM student_achievement_progress WHERE student_id = ?', [student_id])[0];
  if (!progress) return 0;
  
  let bonus = 0;
  
  if (category === 'quiz' && progress.coeus_unlocked) {
    bonus = 0.10; // +10% for quizzes
  } else if ((category === 'myth_comp_conn' || category === 'comp_conn') && progress.metis_unlocked) {
    bonus = 0.15; // +15% for comp conns
  } else if (category === 'mural' && progress.apollo_unlocked) {
    bonus = 0.33; // +33% for murals
  } else if (category === 'video' && progress.delphi_unlocked) {
    bonus = 0.33; // +33% for videos
  }
  
  return bonus;
}

// ====================
// AUTH ROUTES
// ====================

// Teacher Registration
app.post('/api/auth/teacher/register', async (req, res) => {
  try {
    const { name, email, password } = req.body;
    
    // Check if teacher exists
    const existing = query('SELECT * FROM teachers WHERE email = ?', [email]);
    if (existing.length > 0) {
      return res.status(400).json({ error: 'Teacher already exists' });
    }

    // Hash password
    const password_hash = await bcrypt.hash(password, 10);
    
    // Insert teacher
    run('INSERT INTO teachers (name, email, password_hash) VALUES (?, ?, ?)', 
        [name, email, password_hash]);
    
    const teacher = query('SELECT teacher_id, name, email FROM teachers WHERE email = ?', [email])[0];
    
    // Generate token
    const token = jwt.sign({ id: teacher.teacher_id, type: 'teacher' }, JWT_SECRET);
    
    res.json({ token, teacher });
  } catch (err) {
    console.error('Registration error:', err);
    res.status(500).json({ error: 'Registration failed' });
  }
});

// Teacher Login
app.post('/api/auth/teacher/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    
    const teachers = query('SELECT * FROM teachers WHERE email = ?', [email]);
    if (teachers.length === 0) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }
    
    const teacher = teachers[0];
    const validPassword = await bcrypt.compare(password, teacher.password_hash);
    
    if (!validPassword) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }
    
    const token = jwt.sign({ id: teacher.teacher_id, type: 'teacher' }, JWT_SECRET);
    
    res.json({ 
      token, 
      teacher: { 
        teacher_id: teacher.teacher_id, 
        name: teacher.name, 
        email: teacher.email 
      } 
    });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ error: 'Login failed' });
  }
});

// Student Registration
app.post('/api/auth/student/register', async (req, res) => {
  try {
    const { name, email, password, class_period } = req.body;
    
    const existing = query('SELECT * FROM students WHERE email = ?', [email]);
    if (existing.length > 0) {
      return res.status(400).json({ error: 'Student already exists' });
    }

    const password_hash = await bcrypt.hash(password, 10);
    
    run('INSERT INTO students (name, email, password_hash, class_period) VALUES (?, ?, ?, ?)', 
        [name, email, password_hash, class_period || null]);
    
    const student = query('SELECT student_id, name, email, class_period FROM students WHERE email = ?', [email])[0];
    
    const token = jwt.sign({ id: student.student_id, type: 'student' }, JWT_SECRET);
    
    res.json({ token, student });
  } catch (err) {
    console.error('Registration error:', err);
    res.status(500).json({ error: 'Registration failed' });
  }
});

// Student Login
app.post('/api/auth/student/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    
    const students = query('SELECT * FROM students WHERE email = ?', [email]);
    if (students.length === 0) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }
    
    const student = students[0];
    const validPassword = await bcrypt.compare(password, student.password_hash);
    
    if (!validPassword) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }
    
    const token = jwt.sign({ id: student.student_id, type: 'student' }, JWT_SECRET);
    
    res.json({ 
      token, 
      student: { 
        student_id: student.student_id, 
        name: student.name, 
        email: student.email,
        alliance_id: student.alliance_id
      } 
    });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ error: 'Login failed' });
  }
});

// ====================
// TEACHER ROUTES
// ====================

// Get Leaderboard
app.get('/api/teacher/leaderboard', authenticateToken, (req, res) => {
  try {
    const { class_period } = req.query; // Optional filter
    
    let whereClause = 'WHERE a.is_disbanded = 0';
    let params = [];
    
    if (class_period) {
      whereClause += ' AND a.class_period = ?';
      params.push(class_period);
    }
    
    const alliances = query(`
      SELECT 
        a.alliance_id,
        a.alliance_name,
        a.class_period,
        a.total_points,
        a.current_age,
        a.buildings_owned,
        a.underdog_blessing,
        COUNT(s.student_id) as member_count
      FROM alliances a
      LEFT JOIN students s ON a.alliance_id = s.alliance_id
      ${whereClause}
      GROUP BY a.alliance_id
      ORDER BY a.class_period, a.total_points DESC
    `, params);
    
    // Parse JSON fields and get member names
    alliances.forEach(alliance => {
      alliance.buildings_owned = JSON.parse(alliance.buildings_owned || '[]');
      
      // Get member names for this alliance
      const members = query(`
        SELECT name FROM students WHERE alliance_id = ? ORDER BY name
      `, [alliance.alliance_id]);
      
      alliance.member_names = members.map(m => m.name);
    });
    
    res.json(alliances);
  } catch (err) {
    console.error('Leaderboard error:', err);
    res.status(500).json({ error: 'Failed to fetch leaderboard' });
  }
});

// Award Points
app.post('/api/teacher/award-points', authenticateToken, (req, res) => {
  try {
    const { alliance_id, student_id, amount, max_points, category, reason } = req.body;
    const teacher_id = req.user.id;
    
    if (!alliance_id) {
      return res.status(400).json({ error: 'alliance_id required' });
    }
    
    // Start with base amount
    let finalAmount = amount;
    let techMultiplier = 1.0;
    let buildingBonus = 0;
    let achievementBonus = 0;
    
    // Only apply bonuses to positive point awards
    if (amount > 0) {
      // Track achievement progress if student specified
      if (student_id && category) {
        updateAchievementProgress(student_id, category, amount, max_points || null);
      }
      
      // Calculate technology bonuses if student specified
      if (student_id) {
        const student = query('SELECT technologies_unlocked FROM students WHERE student_id = ?', [student_id])[0];
        if (student) {
          const techs = JSON.parse(student.technologies_unlocked || '[]');
          if (techs.length > 0) {
            const techDetails = query(`SELECT bonus_value, specific_assignment_type FROM technologies_ref WHERE tech_name IN (${techs.map(() => '?').join(',')})`, techs);
            
            techDetails.forEach(tech => {
              // Apply bonus if it's general or matches the category
              if (!tech.specific_assignment_type || tech.specific_assignment_type === category) {
                techMultiplier *= (1 + tech.bonus_value);
              }
            });
          }
        }
        
        // Get achievement power-up bonus
        achievementBonus = getAchievementBonus(student_id, category);
      }
      
      // Calculate building activation bonuses
      buildingBonus = getAllianceBuildingBonus(alliance_id);
      
      // Apply all bonuses: (base * tech multiplier) * (1 + building bonus) * (1 + achievement bonus)
      finalAmount = Math.round(amount * techMultiplier * (1 + buildingBonus) * (1 + achievementBonus));
    }
    
    // Add points to alliance
    run('UPDATE alliances SET total_points = total_points + ? WHERE alliance_id = ?', 
        [finalAmount, alliance_id]);
    
    // Log transaction - use null for undefined student_id
    run(`INSERT INTO point_transactions (alliance_id, student_id, amount, category, reason, teacher_id) 
         VALUES (?, ?, ?, ?, ?, ?)`, 
        [alliance_id, student_id || null, finalAmount, category || 'general', reason || 'Points awarded', teacher_id]);
    
    // Get updated alliance
    const alliance = query('SELECT * FROM alliances WHERE alliance_id = ?', [alliance_id])[0];
    
    // Build bonus breakdown for response
    const bonusBreakdown = {
      base_amount: amount,
      tech_multiplier: Math.round((techMultiplier - 1) * 100),
      building_bonus: Math.round(buildingBonus * 100),
      achievement_bonus: Math.round(achievementBonus * 100),
      final_amount: finalAmount
    };
    
    res.json({ 
      success: true, 
      finalAmount,
      bonusBreakdown,
      alliance
    });
  } catch (err) {
    console.error('Award points error:', err);
    res.status(500).json({ error: 'Failed to award points' });
  }
});

// Deduct Points
app.post('/api/teacher/deduct-points', authenticateToken, (req, res) => {
  try {
    const { alliance_id, amount, reason } = req.body;
    const teacher_id = req.user.id;
    
    run('UPDATE alliances SET total_points = total_points - ? WHERE alliance_id = ?', 
        [amount, alliance_id]);
    
    run(`INSERT INTO point_transactions (alliance_id, amount, category, reason, teacher_id) 
         VALUES (?, ?, ?, ?, ?)`, 
        [alliance_id, -amount, 'deduction', reason, teacher_id]);
    
    const alliance = query('SELECT * FROM alliances WHERE alliance_id = ?', [alliance_id])[0];
    
    res.json({ success: true, alliance });
  } catch (err) {
    console.error('Deduct points error:', err);
    res.status(500).json({ error: 'Failed to deduct points' });
  }
});

// Get Recent Transactions
app.get('/api/teacher/transactions', authenticateToken, (req, res) => {
  try {
    const limit = req.query.limit || 20;
    const transactions = query(`
      SELECT 
        t.*,
        a.alliance_name,
        s.name as student_name
      FROM point_transactions t
      LEFT JOIN alliances a ON t.alliance_id = a.alliance_id
      LEFT JOIN students s ON t.student_id = s.student_id
      ORDER BY t.timestamp DESC
      LIMIT ?
    `, [limit]);
    
    res.json(transactions);
  } catch (err) {
    console.error('Transactions error:', err);
    res.status(500).json({ error: 'Failed to fetch transactions' });
  }
});

// Get Alliance Details
app.get('/api/teacher/alliance/:id', authenticateToken, (req, res) => {
  try {
    const alliance_id = req.params.id;
    
    const alliance = query('SELECT * FROM alliances WHERE alliance_id = ?', [alliance_id])[0];
    if (!alliance) {
      return res.status(404).json({ error: 'Alliance not found' });
    }
    
    const members = query('SELECT student_id, name, technologies_unlocked FROM students WHERE alliance_id = ?', [alliance_id]);
    
    alliance.buildings_owned = JSON.parse(alliance.buildings_owned || '[]');
    members.forEach(m => {
      m.technologies_unlocked = JSON.parse(m.technologies_unlocked || '[]');
    });
    
    res.json({ alliance, members });
  } catch (err) {
    console.error('Alliance details error:', err);
    res.status(500).json({ error: 'Failed to fetch alliance details' });
  }
});

// Get All Alliances for Teacher Management
app.get('/api/teacher/alliances', authenticateToken, (req, res) => {
  try {
    const alliances = query(`
      SELECT 
        a.alliance_id,
        a.alliance_name,
        a.class_period,
        a.total_points,
        a.buildings_owned,
        a.is_disbanded,
        a.created_at,
        COUNT(s.student_id) as member_count,
        GROUP_CONCAT(s.name, ', ') as member_names
      FROM alliances a
      LEFT JOIN students s ON a.alliance_id = s.alliance_id
      WHERE a.is_disbanded = 0
      GROUP BY a.alliance_id
      ORDER BY a.class_period, a.total_points DESC
    `);
    
    res.json(alliances);
  } catch (err) {
    console.error('Get alliances error:', err);
    res.status(500).json({ error: 'Failed to fetch alliances' });
  }
});

// Disband Alliance (Teacher only)
app.post('/api/teacher/disband-alliance', authenticateToken, (req, res) => {
  try {
    const { alliance_id } = req.body;
    
    // Get alliance info before disbanding
    const alliance = query('SELECT * FROM alliances WHERE alliance_id = ?', [alliance_id])[0];
    if (!alliance) {
      return res.status(404).json({ error: 'Alliance not found' });
    }
    
    // Calculate building values to sell back
    const ownedBuildings = JSON.parse(alliance.buildings_owned || '[]');
    let buildingRefundTotal = 0;
    
    // Get building prices for refund calculation
    const buildingPrices = query('SELECT building_name, cost_points FROM buildings_ref');
    const priceMap = {};
    buildingPrices.forEach(b => { priceMap[b.building_name] = b.cost_points; });
    
    // Refund all buildings at full cost
    ownedBuildings.forEach(buildingName => {
      buildingRefundTotal += priceMap[buildingName] || 0;
    });
    
    // Total points to distribute = current points + building refunds
    const totalToDistribute = alliance.total_points + buildingRefundTotal;
    
    // Get all members
    const members = query(`
      SELECT 
        s.student_id,
        s.name,
        COALESCE(SUM(CASE WHEN pt.amount > 0 THEN pt.amount ELSE 0 END), 0) as points_contributed
      FROM students s
      LEFT JOIN point_transactions pt ON s.student_id = pt.student_id AND pt.alliance_id = ?
      WHERE s.alliance_id = ?
      GROUP BY s.student_id
    `, [alliance_id, alliance_id]);
    
    const memberCount = members.length;
    const pointsPerMember = memberCount > 0 ? Math.floor(totalToDistribute / memberCount) : 0;
    
    // Save each member's contributions and give them their share
    members.forEach(member => {
      // Record their contribution history
      run(`INSERT INTO student_contributions (student_id, alliance_id, points_contributed, buildings_contributed)
           VALUES (?, ?, ?, ?)`,
          [member.student_id, alliance_id, member.points_contributed, alliance.buildings_owned]);
      
      // Remove from alliance (make them free agents)
      run('UPDATE students SET alliance_id = NULL WHERE student_id = ?', [member.student_id]);
      
      // Delete their building placements (buildings are gone)
      run('DELETE FROM building_placements WHERE student_id = ?', [member.student_id]);
    });
    
    // Mark alliance as disbanded (don't delete, keep for history)
    run('UPDATE alliances SET is_disbanded = 1, total_points = 0, buildings_owned = ? WHERE alliance_id = ?', 
        [JSON.stringify([]), alliance_id]);
    
    // Cancel any pending invitations
    run("UPDATE alliance_invitations SET status = 'cancelled' WHERE alliance_id = ? AND status = 'pending'", [alliance_id]);
    
    // Delete god assignments for this alliance
    run('DELETE FROM god_assignments WHERE alliance_id = ?', [alliance_id]);
    
    // Delete building activations for this alliance
    run('DELETE FROM building_activations WHERE alliance_id = ?', [alliance_id]);
    
    res.json({ 
      success: true, 
      message: `Alliance "${alliance.alliance_name}" disbanded. Buildings sold for ${buildingRefundTotal} points. ${pointsPerMember} points returned to each of ${memberCount} members.`,
      freedMembers: members.map(m => m.name),
      pointsPerMember,
      buildingRefund: buildingRefundTotal
    });
  } catch (err) {
    console.error('Disband alliance error:', err);
    res.status(500).json({ error: 'Failed to disband alliance' });
  }
});

// Get Student's Contribution History (for carrying over to new alliance)
app.get('/api/student/contribution-history', authenticateToken, (req, res) => {
  try {
    const student_id = req.user.id;
    
    const contributions = query(`
      SELECT 
        sc.*,
        a.alliance_name
      FROM student_contributions sc
      JOIN alliances a ON sc.alliance_id = a.alliance_id
      WHERE sc.student_id = ?
      ORDER BY sc.contribution_date DESC
    `, [student_id]);
    
    // Calculate totals
    const totalPoints = contributions.reduce((sum, c) => sum + c.points_contributed, 0);
    
    res.json({ contributions, totalPoints });
  } catch (err) {
    console.error('Get contribution history error:', err);
    res.status(500).json({ error: 'Failed to fetch contribution history' });
  }
});

// Get All Students (for point awarding)
app.get('/api/teacher/students', authenticateToken, (req, res) => {
  try {
    const students = query(`
      SELECT 
        s.student_id,
        s.name,
        s.class_period,
        s.alliance_id,
        a.alliance_name
      FROM students s
      LEFT JOIN alliances a ON s.alliance_id = a.alliance_id
      ORDER BY s.class_period, a.alliance_name, s.name
    `);
    
    res.json(students);
  } catch (err) {
    console.error('Students error:', err);
    res.status(500).json({ error: 'Failed to fetch students' });
  }
});

// Get Pending Point Submissions
app.get('/api/teacher/pending-submissions', authenticateToken, (req, res) => {
  try {
    const submissions = query(`
      SELECT 
        ps.*,
        s.name as student_name,
        a.alliance_name
      FROM point_submissions ps
      JOIN students s ON ps.student_id = s.student_id
      JOIN alliances a ON ps.alliance_id = a.alliance_id
      WHERE ps.status = 'pending'
      ORDER BY ps.submitted_at ASC
    `);
    
    res.json(submissions);
  } catch (err) {
    console.error('Pending submissions error:', err);
    res.status(500).json({ error: 'Failed to fetch pending submissions' });
  }
});

// Approve/Reject Point Submission
app.post('/api/teacher/review-submission', authenticateToken, (req, res) => {
  try {
    const { submission_id, approve, teacher_notes } = req.body;
    const teacher_id = req.user.id;
    
    // Get submission
    const submission = query('SELECT * FROM point_submissions WHERE submission_id = ?', [submission_id])[0];
    
    if (!submission) {
      return res.status(404).json({ error: 'Submission not found' });
    }
    
    if (submission.status !== 'pending') {
      return res.status(400).json({ error: 'Submission already reviewed' });
    }
    
    if (approve) {
      // Check if this is a resubmission (grade record already exists)
      let isResubmission = false;
      let previousPoints = 0;
      let previousMaxPoints = 0;
      
      if (submission.myth_god && submission.section) {
        const assignment = query(`
          SELECT assignment_id FROM assignments_ref 
          WHERE section = ? AND myth_god = ? AND assignment_type = ?
        `, [submission.section, submission.myth_god, submission.category])[0];
        
        if (assignment) {
          const existingRecord = query(`
            SELECT points_earned, points_possible FROM grade_records 
            WHERE student_id = ? AND assignment_id = ?
          `, [submission.student_id, assignment.assignment_id])[0];
          
          if (existingRecord) {
            isResubmission = true;
            previousPoints = existingRecord.points_earned;
            previousMaxPoints = existingRecord.points_possible;
            console.log(`Resubmission detected - previous score: ${previousPoints}/${previousMaxPoints}`);
          }
        }
      }
      
      // Update achievement tracking (handle resubmissions by passing difference)
      if (isResubmission) {
        // For resubmissions, update with the DIFFERENCE in points
        const pointsDiff = submission.points_claimed - previousPoints;
        const maxPointsDiff = (submission.max_points || submission.points_claimed) - previousMaxPoints;
        // Don't increment count for resubmissions, just adjust totals
        updateAchievementProgressForResubmission(submission.student_id, submission.category, pointsDiff, maxPointsDiff);
      } else {
        // New submission - add full points and increment count
        updateAchievementProgress(submission.student_id, submission.category, submission.points_claimed, submission.max_points);
      }
      
      // Approve - add points to alliance with technology, building, AND achievement bonuses
      const student = query('SELECT technologies_unlocked FROM students WHERE student_id = ?', [submission.student_id])[0];
      
      let techMultiplier = 1.0;
      
      // Apply technology bonuses
      if (student) {
        const techs = JSON.parse(student.technologies_unlocked || '[]');
        if (techs.length > 0) {
          const techDetails = query(`SELECT bonus_value, specific_assignment_type FROM technologies_ref WHERE tech_name IN (${techs.map(() => '?').join(',')})`, techs);
          
          techDetails.forEach(tech => {
            if (!tech.specific_assignment_type || tech.specific_assignment_type === submission.category) {
              techMultiplier *= (1 + tech.bonus_value);
            }
          });
        }
      }
      
      // Apply building bonuses
      const buildingBonus = getAllianceBuildingBonus(submission.alliance_id);
      
      // Apply achievement power-up bonuses
      const achievementBonus = getAchievementBonus(submission.student_id, submission.category);
      
      // Apply Handaxe bonus (+5% points earned) if alliance has it
      const allianceTechs = query(
        'SELECT tech_name FROM alliance_technologies WHERE alliance_id = ?',
        [submission.alliance_id]
      ).map(t => t.tech_name);
      const hasHandaxe = allianceTechs.includes('Handaxe');
      const handaxeBonus = hasHandaxe ? 0.05 : 0;
      
      // Calculate final: base * tech * (1 + building) * (1 + achievement) * (1 + handaxe)
      // For resubmissions, only award the DIFFERENCE in points
      let baseAmount = submission.points_claimed;
      if (isResubmission) {
        baseAmount = submission.points_claimed - previousPoints; // Only the improvement
        console.log(`Resubmission: Awarding difference of ${baseAmount} points (${submission.points_claimed} - ${previousPoints})`);
      }
      
      // Only add points if there's a positive difference (or it's not a resubmission)
      let finalAmount = 0;
      if (baseAmount > 0) {
        finalAmount = Math.round(baseAmount * techMultiplier * (1 + buildingBonus) * (1 + achievementBonus) * (1 + handaxeBonus));
        
        // Add points to alliance
        run('UPDATE alliances SET total_points = total_points + ? WHERE alliance_id = ?', 
            [finalAmount, submission.alliance_id]);
        
        // Log transaction with god name and assignment type
        const godName = submission.myth_god || '';
        const assignmentType = submission.category === 'comp_conn' ? 'Reading Notes' : 
                               submission.category === 'quiz' ? 'Quiz' :
                               submission.category === 'mural' ? 'Mural' :
                               submission.category === 'video' ? 'Video' :
                               submission.category;
        const assignmentName = godName ? `${godName} ${assignmentType}` : assignmentType;
        
        run(`INSERT INTO point_transactions (alliance_id, student_id, amount, category, reason, teacher_id) 
             VALUES (?, ?, ?, ?, ?, ?)`, 
            [submission.alliance_id, submission.student_id, finalAmount, submission.category, 
             assignmentName, teacher_id]);
      } else if (isResubmission && baseAmount < 0) {
        // Score went down - log but don't subtract points (be nice to students!)
        console.log(`Resubmission: Score decreased from ${previousPoints} to ${submission.points_claimed} - not subtracting points`);
      }
      
      // Create grade record if myth_god and section are provided
      if (submission.myth_god && submission.section) {
        console.log('Creating grade record for:', {
          section: submission.section,
          myth_god: submission.myth_god,
          category: submission.category
        });
        
        // Find the matching assignment
        const assignment = query(`
          SELECT assignment_id, display_name FROM assignments_ref 
          WHERE section = ? AND myth_god = ? AND assignment_type = ?
        `, [submission.section, submission.myth_god, submission.category])[0];
        
        console.log('Found assignment:', assignment);
        
        if (assignment) {
          // Check if record already exists (update) or needs to be created
          const existingRecord = query(`
            SELECT record_id FROM grade_records 
            WHERE student_id = ? AND assignment_id = ?
          `, [submission.student_id, assignment.assignment_id])[0];
          
          if (existingRecord) {
            // Update existing record (allow resubmission/improvement)
            run(`UPDATE grade_records 
                 SET points_earned = ?, points_possible = ?, submission_id = ?, completed_at = CURRENT_TIMESTAMP
                 WHERE record_id = ?`,
                [submission.points_claimed, submission.max_points || submission.points_claimed, submission_id, existingRecord.record_id]);
            console.log('Updated existing grade record');
          } else {
            // Create new grade record
            run(`INSERT INTO grade_records (student_id, assignment_id, points_earned, points_possible, submission_id)
                 VALUES (?, ?, ?, ?, ?)`,
                [submission.student_id, assignment.assignment_id, submission.points_claimed, submission.max_points || submission.points_claimed, submission_id]);
            console.log('Created new grade record for:', assignment.display_name);
          }
        } else {
          console.log('WARNING: No matching assignment found for submission');
        }
      } else {
        console.log('Skipping grade record - no myth_god or section:', {
          myth_god: submission.myth_god,
          section: submission.section
        });
      }
      
      // Check if this is a Rite of Passage submission - mark alliance as complete
      if (submission.category === 'rite_of_passage') {
        run('UPDATE alliances SET rite_of_passage_complete = 1 WHERE alliance_id = ?', 
            [submission.alliance_id]);
      }
      
      // Update submission status
      run(`UPDATE point_submissions 
           SET status = 'approved', reviewed_at = CURRENT_TIMESTAMP, 
               reviewed_by_teacher_id = ?, teacher_notes = ?
           WHERE submission_id = ?`, 
          [teacher_id, teacher_notes || '', submission_id]);
      
      // Build message with bonus info
      let bonusInfo = '';
      if (buildingBonus > 0) bonusInfo += ` +${Math.round(buildingBonus * 100)}% building`;
      if (achievementBonus > 0) bonusInfo += ` +${Math.round(achievementBonus * 100)}% power-up`;
      if (handaxeBonus > 0) bonusInfo += ` +5% Handaxe`;
      if (bonusInfo) bonusInfo = ` (includes${bonusInfo})`;
      
      // Add Rite of Passage completion note
      let riteNote = '';
      if (submission.category === 'rite_of_passage') {
        riteNote = ' (Alliance Rite of Passage requirement fulfilled!)';
      }
      
      res.json({ success: true, message: `Approved! ${finalAmount} points awarded${bonusInfo}.${riteNote}`, finalAmount });
    } else {
      // Reject
      run(`UPDATE point_submissions 
           SET status = 'rejected', reviewed_at = CURRENT_TIMESTAMP, 
               reviewed_by_teacher_id = ?, teacher_notes = ?
           WHERE submission_id = ?`, 
          [teacher_id, teacher_notes || '', submission_id]);
      
      res.json({ success: true, message: 'Submission rejected' });
    }
  } catch (err) {
    console.error('Review submission error:', err);
    res.status(500).json({ error: 'Failed to review submission' });
  }
});

// ====================
// STUDENT ROUTES
// ====================

// Get Student Dashboard Data
app.get('/api/student/dashboard', authenticateToken, (req, res) => {
  try {
    const student_id = req.user.id;
    
    // Get student info
    const student = query(`
      SELECT 
        s.*,
        a.alliance_name,
        a.total_points as alliance_points,
        a.current_age,
        a.buildings_owned,
        a.reverse_cards
      FROM students s
      LEFT JOIN alliances a ON s.alliance_id = a.alliance_id
      WHERE s.student_id = ?
    `, [student_id])[0];
    
    if (!student) {
      return res.status(404).json({ error: 'Student not found' });
    }
    
    // Parse JSON fields
    student.technologies_unlocked = JSON.parse(student.technologies_unlocked || '[]');
    student.badges_earned = JSON.parse(student.badges_earned || '[]');
    student.buildings_owned = JSON.parse(student.buildings_owned || '[]');
    
    // Get alliance members
    let members = [];
    if (student.alliance_id) {
      members = query(`
        SELECT student_id, name, technologies_unlocked
        FROM students
        WHERE alliance_id = ?
      `, [student.alliance_id]);
      
      members.forEach(m => {
        m.technologies_unlocked = JSON.parse(m.technologies_unlocked || '[]');
      });
    }
    
    // Get leaderboard
    const leaderboard = query(`
      SELECT 
        alliance_id,
        alliance_name,
        total_points,
        current_age
      FROM alliances
      ORDER BY total_points DESC
    `);
    
    // Add technologies to each alliance
    const leaderboardWithTechs = leaderboard.map(alliance => {
      const techs = query(
        'SELECT tech_name FROM alliance_technologies WHERE alliance_id = ?',
        [alliance.alliance_id]
      ).map(t => t.tech_name);
      return { ...alliance, technologies: techs };
    });
    
    res.json({
      student,
      members,
      leaderboard: leaderboardWithTechs
    });
  } catch (err) {
    console.error('Dashboard error:', err);
    res.status(500).json({ error: 'Failed to fetch dashboard' });
  }
});

// Get Buildings Reference
app.get('/api/buildings', (req, res) => {
  try {
    const buildings = query('SELECT * FROM buildings_ref ORDER BY cost_points');
    res.json(buildings);
  } catch (err) {
    console.error('Buildings error:', err);
    res.status(500).json({ error: 'Failed to fetch buildings' });
  }
});

// ====================
// STUDENT POINT SUBMISSION
// ====================

// Submit Points for Approval
app.post('/api/student/submit-points', authenticateToken, (req, res) => {
  try {
    const { points_claimed, max_points, category, myth_god, section, description } = req.body;
    const student_id = req.user.id;
    
    // Get student's alliance
    const student = query('SELECT alliance_id FROM students WHERE student_id = ?', [student_id])[0];
    
    if (!student || !student.alliance_id) {
      return res.status(400).json({ error: 'You must be in an alliance to submit points' });
    }
    
    // Create submission with max_points, myth_god, and section
    run(`INSERT INTO point_submissions (student_id, alliance_id, points_claimed, max_points, category, myth_god, section, description, status) 
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending')`, 
        [student_id, student.alliance_id, points_claimed, max_points || null, category, myth_god || null, section || null, description]);
    
    res.json({ success: true, message: 'Points submitted for teacher approval!' });
  } catch (err) {
    console.error('Submit points error:', err);
    res.status(500).json({ error: 'Failed to submit points' });
  }
});

// Get Student's Pending Submissions
app.get('/api/student/my-submissions', authenticateToken, (req, res) => {
  try {
    const student_id = req.user.id;
    
    const submissions = query(`
      SELECT * FROM point_submissions 
      WHERE student_id = ? 
      ORDER BY submitted_at DESC
      LIMIT 20
    `, [student_id]);
    
    res.json(submissions);
  } catch (err) {
    console.error('Get submissions error:', err);
    res.status(500).json({ error: 'Failed to fetch submissions' });
  }
});

// Get Student's Alliance Info
app.get('/api/student/alliance', authenticateToken, (req, res) => {
  try {
    const student_id = req.user.id;
    
    const student = query('SELECT alliance_id FROM students WHERE student_id = ?', [student_id])[0];
    if (!student || !student.alliance_id) {
      return res.json({ alliance: null });
    }
    
    const alliance = query('SELECT * FROM alliances WHERE alliance_id = ?', [student.alliance_id])[0];
    
    res.json({ alliance });
  } catch (err) {
    console.error('Get alliance error:', err);
    res.status(500).json({ error: 'Failed to fetch alliance' });
  }
});

// Get Student Achievement Progress
app.get('/api/student/achievements', authenticateToken, (req, res) => {
  try {
    const student_id = req.user.id;
    
    ensureAchievementProgress(student_id);
    
    const progress = query('SELECT * FROM student_achievement_progress WHERE student_id = ?', [student_id])[0];
    
    // Calculate percentages
    const quizAvg = progress.quiz_total_possible > 0 
      ? Math.round((progress.quiz_total_earned / progress.quiz_total_possible) * 100) 
      : 0;
    const compConnAvg = progress.comp_conn_total_possible > 0 
      ? Math.round((progress.comp_conn_total_earned / progress.comp_conn_total_possible) * 100) 
      : 0;
    
    res.json({
      // Curiosity of Coeus (Quiz mastery)
      coeus: {
        name: 'Curiosity of Coeus',
        description: 'The Titan of Curiosity rewards those who seek knowledge',
        requirement: 'Score 80%+ average on 8 quizzes',
        effect: '+10% on future quiz points',
        unlocked: progress.coeus_unlocked === 1,
        unlocked_at: progress.coeus_unlocked_at,
        progress: {
          count: progress.quiz_count,
          needed: 8,
          average: quizAvg,
          threshold: 80
        }
      },
      // Mind of Metis (Comp Conn mastery)
      metis: {
        name: 'Mind of Metis',
        description: "Athena's mother blesses those with wisdom in writing",
        requirement: 'Score 80%+ average on 8 comprehension connections',
        effect: '+15% on future comp conn points',
        unlocked: progress.metis_unlocked === 1,
        unlocked_at: progress.metis_unlocked_at,
        progress: {
          count: progress.comp_conn_count,
          needed: 8,
          average: compConnAvg,
          threshold: 80
        }
      },
      // Apollo's Blessing (Mural mastery)
      apollo: {
        name: "Apollo's Blessing",
        description: 'The god of art rewards dedicated creators',
        requirement: 'Create 5 murals or comics',
        effect: '+33% on future mural/comic points',
        unlocked: progress.apollo_unlocked === 1,
        unlocked_at: progress.apollo_unlocked_at,
        progress: {
          count: progress.mural_count,
          needed: 5
        }
      },
      // Oracle of Delphi (Video mastery)
      delphi: {
        name: 'Oracle of Delphi',
        description: "Apollo's oracle speaks through visual storytelling",
        requirement: 'Create 3 videos',
        effect: '+33% on future video points',
        unlocked: progress.delphi_unlocked === 1,
        unlocked_at: progress.delphi_unlocked_at,
        progress: {
          count: progress.video_count,
          needed: 3
        }
      }
    });
  } catch (err) {
    console.error('Get achievements error:', err);
    res.status(500).json({ error: 'Failed to fetch achievements' });
  }
});

// ====================
// PANTHEON UNLOCK SYSTEM
// ====================

// Helper function to get quiz + notes score for a god
function getGodScore(student_id, godName, quizGod = null) {
  // quizGod is used when the quiz is shared (e.g., Apollo and Artemis share a quiz)
  const quizGodName = quizGod || godName;
  
  const quiz = query(`
    SELECT gr.points_earned 
    FROM grade_records gr
    JOIN assignments_ref ar ON gr.assignment_id = ar.assignment_id
    WHERE gr.student_id = ? AND ar.myth_god = ? AND ar.assignment_type = 'quiz'
  `, [student_id, quizGodName])[0];
  
  const notes = query(`
    SELECT gr.points_earned 
    FROM grade_records gr
    JOIN assignments_ref ar ON gr.assignment_id = ar.assignment_id
    WHERE gr.student_id = ? AND ar.myth_god = ? AND ar.assignment_type = 'comp_conn'
  `, [student_id, godName])[0];
  
  return {
    quizScore: quiz ? quiz.points_earned : 0,
    notesScore: notes ? notes.points_earned : 0,
    total: (quiz ? quiz.points_earned : 0) + (notes ? notes.points_earned : 0)
  };
}

// Helper function to check if bonus is complete
function isBonusComplete(student_id, godName) {
  const bonus = query(`
    SELECT gr.points_earned 
    FROM grade_records gr
    JOIN assignments_ref ar ON gr.assignment_id = ar.assignment_id
    WHERE gr.student_id = ? AND ar.myth_god = ? AND ar.section = 'bonus'
  `, [student_id, godName])[0];
  
  return bonus && bonus.points_earned > 0;
}

// Get student's pantheon unlock status
app.get('/api/student/pantheon', authenticateToken, (req, res) => {
  try {
    const student_id = req.user.id;
    
    // Get student name for logging
    const student = query('SELECT name FROM students WHERE student_id = ?', [student_id])[0];
    const studentName = student ? student.name : `Student ${student_id}`;
    
    ensureAchievementProgress(student_id);
    let progress = query('SELECT * FROM student_achievement_progress WHERE student_id = ?', [student_id])[0];
    
    // Define all gods with their unlock requirements
    const godConfigs = [
      { name: 'zeus', emoji: '⚡', threshold: 13, maxScore: 15, quizMax: 5, notesMax: 10 },
      { name: 'poseidon', emoji: '🔱', threshold: 13, maxScore: 15, quizMax: 5, notesMax: 10 },
      { name: 'prometheus', emoji: '🔥', threshold: 17, maxScore: 20, quizMax: 10, notesMax: 10 },
      { name: 'apollo', emoji: '☀️', threshold: 13, maxScore: 15, quizMax: 5, notesMax: 10, quizGod: 'Apollo and Artemis' },
      { name: 'artemis', emoji: '🏹', threshold: 13, maxScore: 15, quizMax: 5, notesMax: 10, quizGod: 'Apollo and Artemis' },
      { name: 'athena', emoji: '🦉', threshold: 13, maxScore: 15, quizMax: 5, notesMax: 10 },
      { name: 'hera', emoji: '🦚', threshold: 13, maxScore: 15, quizMax: 5, notesMax: 10 },
      { name: 'aphrodite', emoji: '💕', threshold: 13, maxScore: 15, quizMax: 5, notesMax: 10 },
      { name: 'demeter', emoji: '🌾', threshold: 13, maxScore: 15, quizMax: 5, notesMax: 10 },
      { name: 'hermes', emoji: '🪽', threshold: 13, maxScore: 15, quizMax: 5, notesMax: 10 },
      { name: 'hephaestus', emoji: '🔨', threshold: 13, maxScore: 15, quizMax: 5, notesMax: 10 },
      { name: 'hades', emoji: '💀', isBonus: true },
      { name: 'ares', emoji: '⚔️', isBonus: true }
    ];
    
    const pantheon = {};
    const newUnlocks = [];
    
    for (const god of godConfigs) {
      const godNameCap = god.name.charAt(0).toUpperCase() + god.name.slice(1);
      const colUnlocked = `pantheon_${god.name}_unlocked`;
      const colUnlockedAt = `pantheon_${god.name}_unlocked_at`;
      const colSeen = `pantheon_${god.name}_celebration_seen`;
      
      let qualifies = false;
      let scoreInfo = {};
      
      if (god.isBonus) {
        // Bonus-based unlock (Hades, Ares)
        qualifies = isBonusComplete(student_id, godNameCap);
        scoreInfo = {
          requirement: `Complete ${godNameCap} Bonus assignment`,
          current_score: qualifies ? 'Bonus Complete ✓' : 'Bonus not complete'
        };
      } else {
        // Quiz + Notes based unlock
        const quizGod = god.quizGod || godNameCap;
        const scores = getGodScore(student_id, godNameCap, quizGod);
        qualifies = scores.total >= god.threshold;
        scoreInfo = {
          requirement: `Combined ${god.threshold}+ on quiz and reading notes`,
          current_score: `${scores.total}/${god.maxScore} (Quiz: ${scores.quizScore}/${god.quizMax}, Notes: ${scores.notesScore}/${god.notesMax})`
        };
      }
      
      // Check if should unlock
      if (qualifies && !progress[colUnlocked]) {
        run(`UPDATE student_achievement_progress 
             SET ${colUnlocked} = 1, ${colUnlockedAt} = CURRENT_TIMESTAMP
             WHERE student_id = ?`, [student_id]);
        console.log(`${god.emoji} ${studentName} unlocked ${godNameCap} in the Pantheon!`);
        // Refresh progress
        progress = query('SELECT * FROM student_achievement_progress WHERE student_id = ?', [student_id])[0];
      }
      
      const colBonusSeen = `pantheon_${god.name}_bonus_seen`;
      
      pantheon[god.name] = {
        unlocked: progress[colUnlocked] === 1,
        unlocked_at: progress[colUnlockedAt],
        celebration_seen: progress[colSeen] === 1,
        bonus_complete: god.isBonus ? qualifies : isBonusComplete(student_id, godNameCap),
        bonus_celebration_seen: progress[colBonusSeen] === 1,
        ...scoreInfo
      };
      
      // Add to newUnlocks if unlocked but not celebrated
      if (pantheon[god.name].unlocked && !pantheon[god.name].celebration_seen) {
        newUnlocks.push(god.name);
      }
    }
    
    // Build array of NEW bonus completions to celebrate
    // For Hades/Ares, bonus_complete triggers both unlock AND bonus celebration together
    const newBonuses = [];
    for (const god of godConfigs) {
      const godData = pantheon[god.name];
      // Only add to newBonuses if:
      // 1. God is unlocked AND celebration was seen (so they've already unlocked)
      // 2. Bonus is complete
      // 3. Bonus celebration hasn't been seen yet
      // OR for Hades/Ares: they unlock via bonus, so bonus celebration happens with unlock
      if (god.isBonus) {
        // Hades/Ares: bonus celebration triggers with unlock celebration
        // So we don't add them to newBonuses separately
      } else {
        if (godData.unlocked && godData.celebration_seen && godData.bonus_complete && !godData.bonus_celebration_seen) {
          newBonuses.push(god.name);
        }
      }
    }
    
    res.json({ pantheon, newUnlocks, newBonuses });
  } catch (err) {
    console.error('Get pantheon error:', err);
    res.status(500).json({ error: 'Failed to fetch pantheon status' });
  }
});

// Mark celebration as seen
app.post('/api/student/pantheon/celebration-seen', authenticateToken, (req, res) => {
  try {
    const student_id = req.user.id;
    const { god } = req.body;
    
    const validGods = ['zeus', 'hera', 'poseidon', 'athena', 'apollo', 'artemis', 'aphrodite', 'ares', 'hephaestus', 'hermes', 'demeter', 'prometheus', 'hades'];
    if (!validGods.includes(god)) {
      return res.status(400).json({ error: 'Invalid god name' });
    }
    
    run(`UPDATE student_achievement_progress 
         SET pantheon_${god}_celebration_seen = 1
         WHERE student_id = ?`, [student_id]);
    
    // For Hades and Ares, also mark bonus as seen since they unlock via bonus
    if (god === 'hades' || god === 'ares') {
      run(`UPDATE student_achievement_progress 
           SET pantheon_${god}_bonus_seen = 1
           WHERE student_id = ?`, [student_id]);
    }
    
    saveDatabase();
    
    res.json({ success: true, message: `${god} celebration marked as seen` });
  } catch (err) {
    console.error('Mark celebration seen error:', err);
    res.status(500).json({ error: 'Failed to mark celebration' });
  }
});

// Mark bonus celebration as seen
app.post('/api/student/pantheon/bonus-seen', authenticateToken, (req, res) => {
  try {
    const student_id = req.user.id;
    const { god } = req.body;
    
    const validGods = ['zeus', 'hera', 'poseidon', 'athena', 'apollo', 'artemis', 'aphrodite', 'ares', 'hephaestus', 'hermes', 'demeter', 'prometheus', 'hades'];
    if (!validGods.includes(god)) {
      return res.status(400).json({ error: 'Invalid god name' });
    }
    
    run(`UPDATE student_achievement_progress 
         SET pantheon_${god}_bonus_seen = 1
         WHERE student_id = ?`, [student_id]);
    
    saveDatabase();
    
    res.json({ success: true, message: `${god} bonus celebration marked as seen` });
  } catch (err) {
    console.error('Mark bonus celebration seen error:', err);
    res.status(500).json({ error: 'Failed to mark bonus celebration' });
  }
});

// ====================
// GRADE TRACKING SYSTEM
// ====================

// Get all assignments (for dropdowns)
app.get('/api/assignments', authenticateToken, (req, res) => {
  try {
    const assignments = query(`
      SELECT * FROM assignments_ref 
      WHERE age = 'Archaic'
      ORDER BY section, assignment_type, myth_god
    `);
    
    res.json(assignments);
  } catch (err) {
    console.error('Get assignments error:', err);
    res.status(500).json({ error: 'Failed to fetch assignments' });
  }
});

// Get assignments by section and type (for filtered dropdowns)
app.get('/api/assignments/filter', authenticateToken, (req, res) => {
  try {
    const { section, assignment_type } = req.query;
    
    let sql = 'SELECT * FROM assignments_ref WHERE age = ?';
    let params = ['Archaic'];
    
    if (section) {
      sql += ' AND section = ?';
      params.push(section);
    }
    
    if (assignment_type) {
      sql += ' AND assignment_type = ?';
      params.push(assignment_type);
    }
    
    sql += ' ORDER BY myth_god';
    
    const assignments = query(sql, params);
    res.json(assignments);
  } catch (err) {
    console.error('Filter assignments error:', err);
    res.status(500).json({ error: 'Failed to filter assignments' });
  }
});

// Get student's grade summary
app.get('/api/student/grades', authenticateToken, (req, res) => {
  try {
    const student_id = req.user.id;
    
    // Get all assignments
    const allAssignments = query(`
      SELECT * FROM assignments_ref WHERE age = 'Archaic'
    `);
    
    // Get student's completed assignments
    const completedRecords = query(`
      SELECT gr.*, ar.section, ar.assignment_type, ar.myth_god, ar.display_name, ar.max_points as assignment_max, ar.is_bonus
      FROM grade_records gr
      JOIN assignments_ref ar ON gr.assignment_id = ar.assignment_id
      WHERE gr.student_id = ?
    `, [student_id]);
    
    // Calculate totals by section
    const section1Assignments = allAssignments.filter(a => a.section === 'section_1');
    const section2Assignments = allAssignments.filter(a => a.section === 'section_2');
    const bonusAssignments = allAssignments.filter(a => a.section === 'bonus');
    
    const section1Completed = completedRecords.filter(r => r.section === 'section_1');
    const section2Completed = completedRecords.filter(r => r.section === 'section_2');
    const bonusCompleted = completedRecords.filter(r => r.section === 'bonus');
    
    // Calculate earned points
    const section1Earned = section1Completed.reduce((sum, r) => sum + r.points_earned, 0);
    const section2Earned = section2Completed.reduce((sum, r) => sum + r.points_earned, 0);
    const bonusEarned = bonusCompleted.reduce((sum, r) => sum + r.points_earned, 0);
    
    // Calculate max points
    const section1Max = section1Assignments.reduce((sum, a) => sum + a.max_points, 0);
    const section2Max = section2Assignments.reduce((sum, a) => sum + a.max_points, 0);
    const bonusMax = bonusAssignments.reduce((sum, a) => sum + a.max_points, 0);
    
    // Find missing assignments (not completed)
    const completedAssignmentIds = new Set(completedRecords.map(r => r.assignment_id));
    
    const section1Missing = section1Assignments
      .filter(a => !completedAssignmentIds.has(a.assignment_id))
      .map(a => ({ display_name: a.display_name, max_points: a.max_points, myth_god: a.myth_god, assignment_type: a.assignment_type }));
    
    const section2Missing = section2Assignments
      .filter(a => !completedAssignmentIds.has(a.assignment_id))
      .map(a => ({ display_name: a.display_name, max_points: a.max_points, myth_god: a.myth_god, assignment_type: a.assignment_type }));
    
    res.json({
      section1: {
        earned: section1Earned,
        max: section1Max,
        percentage: section1Max > 0 ? Math.round((section1Earned / section1Max) * 100) : 0,
        completed: section1Completed.map(r => ({
          display_name: r.display_name,
          myth_god: r.myth_god,
          points_earned: r.points_earned,
          points_possible: r.points_possible,
          assignment_type: r.assignment_type
        })),
        missing: section1Missing
      },
      section2: {
        earned: section2Earned,
        max: section2Max,
        percentage: section2Max > 0 ? Math.round((section2Earned / section2Max) * 100) : 0,
        completed: section2Completed.map(r => ({
          display_name: r.display_name,
          myth_god: r.myth_god,
          points_earned: r.points_earned,
          points_possible: r.points_possible,
          assignment_type: r.assignment_type
        })),
        missing: section2Missing
      },
      bonus: {
        earned: bonusEarned,
        max: bonusMax,
        percentage: bonusMax > 0 ? Math.round((bonusEarned / bonusMax) * 100) : 0,
        completed: bonusCompleted.map(r => ({
          display_name: r.display_name,
          myth_god: r.myth_god,
          points_earned: r.points_earned,
          points_possible: r.points_possible
        }))
      }
    });
  } catch (err) {
    console.error('Get grades error:', err);
    res.status(500).json({ error: 'Failed to fetch grades' });
  }
});

// Get bonus assignments with full details (for portal)
app.get('/api/student/bonus-assignments', authenticateToken, (req, res) => {
  try {
    const student_id = req.user.id;
    
    // Get all bonus assignments
    const bonusAssignments = query(`
      SELECT * FROM assignments_ref 
      WHERE section = 'bonus' AND age = 'Archaic'
      ORDER BY myth_god
    `);
    
    // Get student's completed bonus records
    const completedRecords = query(`
      SELECT gr.*, ar.myth_god
      FROM grade_records gr
      JOIN assignments_ref ar ON gr.assignment_id = ar.assignment_id
      WHERE gr.student_id = ? AND ar.section = 'bonus'
    `, [student_id]);
    
    // Get pending submissions for bonus work
    const pendingSubmissions = query(`
      SELECT myth_god FROM point_submissions
      WHERE student_id = ? AND section = 'bonus' AND status = 'pending'
    `, [student_id]);
    
    const completedGods = new Set(completedRecords.map(r => r.myth_god));
    const pendingGods = new Set(pendingSubmissions.map(s => s.myth_god));
    
    // Add status to each assignment
    const assignmentsWithStatus = bonusAssignments.map(a => {
      let status = 'not_started';
      let points_earned = null;
      
      if (completedGods.has(a.myth_god)) {
        status = 'completed';
        const record = completedRecords.find(r => r.myth_god === a.myth_god);
        points_earned = record ? record.points_earned : null;
      } else if (pendingGods.has(a.myth_god)) {
        status = 'pending';
      }
      
      return {
        ...a,
        status,
        points_earned
      };
    });
    
    res.json(assignmentsWithStatus);
  } catch (err) {
    console.error('Get bonus assignments error:', err);
    res.status(500).json({ error: 'Failed to fetch bonus assignments' });
  }
});

// Teacher: View a specific student's grades
app.get('/api/teacher/student-grades/:student_id', authenticateToken, (req, res) => {
  try {
    const { student_id } = req.params;
    
    // Get student info
    const student = query('SELECT student_id, name, class_period FROM students WHERE student_id = ?', [student_id])[0];
    
    if (!student) {
      return res.status(404).json({ error: 'Student not found' });
    }
    
    // Get all assignments
    const allAssignments = query(`
      SELECT * FROM assignments_ref WHERE age = 'Archaic'
    `);
    
    // Get student's completed assignments
    const completedRecords = query(`
      SELECT gr.*, ar.section, ar.assignment_type, ar.myth_god, ar.display_name, ar.max_points as assignment_max, ar.is_bonus
      FROM grade_records gr
      JOIN assignments_ref ar ON gr.assignment_id = ar.assignment_id
      WHERE gr.student_id = ?
    `, [student_id]);
    
    // Calculate totals by section
    const section1Assignments = allAssignments.filter(a => a.section === 'section_1');
    const section2Assignments = allAssignments.filter(a => a.section === 'section_2');
    const bonusAssignments = allAssignments.filter(a => a.section === 'bonus');
    
    const section1Completed = completedRecords.filter(r => r.section === 'section_1');
    const section2Completed = completedRecords.filter(r => r.section === 'section_2');
    const bonusCompleted = completedRecords.filter(r => r.section === 'bonus');
    
    const section1Earned = section1Completed.reduce((sum, r) => sum + r.points_earned, 0);
    const section2Earned = section2Completed.reduce((sum, r) => sum + r.points_earned, 0);
    const bonusEarned = bonusCompleted.reduce((sum, r) => sum + r.points_earned, 0);
    
    const section1Max = section1Assignments.reduce((sum, a) => sum + a.max_points, 0);
    const section2Max = section2Assignments.reduce((sum, a) => sum + a.max_points, 0);
    const bonusMax = bonusAssignments.reduce((sum, a) => sum + a.max_points, 0);
    
    res.json({
      student,
      section1: {
        earned: section1Earned,
        max: section1Max,
        percentage: section1Max > 0 ? Math.round((section1Earned / section1Max) * 100) : 0,
        completed: section1Completed
      },
      section2: {
        earned: section2Earned,
        max: section2Max,
        percentage: section2Max > 0 ? Math.round((section2Earned / section2Max) * 100) : 0,
        completed: section2Completed
      },
      bonus: {
        earned: bonusEarned,
        max: bonusMax,
        percentage: bonusMax > 0 ? Math.round((bonusEarned / bonusMax) * 100) : 0,
        completed: bonusCompleted
      }
    });
  } catch (err) {
    console.error('Get student grades error:', err);
    res.status(500).json({ error: 'Failed to fetch student grades' });
  }
});

// Teacher: Get all students' grade overview by class period
app.get('/api/teacher/grade-overview', authenticateToken, (req, res) => {
  try {
    // Get all students
    const students = query(`
      SELECT student_id, name, class_period, alliance_id
      FROM students
      ORDER BY class_period, name
    `);
    
    // Get all assignments for calculating max points
    const allAssignments = query(`SELECT * FROM assignments_ref WHERE age = 'Archaic'`);
    const section1Max = allAssignments.filter(a => a.section === 'section_1').reduce((sum, a) => sum + a.max_points, 0);
    const section2Max = allAssignments.filter(a => a.section === 'section_2').reduce((sum, a) => sum + a.max_points, 0);
    const bonusMax = allAssignments.filter(a => a.section === 'bonus').reduce((sum, a) => sum + a.max_points, 0);
    
    // Get all grade records
    const allGradeRecords = query(`
      SELECT gr.student_id, gr.points_earned, ar.section
      FROM grade_records gr
      JOIN assignments_ref ar ON gr.assignment_id = ar.assignment_id
    `);
    
    // Calculate grades for each student
    const studentsWithGrades = students.map(student => {
      const studentRecords = allGradeRecords.filter(r => r.student_id === student.student_id);
      
      const section1Earned = studentRecords.filter(r => r.section === 'section_1').reduce((sum, r) => sum + r.points_earned, 0);
      const section2Earned = studentRecords.filter(r => r.section === 'section_2').reduce((sum, r) => sum + r.points_earned, 0);
      const bonusEarned = studentRecords.filter(r => r.section === 'bonus').reduce((sum, r) => sum + r.points_earned, 0);
      
      return {
        student_id: student.student_id,
        name: student.name,
        class_period: student.class_period || 'Unassigned',
        section1: {
          earned: section1Earned,
          max: section1Max,
          percentage: section1Max > 0 ? Math.round((section1Earned / section1Max) * 100) : 0
        },
        section2: {
          earned: section2Earned,
          max: section2Max,
          percentage: section2Max > 0 ? Math.round((section2Earned / section2Max) * 100) : 0
        },
        bonus: {
          earned: bonusEarned,
          max: bonusMax,
          percentage: bonusMax > 0 ? Math.round((bonusEarned / bonusMax) * 100) : 0
        }
      };
    });
    
    // Group by class period
    const periods = ['1st', '2nd', '3rd', '4th', 'Unassigned'];
    const byPeriod = periods.map(period => ({
      period,
      students: studentsWithGrades.filter(s => s.class_period === period).sort((a, b) => a.name.localeCompare(b.name))
    })).filter(p => p.students.length > 0);
    
    res.json({
      byPeriod,
      maxPoints: {
        section1: section1Max,
        section2: section2Max,
        bonus: bonusMax
      }
    });
  } catch (err) {
    console.error('Get grade overview error:', err);
    res.status(500).json({ error: 'Failed to fetch grade overview' });
  }
});

// Get all submissions for a specific student (for teacher to view/delete)
app.get('/api/teacher/student-submissions/:student_id', authenticateToken, (req, res) => {
  try {
    const { student_id } = req.params;
    
    const submissions = query(`
      SELECT 
        submission_id,
        category,
        section,
        myth_god,
        points_claimed,
        max_points,
        status,
        submitted_at,
        reviewed_at,
        description
      FROM point_submissions
      WHERE student_id = ?
      ORDER BY submitted_at DESC
    `, [student_id]);
    
    res.json(submissions);
  } catch (err) {
    console.error('Get student submissions error:', err);
    res.status(500).json({ error: 'Failed to fetch submissions' });
  }
});

// Delete a submission (teacher only)
app.delete('/api/teacher/delete-submission/:submission_id', authenticateToken, (req, res) => {
  try {
    const { submission_id } = req.params;
    
    // Get the submission first to know how many points to remove
    const submission = query('SELECT * FROM point_submissions WHERE submission_id = ?', [submission_id])[0];
    
    if (!submission) {
      return res.status(404).json({ error: 'Submission not found' });
    }
    
    // Only allow deleting approved submissions (pending ones can just be rejected)
    if (submission.status !== 'approved') {
      return res.status(400).json({ error: 'Can only delete approved submissions. Reject pending submissions instead.' });
    }
    
    const student_id = submission.student_id;
    const points_to_remove = submission.points_claimed || 0;
    
    // Get student's alliance
    const student = query('SELECT alliance_id FROM students WHERE student_id = ?', [student_id])[0];
    
    // Delete the submission
    run('DELETE FROM point_submissions WHERE submission_id = ?', [submission_id]);
    
    // Delete from grade_records if exists
    run('DELETE FROM grade_records WHERE submission_id = ?', [submission_id]);
    
    // Subtract points from alliance if student is in one
    if (student && student.alliance_id && points_to_remove > 0) {
      run('UPDATE alliances SET total_points = MAX(0, total_points - ?) WHERE alliance_id = ?', 
        [points_to_remove, student.alliance_id]);
    }
    
    console.log(`Deleted submission ${submission_id} for student ${student_id}, removed ${points_to_remove} points`);
    
    res.json({ 
      message: 'Submission deleted successfully',
      points_removed: points_to_remove
    });
    
    saveDatabase();
  } catch (err) {
    console.error('Delete submission error:', err);
    res.status(500).json({ error: 'Failed to delete submission' });
  }
});

// ====================
// MAP SYSTEM
// ====================

// Building icon mapping
const BUILDING_ICONS = {
  'Town Center': '/buildings/town_center.png',
  'Library': '/buildings/library.png',
  'House': '/buildings/house.png',
  'Wooden Wall': '🧱',
  'Stone Wall': '🪨',
  'Dock': '/buildings/dock.png',
  'Fishing Ship': '/buildings/fishing_boat.png',
  'Granary': '/buildings/granary.png',
  'Storehouse': '/buildings/storehouse.png'
};

// Student: Upload map
app.post('/api/student/upload-map', authenticateToken, (req, res) => {
  try {
    const { map_image } = req.body; // base64 encoded image
    const student_id = req.user.id;
    
    console.log('Upload map request received for student:', student_id);
    console.log('Image data length:', map_image ? map_image.length : 'no image');
    
    if (!map_image) {
      return res.status(400).json({ error: 'No map image provided' });
    }
    
    // Validate it's a base64 image
    if (!map_image.startsWith('data:image/')) {
      console.log('Invalid image format, starts with:', map_image.substring(0, 50));
      return res.status(400).json({ error: 'Invalid image format' });
    }
    
    // Save map
    console.log('Saving map to database...');
    run('UPDATE students SET map_image = ?, map_uploaded_at = CURRENT_TIMESTAMP WHERE student_id = ?',
        [map_image, student_id]);
    
    // If student is in an alliance, mark the alliance's civilization_map_complete as true
    const student = query('SELECT alliance_id FROM students WHERE student_id = ?', [student_id])[0];
    console.log('Student alliance_id:', student ? student.alliance_id : 'no student found');
    
    if (student && student.alliance_id) {
      console.log('Marking civilization_map_complete = 1 for alliance:', student.alliance_id);
      run('UPDATE alliances SET civilization_map_complete = 1 WHERE alliance_id = ?', [student.alliance_id]);
      
      // Verify the update worked
      const alliance = query('SELECT civilization_map_complete FROM alliances WHERE alliance_id = ?', [student.alliance_id])[0];
      console.log('Alliance civilization_map_complete after update:', alliance ? alliance.civilization_map_complete : 'not found');
      
      console.log('Alliance map requirement marked complete');
    }
    
    // Save database to persist
    saveDatabase();
    
    console.log('Map saved successfully!');
    res.json({ success: true, message: 'Map uploaded successfully!' });
  } catch (err) {
    console.error('Upload map error:', err);
    res.status(500).json({ error: 'Failed to upload map: ' + err.message });
  }
});

// Student: Get my map and placements
app.get('/api/student/my-map', authenticateToken, (req, res) => {
  try {
    const student_id = req.user.id;
    console.log('Loading map for student:', student_id);
    
    const student = query(`
      SELECT s.*, a.buildings_owned, a.alliance_name 
      FROM students s 
      LEFT JOIN alliances a ON s.alliance_id = a.alliance_id 
      WHERE s.student_id = ?
    `, [student_id])[0];
    
    if (!student) {
      console.log('Student not found');
      return res.status(404).json({ error: 'Student not found' });
    }
    
    console.log('Student found, has map:', !!student.map_image);
    console.log('Map image length:', student.map_image ? student.map_image.length : 0);
    
    const placements = query('SELECT * FROM building_placements WHERE student_id = ?', [student_id]);
    console.log('Placements found:', placements.length);
    
    // Get available buildings to place (owned by alliance but not yet placed by this student)
    const ownedBuildings = JSON.parse(student.buildings_owned || '[]');
    console.log('Owned buildings:', ownedBuildings);
    
    // Count placements per building
    const placementCounts = {};
    placements.forEach(p => {
      placementCounts[p.building_name] = (placementCounts[p.building_name] || 0) + 1;
    });
    
    // Calculate what can still be placed
    const buildingsToPlace = [];
    const buildingCounts = {};
    ownedBuildings.forEach(b => {
      buildingCounts[b] = (buildingCounts[b] || 0) + 1;
    });
    
    Object.keys(buildingCounts).forEach(building => {
      const owned = buildingCounts[building];
      const placed = placementCounts[building] || 0;
      const remaining = owned - placed;
      if (remaining > 0) {
        buildingsToPlace.push({
          building_name: building,
          icon: BUILDING_ICONS[building] || '🏗️',
          count: remaining
        });
      }
    });
    
    console.log('Sending response...');
    
    // Safely get wall_points (column might not exist in older databases)
    let wallPoints = null;
    try {
      if (student.wall_points) {
        wallPoints = JSON.parse(student.wall_points);
      }
    } catch (e) {
      console.log('Could not parse wall_points:', e.message);
    }
    
    res.json({
      hasMap: !!student.map_image,
      map_image: student.map_image,
      map_uploaded_at: student.map_uploaded_at,
      wall_points: wallPoints,
      placements: placements.map(p => ({
        ...p,
        icon: BUILDING_ICONS[p.building_name] || '🏗️'
      })),
      buildingsToPlace,
      alliance_name: student.alliance_name
    });
    console.log('Response sent successfully');
  } catch (err) {
    console.error('Get my map error:', err);
    res.status(500).json({ error: 'Failed to fetch map: ' + err.message });
  }
});

// Student: Place building on map
app.post('/api/student/place-building', authenticateToken, (req, res) => {
  try {
    const { building_name, x_position, y_position } = req.body;
    const student_id = req.user.id;
    
    // Check student has a map
    const student = query(`
      SELECT s.*, a.buildings_owned 
      FROM students s 
      LEFT JOIN alliances a ON s.alliance_id = a.alliance_id 
      WHERE s.student_id = ?
    `, [student_id])[0];
    
    if (!student.map_image) {
      return res.status(400).json({ error: 'You must upload a map first' });
    }
    
    // Check alliance owns this building
    const ownedBuildings = JSON.parse(student.buildings_owned || '[]');
    const ownedCount = ownedBuildings.filter(b => b === building_name).length;
    
    if (ownedCount === 0) {
      return res.status(400).json({ error: 'Your alliance does not own this building' });
    }
    
    // Check how many this student has already placed
    const placedCount = query(
      'SELECT COUNT(*) as count FROM building_placements WHERE student_id = ? AND building_name = ?',
      [student_id, building_name]
    )[0].count;
    
    if (placedCount >= ownedCount) {
      return res.status(400).json({ error: 'You have already placed all of these buildings' });
    }
    
    // Place the building
    const instance = placedCount + 1;
    run(`INSERT INTO building_placements (student_id, building_name, instance_number, x_position, y_position)
         VALUES (?, ?, ?, ?, ?)`,
        [student_id, building_name, instance, x_position, y_position]);
    
    res.json({ 
      success: true, 
      message: `${building_name} placed on your map!`,
      icon: BUILDING_ICONS[building_name] || '🏗️'
    });
  } catch (err) {
    console.error('Place building error:', err);
    res.status(500).json({ error: 'Failed to place building' });
  }
});

// Student: Move building on map
app.post('/api/student/move-building', authenticateToken, (req, res) => {
  try {
    const { placement_id, x_position, y_position } = req.body;
    const student_id = req.user.id;
    
    // Verify ownership
    const placement = query('SELECT * FROM building_placements WHERE placement_id = ? AND student_id = ?',
                           [placement_id, student_id])[0];
    
    if (!placement) {
      return res.status(404).json({ error: 'Placement not found' });
    }
    
    run('UPDATE building_placements SET x_position = ?, y_position = ? WHERE placement_id = ?',
        [x_position, y_position, placement_id]);
    
    res.json({ success: true });
  } catch (err) {
    console.error('Move building error:', err);
    res.status(500).json({ error: 'Failed to move building' });
  }
});

// Student: Save wall drawing
app.post('/api/student/save-wall', authenticateToken, (req, res) => {
  try {
    const { wall_points } = req.body;
    const student_id = req.user.id;
    
    // Validate wall points
    if (!wall_points || !Array.isArray(wall_points) || wall_points.length < 3) {
      return res.status(400).json({ error: 'Wall must have at least 3 points' });
    }
    
    // Check student has a wall building
    const student = query(`
      SELECT s.*, a.buildings_owned 
      FROM students s 
      LEFT JOIN alliances a ON s.alliance_id = a.alliance_id 
      WHERE s.student_id = ?
    `, [student_id])[0];
    
    if (!student) {
      return res.status(404).json({ error: 'Student not found' });
    }
    
    const ownedBuildings = JSON.parse(student.buildings_owned || '[]');
    const hasWall = ownedBuildings.includes('Wooden Wall') || ownedBuildings.includes('Stone Wall');
    
    if (!hasWall) {
      return res.status(400).json({ error: 'You must own a wall building to draw walls' });
    }
    
    // Save wall points as JSON
    const wallPointsJson = JSON.stringify(wall_points);
    run('UPDATE students SET wall_points = ? WHERE student_id = ?', [wallPointsJson, student_id]);
    
    console.log(`🏰 Student ${student_id} saved wall with ${wall_points.length} points`);
    
    res.json({ success: true, wall_points });
  } catch (err) {
    console.error('Save wall error:', err);
    res.status(500).json({ error: 'Failed to save wall' });
  }
});

// Get alliance maps (for viewing alliance members' maps)
app.get('/api/alliance/maps/:alliance_id', authenticateToken, (req, res) => {
  try {
    const { alliance_id } = req.params;
    
    const members = query(`
      SELECT student_id, name, map_image, map_uploaded_at, wall_points 
      FROM students 
      WHERE alliance_id = ?
    `, [alliance_id]);
    
    const mapsWithPlacements = members.map(member => {
      const placements = query('SELECT * FROM building_placements WHERE student_id = ?', [member.student_id]);
      
      // Parse wall_points safely
      let wallPoints = null;
      try {
        if (member.wall_points) {
          wallPoints = JSON.parse(member.wall_points);
        }
      } catch (e) {
        console.log('Could not parse wall_points for student', member.student_id);
      }
      
      return {
        ...member,
        hasMap: !!member.map_image,
        wall_points: wallPoints,
        placements: placements.map(p => ({
          ...p,
          icon: BUILDING_ICONS[p.building_name] || '🏗️'
        }))
      };
    });
    
    res.json(mapsWithPlacements);
  } catch (err) {
    console.error('Get alliance maps error:', err);
    res.status(500).json({ error: 'Failed to fetch alliance maps' });
  }
});

// Get single student's map (for gallery view)
app.get('/api/student/map/:student_id', authenticateToken, (req, res) => {
  try {
    const { student_id } = req.params;
    
    const student = query(`
      SELECT s.student_id, s.name, s.map_image, s.map_uploaded_at, s.wall_points, a.alliance_name, a.buildings_owned
      FROM students s
      LEFT JOIN alliances a ON s.alliance_id = a.alliance_id
      WHERE s.student_id = ?
    `, [student_id])[0];
    
    if (!student) {
      return res.status(404).json({ error: 'Student not found' });
    }
    
    const placements = query('SELECT * FROM building_placements WHERE student_id = ?', [student_id]);
    
    // Parse wall_points safely
    let wallPoints = null;
    try {
      if (student.wall_points) {
        wallPoints = JSON.parse(student.wall_points);
      }
    } catch (e) {
      console.log('Could not parse wall_points');
    }
    
    res.json({
      ...student,
      hasMap: !!student.map_image,
      wall_points: wallPoints,
      placements: placements.map(p => ({
        ...p,
        icon: BUILDING_ICONS[p.building_name] || '🏗️'
      }))
    });
  } catch (err) {
    console.error('Get student map error:', err);
    res.status(500).json({ error: 'Failed to fetch map' });
  }
});

// Check if student has map (for purchase blocking)
app.get('/api/student/has-map', authenticateToken, (req, res) => {
  try {
    const student_id = req.user.id;
    const student = query('SELECT map_image FROM students WHERE student_id = ?', [student_id])[0];
    res.json({ hasMap: !!student.map_image });
  } catch (err) {
    res.status(500).json({ error: 'Failed to check map status' });
  }
});

// ====================
// ALLIANCE INVITATIONS
// ====================

// Send Alliance Invitation
app.post('/api/alliance/invite', authenticateToken, (req, res) => {
  try {
    const { invited_student_id } = req.body;
    const inviter_id = req.user.id;
    
    // Get inviter's info including class period and alliance
    const inviter = query('SELECT s.alliance_id, s.class_period FROM students s WHERE s.student_id = ?', [inviter_id])[0];
    
    if (!inviter || !inviter.alliance_id) {
      return res.status(400).json({ error: 'You must be in an alliance to send invitations' });
    }
    
    // Check alliance member count (can only invite if < 4 members)
    const memberCount = query('SELECT COUNT(*) as count FROM students WHERE alliance_id = ?', [inviter.alliance_id])[0].count;
    if (memberCount >= 4) {
      return res.status(400).json({ error: 'Your alliance is full (4 members maximum)' });
    }
    
    // Check if invited student exists and get their info
    const invited = query('SELECT alliance_id, class_period FROM students WHERE student_id = ?', [invited_student_id])[0];
    
    if (!invited) {
      return res.status(404).json({ error: 'Student not found' });
    }
    
    // Must be same class period
    if (invited.class_period !== inviter.class_period) {
      return res.status(400).json({ error: 'Can only invite students from your class period' });
    }
    
    if (invited.alliance_id) {
      return res.status(400).json({ error: 'This student is already in an alliance' });
    }
    
    // Check if invitation already exists
    const existing = query(`
      SELECT * FROM alliance_invitations 
      WHERE alliance_id = ? AND invited_student_id = ? AND status = 'pending'
    `, [inviter.alliance_id, invited_student_id]);
    
    if (existing.length > 0) {
      return res.status(400).json({ error: 'Invitation already sent to this student' });
    }
    
    // Create invitation
    run(`INSERT INTO alliance_invitations (alliance_id, inviter_student_id, invited_student_id, status) 
         VALUES (?, ?, ?, 'pending')`, 
        [inviter.alliance_id, inviter_id, invited_student_id]);
    
    res.json({ success: true, message: 'Invitation sent!' });
  } catch (err) {
    console.error('Send invitation error:', err);
    res.status(500).json({ error: 'Failed to send invitation' });
  }
});

// Get Student's Pending Invitations
app.get('/api/student/invitations', authenticateToken, (req, res) => {
  try {
    const student_id = req.user.id;
    
    const invitations = query(`
      SELECT 
        i.*,
        a.alliance_name,
        s.name as inviter_name
      FROM alliance_invitations i
      JOIN alliances a ON i.alliance_id = a.alliance_id
      JOIN students s ON i.inviter_student_id = s.student_id
      WHERE i.invited_student_id = ? AND i.status = 'pending'
      ORDER BY i.created_at DESC
    `, [student_id]);
    
    res.json(invitations);
  } catch (err) {
    console.error('Get invitations error:', err);
    res.status(500).json({ error: 'Failed to fetch invitations' });
  }
});

// Respond to Alliance Invitation
app.post('/api/alliance/respond-invitation', authenticateToken, (req, res) => {
  try {
    const { invitation_id, accept } = req.body;
    const student_id = req.user.id;
    
    // Get invitation
    const invitation = query(`
      SELECT * FROM alliance_invitations 
      WHERE invitation_id = ? AND invited_student_id = ?
    `, [invitation_id, student_id])[0];
    
    if (!invitation) {
      return res.status(404).json({ error: 'Invitation not found' });
    }
    
    if (invitation.status !== 'pending') {
      return res.status(400).json({ error: 'Invitation already responded to' });
    }
    
    // Check if student is already in an alliance
    const student = query('SELECT alliance_id, class_period FROM students WHERE student_id = ?', [student_id])[0];
    if (student.alliance_id) {
      return res.status(400).json({ error: 'You are already in an alliance' });
    }
    
    if (accept) {
      // Verify class period matches before accepting
      const alliance = query('SELECT class_period FROM alliances WHERE alliance_id = ?', [invitation.alliance_id])[0];
      if (alliance && alliance.class_period !== student.class_period) {
        // Cancel this invalid invitation
        run(`UPDATE alliance_invitations SET status = 'cancelled' WHERE invitation_id = ?`, [invitation_id]);
        return res.status(400).json({ error: 'Cannot join alliance from different class period' });
      }
      
      // Accept invitation - add student to alliance
      run('UPDATE students SET alliance_id = ? WHERE student_id = ?', 
          [invitation.alliance_id, student_id]);
      
      run(`UPDATE alliance_invitations 
           SET status = 'accepted', responded_at = CURRENT_TIMESTAMP 
           WHERE invitation_id = ?`, 
          [invitation_id]);
      
      // Cancel any other pending invitations for this student
      run(`UPDATE alliance_invitations 
           SET status = 'cancelled' 
           WHERE invited_student_id = ? AND status = 'pending' AND invitation_id != ?`,
          [student_id, invitation_id]);
      
      res.json({ success: true, message: 'You joined the alliance!' });
    } else {
      // Decline invitation
      run(`UPDATE alliance_invitations 
           SET status = 'declined', responded_at = CURRENT_TIMESTAMP 
           WHERE invitation_id = ?`, 
          [invitation_id]);
      
      res.json({ success: true, message: 'Invitation declined' });
    }
  } catch (err) {
    console.error('Respond invitation error:', err);
    res.status(500).json({ error: 'Failed to respond to invitation' });
  }
});

// Get students available to invite (same class period, not in any alliance)
app.get('/api/alliance/available-students', authenticateToken, (req, res) => {
  try {
    const student_id = req.user.id;
    
    // Get current student's class period
    const currentStudent = query('SELECT class_period FROM students WHERE student_id = ?', [student_id])[0];
    
    // Get students without an alliance, same class period, excluding the current student
    const students = query(`
      SELECT student_id, name, class_period 
      FROM students 
      WHERE alliance_id IS NULL 
        AND student_id != ?
        AND class_period = ?
      ORDER BY name
    `, [student_id, currentStudent.class_period]);
    
    res.json(students);
  } catch (err) {
    console.error('Get available students error:', err);
    res.status(500).json({ error: 'Failed to fetch students' });
  }
});

// ====================
// ALLIANCE ROUTES
// ====================

// Create Alliance
app.post('/api/alliance/create', authenticateToken, (req, res) => {
  try {
    const { alliance_name } = req.body;
    const student_id = req.user.id;
    
    // Check if student is already in an alliance
    const student = query('SELECT alliance_id, class_period FROM students WHERE student_id = ?', [student_id])[0];
    if (student.alliance_id) {
      return res.status(400).json({ error: 'Already in an alliance' });
    }
    
    // Check if alliance name already exists (must be unique across entire game)
    const existingAlliance = query('SELECT * FROM alliances WHERE alliance_name = ? AND is_disbanded = 0', [alliance_name]);
    if (existingAlliance.length > 0) {
      return res.status(400).json({ error: 'An alliance with this name already exists. Please choose a different name.' });
    }
    
    // Create alliance with empty buildings (must purchase Town Center)
    run('INSERT INTO alliances (alliance_name, class_period, buildings_owned) VALUES (?, ?, ?)', 
        [alliance_name, student.class_period, JSON.stringify([])]);
    
    // Get the newly created alliance by ID (not by name, to avoid confusion)
    const alliance = query('SELECT * FROM alliances WHERE alliance_name = ? AND class_period = ? ORDER BY alliance_id DESC LIMIT 1', 
        [alliance_name, student.class_period])[0];
    
    // Add student to alliance
    run('UPDATE students SET alliance_id = ? WHERE student_id = ?', 
        [alliance.alliance_id, student_id]);
    
    res.json({ success: true, alliance });
  } catch (err) {
    console.error('Create alliance error:', err);
    res.status(500).json({ error: 'Failed to create alliance' });
  }
});

// ====================
// PHASE 3: BUILDINGS & MARKET
// ====================

// Get all buildings for market display
app.get('/api/buildings', authenticateToken, (req, res) => {
  try {
    const buildings = query(`
      SELECT 
        b.*,
        pb.building_name as prerequisite_name
      FROM buildings_ref b
      LEFT JOIN buildings_ref pb ON b.prerequisite_building_id = pb.building_id
      ORDER BY b.building_id
    `);
    
    res.json(buildings);
  } catch (err) {
    console.error('Get buildings error:', err);
    res.status(500).json({ error: 'Failed to fetch buildings' });
  }
});

// Get alliance's owned buildings and purchase eligibility
app.get('/api/alliance/buildings/:alliance_id', authenticateToken, (req, res) => {
  try {
    const { alliance_id } = req.params;
    
    // Get alliance info
    const alliance = query('SELECT * FROM alliances WHERE alliance_id = ?', [alliance_id])[0];
    if (!alliance) {
      return res.status(404).json({ error: 'Alliance not found' });
    }
    
    const ownedBuildings = JSON.parse(alliance.buildings_owned || '[]');
    
    // Get all buildings
    const allBuildings = query(`
      SELECT 
        b.*,
        pb.building_name as prerequisite_name
      FROM buildings_ref b
      LEFT JOIN buildings_ref pb ON b.prerequisite_building_id = pb.building_id
      ORDER BY b.building_id
    `);
    
    // Get completed god assignments for this alliance - check BOTH god_assignments table AND grade_records for bonus assignments
    const godAssignmentsFromTable = query(
      'SELECT god_name FROM god_assignments WHERE alliance_id = ?', 
      [alliance_id]
    ).map(a => a.god_name);
    
    // Also check grade_records for completed bonus assignments (any alliance member)
    const allianceMembers = query('SELECT student_id, name FROM students WHERE alliance_id = ?', [alliance_id]);
    const memberIds = allianceMembers.map(m => m.student_id);
    const memberCount = allianceMembers.length;
    
    let completedBonusGods = [];
    let bonusProgress = {}; // Track how many members completed each bonus
    
    if (memberIds.length > 0) {
      // Get distinct gods that ANY member has completed
      const bonusGrades = query(`
        SELECT DISTINCT ar.myth_god 
        FROM grade_records gr
        JOIN assignments_ref ar ON gr.assignment_id = ar.assignment_id
        WHERE gr.student_id IN (${memberIds.join(',')}) 
          AND ar.section = 'bonus' 
          AND gr.points_earned > 0
      `);
      completedBonusGods = bonusGrades.map(g => g.myth_god);
      
      // Get count of members who completed each bonus god
      const bonusCountQuery = query(`
        SELECT ar.myth_god, COUNT(DISTINCT gr.student_id) as completed_count
        FROM grade_records gr
        JOIN assignments_ref ar ON gr.assignment_id = ar.assignment_id
        WHERE gr.student_id IN (${memberIds.join(',')}) 
          AND ar.section = 'bonus' 
          AND gr.points_earned > 0
        GROUP BY ar.myth_god
      `);
      bonusCountQuery.forEach(row => {
        bonusProgress[row.myth_god] = row.completed_count;
      });
    }
    
    // Combine both sources
    const completedAssignments = [...new Set([...godAssignmentsFromTable, ...completedBonusGods])];
    console.log('Completed god assignments for alliance', alliance_id, ':', completedAssignments);
    console.log('Bonus progress:', bonusProgress);
    
    // Check if any member has completed Prometheus AND Zeus assignments (for Town Center)
    let hasTownCenterRequirement = false;
    for (const member of allianceMembers) {
      const prometheusGrade = query(`
        SELECT gr.* FROM grade_records gr
        JOIN assignments_ref ar ON gr.assignment_id = ar.assignment_id
        WHERE gr.student_id = ? AND ar.myth_god = 'Prometheus' AND gr.points_earned > 0
      `, [member.student_id]);
      
      const zeusGrade = query(`
        SELECT gr.* FROM grade_records gr
        JOIN assignments_ref ar ON gr.assignment_id = ar.assignment_id
        WHERE gr.student_id = ? AND ar.myth_god = 'Zeus' AND gr.points_earned > 0
      `, [member.student_id]);
      
      if (prometheusGrade.length > 0 && zeusGrade.length > 0) {
        hasTownCenterRequirement = true;
        break;
      }
    }
    
    // Check for alliance technologies (Pickaxe = -10% building cost)
    let allianceTechs = [];
    try {
      allianceTechs = query(
        'SELECT tech_name FROM alliance_technologies WHERE alliance_id = ?',
        [alliance_id]
      ).map(t => t.tech_name);
    } catch (techErr) {
      console.log('Note: alliance_technologies table may not exist yet');
      allianceTechs = [];
    }
    
    const hasPickaxe = allianceTechs.includes('Pickaxe');
    const hasGranaryUnlock = allianceTechs.includes('Granary'); // Demeter side quest completed
    
    // Calculate eligibility for each building
    const buildingsWithEligibility = allBuildings.map(building => {
      const owned = ownedBuildings.filter(b => b === building.building_name).length;
      
      // Apply Pickaxe discount (-10% on all building costs)
      const baseCost = building.cost_points;
      const effectiveCost = hasPickaxe ? Math.floor(baseCost * 0.9) : baseCost;
      
      const canAfford = alliance.total_points >= effectiveCost;
      const hasPrerequisite = !building.prerequisite_building_id || 
        ownedBuildings.includes(building.prerequisite_name);
      
      // Special handling for different buildings
      let hasGodAssignment = true;
      let specialRequirement = null;
      let bonusCompletedCount = 0;
      
      if (building.building_name === 'Town Center') {
        // Town Center requires Prometheus + Zeus grades
        hasGodAssignment = hasTownCenterRequirement;
        if (!hasGodAssignment) {
          specialRequirement = 'Requires Prometheus & Zeus assignments';
        }
      } else if (building.building_name === 'Granary') {
        // Granary requires Demeter Side Quest completion
        hasGodAssignment = hasGranaryUnlock;
        if (!hasGodAssignment) {
          specialRequirement = 'Requires Demeter Side Quest';
        }
      } else if (building.requires_god_assignment) {
        // Normal god assignment requirement - needs ALL members to complete the bonus
        bonusCompletedCount = bonusProgress[building.god_associated] || 0;
        hasGodAssignment = bonusCompletedCount >= memberCount; // ALL members must complete
      }
      
      const underMaxLimit = owned < building.max_per_alliance;
      
      return {
        ...building,
        owned_count: owned,
        can_afford: canAfford,
        has_prerequisite: hasPrerequisite,
        has_god_assignment: hasGodAssignment,
        under_max_limit: underMaxLimit,
        can_purchase: canAfford && hasPrerequisite && hasGodAssignment && underMaxLimit,
        base_cost: baseCost,
        effective_cost: effectiveCost,
        has_discount: hasPickaxe,
        bonus_completed_count: bonusCompletedCount,
        member_count: memberCount,
        reason_cannot_purchase: specialRequirement ? specialRequirement :
          !canAfford ? 'Not enough points' :
          !hasPrerequisite ? `Requires ${building.prerequisite_name}` :
          !hasGodAssignment ? `${building.god_associated} Bonus: ${bonusCompletedCount}/${memberCount} members` :
          !underMaxLimit ? `Maximum ${building.max_per_alliance} allowed` : null
      };
    });
    
    res.json({
      alliance_points: alliance.total_points,
      owned_buildings: ownedBuildings,
      completed_assignments: completedAssignments,
      alliance_technologies: allianceTechs,
      member_count: memberCount,
      buildings: buildingsWithEligibility
    });
  } catch (err) {
    console.error('Get alliance buildings error:', err);
    console.error('Error stack:', err.stack);
    res.status(500).json({ error: 'Failed to fetch alliance buildings: ' + err.message });
  }
});

// Purchase a building
app.post('/api/alliance/purchase-building', authenticateToken, (req, res) => {
  try {
    const { building_id } = req.body;
    const student_id = req.user.id;
    
    // Get student's alliance and map status
    const student = query('SELECT alliance_id, map_image FROM students WHERE student_id = ?', [student_id])[0];
    if (!student || !student.alliance_id) {
      return res.status(400).json({ error: 'You must be in an alliance to purchase buildings' });
    }
    
    // Check if student has uploaded a map
    if (!student.map_image) {
      return res.status(400).json({ error: 'You must upload your civilization map before purchasing buildings. Click "Upload Map" to get started!' });
    }
    
    const alliance_id = student.alliance_id;
    const alliance = query('SELECT * FROM alliances WHERE alliance_id = ?', [alliance_id])[0];
    const ownedBuildings = JSON.parse(alliance.buildings_owned || '[]');
    
    // Check for Pickaxe technology (-10% building cost)
    const allianceTechs = query(
      'SELECT tech_name FROM alliance_technologies WHERE alliance_id = ?',
      [alliance_id]
    ).map(t => t.tech_name);
    const hasPickaxe = allianceTechs.includes('Pickaxe');
    
    // Get building info
    const building = query(`
      SELECT b.*, pb.building_name as prerequisite_name
      FROM buildings_ref b
      LEFT JOIN buildings_ref pb ON b.prerequisite_building_id = pb.building_id
      WHERE b.building_id = ?
    `, [building_id])[0];
    
    if (!building) {
      return res.status(404).json({ error: 'Building not found' });
    }
    
    // Calculate effective cost with Pickaxe discount
    const effectiveCost = hasPickaxe ? Math.floor(building.cost_points * 0.9) : building.cost_points;
    
    // Check all requirements
    const owned = ownedBuildings.filter(b => b === building.building_name).length;
    
    if (alliance.total_points < effectiveCost) {
      return res.status(400).json({ error: 'Not enough points' });
    }
    
    if (building.prerequisite_building_id && !ownedBuildings.includes(building.prerequisite_name)) {
      return res.status(400).json({ error: `Requires ${building.prerequisite_name} first` });
    }
    
    // Special handling for Granary (requires Demeter Side Quest)
    if (building.building_name === 'Granary') {
      const hasGranaryUnlock = allianceTechs.includes('Granary');
      if (!hasGranaryUnlock) {
        return res.status(400).json({ error: 'Requires Demeter Side Quest completion' });
      }
    } else if (building.requires_god_assignment) {
      const hasAssignment = query(
        'SELECT * FROM god_assignments WHERE alliance_id = ? AND god_name = ?',
        [alliance_id, building.god_associated]
      );
      if (hasAssignment.length === 0) {
        return res.status(400).json({ error: `Requires ${building.god_associated} assignment completion` });
      }
    }
    
    if (owned >= building.max_per_alliance) {
      return res.status(400).json({ error: `Maximum ${building.max_per_alliance} ${building.building_name}(s) allowed` });
    }
    
    // Purchase the building
    ownedBuildings.push(building.building_name);
    
    // Deduct points (using effective cost with discount) and update buildings
    run('UPDATE alliances SET total_points = total_points - ?, buildings_owned = ? WHERE alliance_id = ?',
        [effectiveCost, JSON.stringify(ownedBuildings), alliance_id]);
    
    // Log transaction (student_id = NULL so it's an alliance transaction, not personal)
    // This prevents building purchases from affecting personal contribution tracking
    const discountNote = hasPickaxe ? ' (10% Pickaxe discount applied)' : '';
    run(`INSERT INTO point_transactions (alliance_id, student_id, amount, category, reason)
         VALUES (?, NULL, ?, ?, ?)`,
        [alliance_id, -effectiveCost, 'Building Purchase', `Purchased ${building.building_name} (by ${req.user.name})${discountNote}`]);
    
    // Create activation record for this building (starts as ready to activate)
    const instanceNum = owned + 1;
    run(`INSERT INTO building_activations (alliance_id, building_name, building_instance)
         VALUES (?, ?, ?)`,
        [alliance_id, building.building_name, instanceNum]);
    
    res.json({ 
      success: true, 
      message: `Purchased ${building.building_name} for ${effectiveCost} points${hasPickaxe ? ' (10% discount!)' : ''}`,
      new_balance: alliance.total_points - effectiveCost,
      buildings_owned: ownedBuildings
    });
  } catch (err) {
    console.error('Purchase building error:', err);
    res.status(500).json({ error: 'Failed to purchase building' });
  }
});

// Teacher: Grant god assignment completion to an alliance
app.post('/api/teacher/grant-god-assignment', authenticateToken, (req, res) => {
  try {
    const { alliance_id, god_name } = req.body;
    const teacher_id = req.user.id;
    
    // Check if already granted
    const existing = query(
      'SELECT * FROM god_assignments WHERE alliance_id = ? AND god_name = ?',
      [alliance_id, god_name]
    );
    
    if (existing.length > 0) {
      return res.status(400).json({ error: `${god_name} assignment already completed for this alliance` });
    }
    
    run(`INSERT INTO god_assignments (alliance_id, god_name, completed_by_teacher_id) VALUES (?, ?, ?)`,
        [alliance_id, god_name, teacher_id]);
    
    // Get alliance name for response
    const alliance = query('SELECT alliance_name FROM alliances WHERE alliance_id = ?', [alliance_id])[0];
    
    res.json({ 
      success: true, 
      message: `${god_name} assignment granted to ${alliance.alliance_name}` 
    });
  } catch (err) {
    console.error('Grant god assignment error:', err);
    res.status(500).json({ error: 'Failed to grant god assignment' });
  }
});

// Teacher: Remove god assignment from an alliance
app.post('/api/teacher/revoke-god-assignment', authenticateToken, (req, res) => {
  try {
    const { alliance_id, god_name } = req.body;
    
    run('DELETE FROM god_assignments WHERE alliance_id = ? AND god_name = ?',
        [alliance_id, god_name]);
    
    res.json({ success: true, message: `${god_name} assignment revoked` });
  } catch (err) {
    console.error('Revoke god assignment error:', err);
    res.status(500).json({ error: 'Failed to revoke god assignment' });
  }
});

// Teacher: Get all god assignments
app.get('/api/teacher/god-assignments', authenticateToken, (req, res) => {
  try {
    const assignments = query(`
      SELECT 
        ga.*,
        a.alliance_name
      FROM god_assignments ga
      JOIN alliances a ON ga.alliance_id = a.alliance_id
      ORDER BY a.alliance_name, ga.god_name
    `);
    
    res.json(assignments);
  } catch (err) {
    console.error('Get god assignments error:', err);
    res.status(500).json({ error: 'Failed to fetch god assignments' });
  }
});

// ====================
// BUILDING REQUESTS (Hybrid System)
// ====================

// Student: Request a building that requires god assignment
app.post('/api/student/request-building', authenticateToken, (req, res) => {
  try {
    const { building_id } = req.body;
    const student_id = req.user.id;
    
    // Get student's alliance
    const student = query('SELECT alliance_id FROM students WHERE student_id = ?', [student_id])[0];
    if (!student || !student.alliance_id) {
      return res.status(400).json({ error: 'You must be in an alliance to request buildings' });
    }
    
    // Get building info
    const building = query('SELECT * FROM buildings_ref WHERE building_id = ?', [building_id])[0];
    if (!building) {
      return res.status(404).json({ error: 'Building not found' });
    }
    
    // Check if building requires god assignment
    if (!building.requires_god_assignment) {
      return res.status(400).json({ error: 'This building does not require a request. You can purchase it directly.' });
    }
    
    // Check if already have god assignment (can purchase directly)
    const hasAssignment = query(
      'SELECT * FROM god_assignments WHERE alliance_id = ? AND god_name = ?',
      [student.alliance_id, building.god_associated]
    );
    if (hasAssignment.length > 0) {
      return res.status(400).json({ error: 'Your alliance already has this god assignment. You can purchase directly.' });
    }
    
    // Check for existing pending request
    const existingRequest = query(
      'SELECT * FROM building_requests WHERE alliance_id = ? AND building_id = ? AND status = ?',
      [student.alliance_id, building_id, 'pending']
    );
    if (existingRequest.length > 0) {
      return res.status(400).json({ error: 'A request for this building is already pending' });
    }
    
    // Create request
    run(`INSERT INTO building_requests (alliance_id, building_id, requested_by_student_id, status)
         VALUES (?, ?, ?, 'pending')`,
        [student.alliance_id, building_id, student_id]);
    
    res.json({ success: true, message: `Request submitted for ${building.building_name}. Waiting for teacher approval.` });
  } catch (err) {
    console.error('Request building error:', err);
    res.status(500).json({ error: 'Failed to request building' });
  }
});

// Student: Get my alliance's building requests
app.get('/api/student/building-requests', authenticateToken, (req, res) => {
  try {
    const student_id = req.user.id;
    const student = query('SELECT alliance_id FROM students WHERE student_id = ?', [student_id])[0];
    
    if (!student || !student.alliance_id) {
      return res.json([]);
    }
    
    const requests = query(`
      SELECT 
        br.*,
        b.building_name,
        b.god_associated,
        b.cost_points
      FROM building_requests br
      JOIN buildings_ref b ON br.building_id = b.building_id
      WHERE br.alliance_id = ?
      ORDER BY br.requested_at DESC
    `, [student.alliance_id]);
    
    res.json(requests);
  } catch (err) {
    console.error('Get building requests error:', err);
    res.status(500).json({ error: 'Failed to fetch building requests' });
  }
});

// Teacher: Get all pending building requests
app.get('/api/teacher/building-requests', authenticateToken, (req, res) => {
  try {
    const requests = query(`
      SELECT 
        br.*,
        b.building_name,
        b.god_associated,
        b.cost_points,
        b.requires_god_assignment,
        a.alliance_name,
        a.total_points,
        a.class_period,
        s.name as requested_by_name
      FROM building_requests br
      JOIN buildings_ref b ON br.building_id = b.building_id
      JOIN alliances a ON br.alliance_id = a.alliance_id
      JOIN students s ON br.requested_by_student_id = s.student_id
      WHERE br.status = 'pending'
      ORDER BY br.requested_at ASC
    `);
    
    res.json(requests);
  } catch (err) {
    console.error('Get building requests error:', err);
    res.status(500).json({ error: 'Failed to fetch building requests' });
  }
});

// Teacher: Approve building request (grants god assignment + purchases building)
app.post('/api/teacher/approve-building-request', authenticateToken, (req, res) => {
  try {
    const { request_id } = req.body;
    const teacher_id = req.user.id;
    
    // Get request
    const request = query(`
      SELECT br.*, b.*, a.total_points, a.buildings_owned
      FROM building_requests br
      JOIN buildings_ref b ON br.building_id = b.building_id
      JOIN alliances a ON br.alliance_id = a.alliance_id
      WHERE br.request_id = ?
    `, [request_id])[0];
    
    if (!request) {
      return res.status(404).json({ error: 'Request not found' });
    }
    
    if (request.status !== 'pending') {
      return res.status(400).json({ error: 'Request already reviewed' });
    }
    
    // Check if alliance can afford
    if (request.total_points < request.cost_points) {
      return res.status(400).json({ error: `Alliance cannot afford this building. Needs ${request.cost_points} pts, has ${request.total_points} pts.` });
    }
    
    // Check prerequisites
    const ownedBuildings = JSON.parse(request.buildings_owned || '[]');
    if (request.prerequisite_building_id) {
      const prereq = query('SELECT building_name FROM buildings_ref WHERE building_id = ?', [request.prerequisite_building_id])[0];
      if (!ownedBuildings.includes(prereq.building_name)) {
        return res.status(400).json({ error: `Alliance needs ${prereq.building_name} first` });
      }
    }
    
    // Grant god assignment
    const existingAssignment = query(
      'SELECT * FROM god_assignments WHERE alliance_id = ? AND god_name = ?',
      [request.alliance_id, request.god_associated]
    );
    if (existingAssignment.length === 0) {
      run(`INSERT INTO god_assignments (alliance_id, god_name, completed_by_teacher_id)
           VALUES (?, ?, ?)`,
          [request.alliance_id, request.god_associated, teacher_id]);
    }
    
    // Purchase building
    ownedBuildings.push(request.building_name);
    run('UPDATE alliances SET total_points = total_points - ?, buildings_owned = ? WHERE alliance_id = ?',
        [request.cost_points, JSON.stringify(ownedBuildings), request.alliance_id]);
    
    // Log transaction
    run(`INSERT INTO point_transactions (alliance_id, student_id, amount, category, reason, teacher_id)
         VALUES (?, ?, ?, ?, ?, ?)`,
        [request.alliance_id, request.requested_by_student_id, -request.cost_points, 'Building Purchase', 
         `Purchased ${request.building_name} (approved request)`, teacher_id]);
    
    // Create activation record
    const owned = ownedBuildings.filter(b => b === request.building_name).length;
    run(`INSERT INTO building_activations (alliance_id, building_name, building_instance)
         VALUES (?, ?, ?)`,
        [request.alliance_id, request.building_name, owned]);
    
    // Update request status
    run(`UPDATE building_requests SET status = 'approved', reviewed_at = CURRENT_TIMESTAMP, reviewed_by_teacher_id = ?
         WHERE request_id = ?`,
        [teacher_id, request_id]);
    
    res.json({ 
      success: true, 
      message: `Approved! ${request.god_associated} assignment granted and ${request.building_name} purchased.`
    });
  } catch (err) {
    console.error('Approve building request error:', err);
    res.status(500).json({ error: 'Failed to approve request' });
  }
});

// Teacher: Reject building request
app.post('/api/teacher/reject-building-request', authenticateToken, (req, res) => {
  try {
    const { request_id, teacher_notes } = req.body;
    const teacher_id = req.user.id;
    
    const request = query('SELECT * FROM building_requests WHERE request_id = ?', [request_id])[0];
    if (!request) {
      return res.status(404).json({ error: 'Request not found' });
    }
    
    if (request.status !== 'pending') {
      return res.status(400).json({ error: 'Request already reviewed' });
    }
    
    run(`UPDATE building_requests 
         SET status = 'rejected', reviewed_at = CURRENT_TIMESTAMP, reviewed_by_teacher_id = ?, teacher_notes = ?
         WHERE request_id = ?`,
        [teacher_id, teacher_notes || 'Complete the required extra credit first', request_id]);
    
    res.json({ success: true, message: 'Request rejected' });
  } catch (err) {
    console.error('Reject building request error:', err);
    res.status(500).json({ error: 'Failed to reject request' });
  }
});

// ====================
// AGE PROGRESSION SYSTEM
// ====================

// Helper: Ensure age gate record exists for a period
function ensureAgeGate(class_period) {
  const existing = query('SELECT * FROM age_gates WHERE class_period = ?', [class_period]);
  if (existing.length === 0) {
    run('INSERT INTO age_gates (class_period) VALUES (?)', [class_period]);
  }
}

// Helper: Calculate age readiness for an alliance
function calculateAgeReadiness(alliance) {
  const ownedBuildings = JSON.parse(alliance.buildings_owned || '[]');
  const memberCount = query('SELECT COUNT(*) as count FROM students WHERE alliance_id = ?', [alliance.alliance_id])[0].count;
  
  // Required buildings for Classical Age (5 buildings)
  const requiredBuildings = ['Town Center', 'Library', 'House', 'Dock', 'Fishing Ship'];
  const ownedRequired = requiredBuildings.filter(b => ownedBuildings.includes(b));
  
  // Points threshold based on alliance size (reduced by 50 as discussed)
  const pointsThreshold = memberCount === 1 ? 100 : memberCount === 2 ? 200 : memberCount === 3 ? 300 : 400;
  
  // Calculate progress
  const buildingsProgress = (ownedRequired.length / requiredBuildings.length) * 100;
  const pointsProgress = Math.min(100, (alliance.total_points / pointsThreshold) * 100);
  const riteProgress = alliance.rite_of_passage_complete ? 100 : 0;
  const mapProgress = alliance.civilization_map_complete ? 100 : 0;
  
  // Overall progress (weighted average)
  const overallProgress = (buildingsProgress * 0.4 + pointsProgress * 0.3 + riteProgress * 0.15 + mapProgress * 0.15);
  
  const isReady = ownedRequired.length === requiredBuildings.length &&
                  alliance.total_points >= pointsThreshold &&
                  alliance.rite_of_passage_complete &&
                  alliance.civilization_map_complete;
  
  return {
    memberCount,
    pointsThreshold,
    pointsHave: alliance.total_points,
    pointsMet: alliance.total_points >= pointsThreshold,
    requiredBuildings,
    ownedRequired,
    buildingsMet: ownedRequired.length === requiredBuildings.length,
    riteComplete: alliance.rite_of_passage_complete === 1,
    mapComplete: alliance.civilization_map_complete === 1,
    overallProgress: Math.round(overallProgress),
    isReady
  };
}

// Student: Get age progress for their alliance
app.get('/api/student/age-progress', authenticateToken, (req, res) => {
  try {
    const student_id = req.user.id;
    const student = query('SELECT alliance_id, class_period FROM students WHERE student_id = ?', [student_id])[0];
    
    if (!student || !student.alliance_id) {
      return res.json({ error: 'Not in an alliance', hasAlliance: false });
    }
    
    let alliance = query('SELECT * FROM alliances WHERE alliance_id = ?', [student.alliance_id])[0];
    if (!alliance) {
      return res.json({ error: 'Alliance not found', hasAlliance: false });
    }
    
    // Check if any alliance member has uploaded a map - if so, mark alliance as complete
    if (!alliance.civilization_map_complete) {
      const memberWithMap = query(
        'SELECT student_id FROM students WHERE alliance_id = ? AND map_image IS NOT NULL AND map_image != ""',
        [student.alliance_id]
      );
      if (memberWithMap.length > 0) {
        run('UPDATE alliances SET civilization_map_complete = 1 WHERE alliance_id = ?', [student.alliance_id]);
        saveDatabase();
        // Refresh alliance data
        alliance = query('SELECT * FROM alliances WHERE alliance_id = ?', [student.alliance_id])[0];
        console.log('Auto-marked civilization_map_complete for alliance:', student.alliance_id);
      }
    }
    
    // Get age gate status for this period
    ensureAgeGate(student.class_period);
    const ageGate = query('SELECT * FROM age_gates WHERE class_period = ?', [student.class_period])[0];
    
    const readiness = calculateAgeReadiness(alliance);
    
    res.json({
      hasAlliance: true,
      currentAge: alliance.current_age,
      nextAge: alliance.current_age === 'Archaic' ? 'Classical' : alliance.current_age === 'Classical' ? 'Heroic' : null,
      gateOpen: alliance.current_age === 'Archaic' ? ageGate.classical_unlocked === 1 : 
                alliance.current_age === 'Classical' ? ageGate.heroic_unlocked === 1 : false,
      currentPoints: alliance.total_points,
      readiness,
      canAdvance: readiness.isReady && (
        (alliance.current_age === 'Archaic' && ageGate.classical_unlocked === 1) ||
        (alliance.current_age === 'Classical' && ageGate.heroic_unlocked === 1)
      )
    });
  } catch (err) {
    console.error('Get age progress error:', err);
    res.status(500).json({ error: 'Failed to fetch age progress' });
  }
});

// Student: Get available buildings for purchase (for map sidebar)
app.get('/api/student/available-buildings', authenticateToken, (req, res) => {
  try {
    const student_id = req.user.id;
    const student = query('SELECT alliance_id FROM students WHERE student_id = ?', [student_id])[0];
    
    if (!student || !student.alliance_id) {
      return res.json({ buildings: [], alliancePoints: 0, error: 'Not in an alliance' });
    }
    
    const alliance = query('SELECT total_points, buildings_owned, current_age FROM alliances WHERE alliance_id = ?', [student.alliance_id])[0];
    if (!alliance) {
      return res.json({ buildings: [], alliancePoints: 0, error: 'Alliance not found' });
    }
    
    const buildingsOwned = JSON.parse(alliance.buildings_owned || '[]');
    
    // Get all available buildings for current age
    const buildings = query(`
      SELECT * FROM buildings_ref 
      WHERE age_available = ?
      ORDER BY cost_points ASC
    `, [alliance.current_age]);
    
    // Count owned buildings
    const buildingsWithOwned = buildings.map(b => {
      const owned = buildingsOwned.filter(name => name === b.building_name).length;
      return {
        ...b,
        owned,
        icon: BUILDING_ICONS[b.building_name] || '🏛️'
      };
    });
    
    res.json({
      buildings: buildingsWithOwned,
      alliancePoints: alliance.total_points
    });
  } catch (err) {
    console.error('Get available buildings error:', err);
    res.status(500).json({ error: 'Failed to fetch buildings' });
  }
});

// Teacher: Get age gate status and alliance readiness for all periods
app.get('/api/teacher/age-gates', authenticateToken, (req, res) => {
  try {
    const periods = ['1st', '2nd', '3rd', '4th'];
    
    // Ensure all gates exist
    periods.forEach(p => ensureAgeGate(p));
    
    const gates = query('SELECT * FROM age_gates');
    const alliances = query('SELECT * FROM alliances WHERE is_disbanded = 0');
    
    // Calculate readiness for each alliance
    const alliancesWithReadiness = alliances.map(a => ({
      ...a,
      readiness: calculateAgeReadiness(a)
    }));
    
    // Group by period
    const byPeriod = periods.map(period => {
      const gate = gates.find(g => g.class_period === period) || { class_period: period, classical_unlocked: 0, heroic_unlocked: 0 };
      const periodAlliances = alliancesWithReadiness.filter(a => a.class_period === period);
      const readyCount = periodAlliances.filter(a => a.readiness.isReady).length;
      
      return {
        period,
        gate,
        alliances: periodAlliances,
        totalAlliances: periodAlliances.length,
        readyCount
      };
    });
    
    res.json(byPeriod);
  } catch (err) {
    console.error('Get age gates error:', err);
    res.status(500).json({ error: 'Failed to fetch age gates' });
  }
});

// Teacher: Open age gate for a period
app.post('/api/teacher/open-age-gate', authenticateToken, (req, res) => {
  try {
    const { class_period, target_age } = req.body;
    const teacher_id = req.user.id;
    
    ensureAgeGate(class_period);
    
    if (target_age === 'Classical') {
      run(`UPDATE age_gates SET classical_unlocked = 1, classical_unlocked_at = CURRENT_TIMESTAMP, classical_unlocked_by = ?
           WHERE class_period = ?`, [teacher_id, class_period]);
      
      // Automatically advance ready alliances
      const alliances = query('SELECT * FROM alliances WHERE class_period = ? AND current_age = ? AND is_disbanded = 0', 
                              [class_period, 'Archaic']);
      
      let advancedCount = 0;
      alliances.forEach(alliance => {
        const readiness = calculateAgeReadiness(alliance);
        if (readiness.isReady) {
          run('UPDATE alliances SET current_age = ? WHERE alliance_id = ?', ['Classical', alliance.alliance_id]);
          advancedCount++;
        }
      });
      
      res.json({ 
        success: true, 
        message: `Classical Age gate opened for ${class_period} period! ${advancedCount} alliance(s) advanced.`
      });
    } else if (target_age === 'Heroic') {
      run(`UPDATE age_gates SET heroic_unlocked = 1, heroic_unlocked_at = CURRENT_TIMESTAMP, heroic_unlocked_by = ?
           WHERE class_period = ?`, [teacher_id, class_period]);
      
      res.json({ success: true, message: `Heroic Age gate opened for ${class_period} period!` });
    } else {
      res.status(400).json({ error: 'Invalid target age' });
    }
  } catch (err) {
    console.error('Open age gate error:', err);
    res.status(500).json({ error: 'Failed to open age gate' });
  }
});

// Teacher: Mark alliance Rite of Passage complete
app.post('/api/teacher/mark-rite-complete', authenticateToken, (req, res) => {
  try {
    const { alliance_id, complete } = req.body;
    
    run('UPDATE alliances SET rite_of_passage_complete = ? WHERE alliance_id = ?', 
        [complete ? 1 : 0, alliance_id]);
    
    // Check if alliance can now advance
    const alliance = query('SELECT * FROM alliances WHERE alliance_id = ?', [alliance_id])[0];
    const readiness = calculateAgeReadiness(alliance);
    
    ensureAgeGate(alliance.class_period);
    const gate = query('SELECT * FROM age_gates WHERE class_period = ?', [alliance.class_period])[0];
    
    // Auto-advance if ready and gate is open
    if (readiness.isReady && alliance.current_age === 'Archaic' && gate.classical_unlocked) {
      run('UPDATE alliances SET current_age = ? WHERE alliance_id = ?', ['Classical', alliance_id]);
      res.json({ success: true, message: 'Rite of Passage marked complete. Alliance advanced to Classical Age!' });
    } else {
      res.json({ success: true, message: `Rite of Passage ${complete ? 'marked complete' : 'unmarked'}` });
    }
  } catch (err) {
    console.error('Mark rite complete error:', err);
    res.status(500).json({ error: 'Failed to update rite status' });
  }
});

// Teacher: Reset all battle counts (for testing)
app.post('/api/teacher/reset-battle-counts', authenticateToken, (req, res) => {
  try {
    // battles_today is in arena_battle_stats, not students
    run('UPDATE arena_battle_stats SET battles_today = 0, last_battle_date = NULL');
    const count = query('SELECT COUNT(*) as c FROM arena_battle_stats')[0].c;
    console.log(`🔄 Reset battle counts for ${count} students`);
    saveDatabase();
    res.json({ success: true, message: `Reset battle counts for ${count} students` });
  } catch (err) {
    console.error('Reset battle counts error:', err);
    res.status(500).json({ error: 'Failed to reset battle counts' });
  }
});

// Teacher: Cleanup stuck battles
app.post('/api/teacher/cleanup-battles', authenticateToken, (req, res) => {
  try {
    // Cancel all pending and accepted battles (stuck in god selection)
    const stuck = query("SELECT * FROM arena_battles WHERE status IN ('pending', 'accepted')");
    
    run("UPDATE arena_battles SET status = 'cancelled' WHERE status IN ('pending', 'accepted')");
    
    console.log(`🧹 Cleaned up ${stuck.length} stuck battles`);
    saveDatabase();
    res.json({ success: true, message: `Cleaned up ${stuck.length} stuck/pending battles` });
  } catch (err) {
    console.error('Cleanup battles error:', err);
    res.status(500).json({ error: 'Failed to cleanup battles' });
  }
});

// Teacher: Mark alliance Map complete
app.post('/api/teacher/mark-map-complete', authenticateToken, (req, res) => {
  try {
    const { alliance_id, complete } = req.body;
    
    run('UPDATE alliances SET civilization_map_complete = ? WHERE alliance_id = ?', 
        [complete ? 1 : 0, alliance_id]);
    
    // Check if alliance can now advance
    const alliance = query('SELECT * FROM alliances WHERE alliance_id = ?', [alliance_id])[0];
    const readiness = calculateAgeReadiness(alliance);
    
    ensureAgeGate(alliance.class_period);
    const gate = query('SELECT * FROM age_gates WHERE class_period = ?', [alliance.class_period])[0];
    
    // Auto-advance if ready and gate is open
    if (readiness.isReady && alliance.current_age === 'Archaic' && gate.classical_unlocked) {
      run('UPDATE alliances SET current_age = ? WHERE alliance_id = ?', ['Classical', alliance_id]);
      res.json({ success: true, message: 'Map marked complete. Alliance advanced to Classical Age!' });
    } else {
      res.json({ success: true, message: `Civilization Map ${complete ? 'marked complete' : 'unmarked'}` });
    }
  } catch (err) {
    console.error('Mark map complete error:', err);
    res.status(500).json({ error: 'Failed to update map status' });
  }
});

// ====================
// BUILDING ACTIVATION SYSTEM
// ====================

// Get alliance building activations
app.get('/api/alliance/activations/:alliance_id', authenticateToken, (req, res) => {
  try {
    const { alliance_id } = req.params;
    
    const activations = query(`
      SELECT 
        ba.*,
        br.point_bonus,
        br.battle_bonus,
        br.active_duration_hours,
        br.cooldown_hours,
        br.always_active,
        br.description
      FROM building_activations ba
      JOIN buildings_ref br ON ba.building_name = br.building_name
      WHERE ba.alliance_id = ?
      ORDER BY ba.building_name, ba.building_instance
    `, [alliance_id]);
    
    const now = new Date();
    
    // Calculate status for each building
    const activationsWithStatus = activations.map(a => {
      // Always active buildings (walls)
      if (a.always_active) {
        return { ...a, status: 'always_active', bonus_active: true };
      }
      
      const activeUntil = a.active_until ? new Date(a.active_until) : null;
      const cooldownUntil = a.cooldown_until ? new Date(a.cooldown_until) : null;
      
      let status = 'ready';
      let hoursRemaining = 0;
      let bonusActive = false;
      
      if (activeUntil && now < activeUntil) {
        status = 'active';
        hoursRemaining = Math.ceil((activeUntil - now) / (1000 * 60 * 60));
        bonusActive = true;
      } else if (cooldownUntil && now < cooldownUntil) {
        status = 'cooldown';
        hoursRemaining = Math.ceil((cooldownUntil - now) / (1000 * 60 * 60));
        bonusActive = false;
      }
      
      return { ...a, status, hours_remaining: hoursRemaining, bonus_active: bonusActive };
    });
    
    // Calculate total active bonus
    const totalBonus = activationsWithStatus
      .filter(a => a.bonus_active)
      .reduce((sum, a) => sum + (a.point_bonus || 0), 0);
    
    res.json({
      activations: activationsWithStatus,
      total_active_bonus: totalBonus,
      total_active_bonus_percent: Math.round(totalBonus * 100)
    });
  } catch (err) {
    console.error('Get activations error:', err);
    res.status(500).json({ error: 'Failed to fetch activations' });
  }
});

// Activate a building
app.post('/api/alliance/activate-building', authenticateToken, (req, res) => {
  try {
    const { activation_id } = req.body;
    const student_id = req.user.id;
    
    // Get the activation record
    const activation = query(`
      SELECT ba.*, br.active_duration_hours, br.cooldown_hours, br.always_active, br.point_bonus
      FROM building_activations ba
      JOIN buildings_ref br ON ba.building_name = br.building_name
      WHERE ba.activation_id = ?
    `, [activation_id])[0];
    
    if (!activation) {
      return res.status(404).json({ error: 'Building activation not found' });
    }
    
    // Verify student is in this alliance
    const student = query('SELECT alliance_id FROM students WHERE student_id = ?', [student_id])[0];
    if (!student || student.alliance_id !== activation.alliance_id) {
      return res.status(403).json({ error: 'You can only activate buildings for your own alliance' });
    }
    
    // Check if always active (walls)
    if (activation.always_active) {
      return res.status(400).json({ error: 'This building is always active' });
    }
    
    // Check if already active or on cooldown
    const now = new Date();
    const activeUntil = activation.active_until ? new Date(activation.active_until) : null;
    const cooldownUntil = activation.cooldown_until ? new Date(activation.cooldown_until) : null;
    
    if (activeUntil && now < activeUntil) {
      return res.status(400).json({ error: 'Building is already active' });
    }
    
    if (cooldownUntil && now < cooldownUntil) {
      const hoursLeft = Math.ceil((cooldownUntil - now) / (1000 * 60 * 60));
      return res.status(400).json({ error: `Building is on cooldown. ${hoursLeft} hours remaining.` });
    }
    
    // Activate the building
    const newActiveUntil = new Date(now.getTime() + activation.active_duration_hours * 60 * 60 * 1000);
    const newCooldownUntil = new Date(newActiveUntil.getTime() + activation.cooldown_hours * 60 * 60 * 1000);
    
    run(`UPDATE building_activations 
         SET activated_at = ?, active_until = ?, cooldown_until = ?, activated_by_student_id = ?
         WHERE activation_id = ?`,
        [now.toISOString(), newActiveUntil.toISOString(), newCooldownUntil.toISOString(), student_id, activation_id]);
    
    const bonusPercent = Math.round(activation.point_bonus * 100);
    
    res.json({ 
      success: true, 
      message: `${activation.building_name} activated! +${bonusPercent}% bonus for ${activation.active_duration_hours} hours.`,
      active_until: newActiveUntil,
      cooldown_until: newCooldownUntil
    });
  } catch (err) {
    console.error('Activate building error:', err);
    res.status(500).json({ error: 'Failed to activate building' });
  }
});

// Get current total bonus for an alliance (used when awarding points)
function getAllianceBuildingBonus(alliance_id) {
  const activations = query(`
    SELECT ba.*, br.point_bonus, br.always_active
    FROM building_activations ba
    JOIN buildings_ref br ON ba.building_name = br.building_name
    WHERE ba.alliance_id = ?
  `, [alliance_id]);
  
  const now = new Date();
  let totalBonus = 0;
  
  activations.forEach(a => {
    if (a.always_active) {
      // Walls don't give point bonuses, only battle bonuses
      return;
    }
    
    const activeUntil = a.active_until ? new Date(a.active_until) : null;
    if (activeUntil && now < activeUntil) {
      totalBonus += a.point_bonus || 0;
    }
  });
  
  return totalBonus;
}

// ====================
// PHASE 2: FATE WHEEL & BATTLES
// ====================

// Spin Fate Wheel
// Get Fate Choices
app.get('/api/teacher/fate-choices/:fate_id', authenticateToken, (req, res) => {
  try {
    const { fate_id } = req.params;
    
    console.log(`🎲 Requesting choices for fate_id: ${fate_id}`);
    
    // First check if the fate exists
    const fate = query('SELECT * FROM fates_ref WHERE fate_id = ?', [fate_id]);
    if (fate.length === 0) {
      console.error(`❌ Fate ${fate_id} does NOT exist in fates_ref!`);
      return res.status(404).json({ error: `Fate ${fate_id} not found` });
    }
    console.log(`✅ Fate exists: ${fate[0].fate_name}`);
    
    // Now get choices
    const choices = query(`
      SELECT * FROM fate_choices 
      WHERE fate_id = ? 
      ORDER BY CASE risk_level 
        WHEN 'conservative' THEN 1
        WHEN 'moderate' THEN 2  
        WHEN 'aggressive' THEN 3
      END
    `, [fate_id]);
    
    console.log(`📊 Found ${choices.length} choices for fate ${fate_id}`);
    
    if (choices.length === 0) {
      console.error(`❌ NO CHOICES found for fate_id ${fate_id}!`);
      console.error(`   Check: SELECT * FROM fate_choices WHERE fate_id = ${fate_id}`);
    }
    
    res.json(choices);
  } catch (err) {
    console.error('Get fate choices error:', err);
    res.status(500).json({ error: 'Failed to get fate choices', details: err.message });
  }
});

// Process Fate Choice
app.post('/api/teacher/process-fate-choice', authenticateToken, (req, res) => {
  try {
    const { alliance_id, fate_id, choice_id } = req.body;
    const teacher_id = req.user.id;
    
    // Get fate details
    const fate = query('SELECT * FROM fates_ref WHERE fate_id = ?', [fate_id])[0];
    if (!fate) {
      return res.status(404).json({ error: 'Fate not found' });
    }
    
    // Get choice details
    const choice = query('SELECT * FROM fate_choices WHERE choice_id = ?', [choice_id])[0];
    if (!choice || choice.fate_id !== fate_id) {
      return res.status(404).json({ error: 'Choice not found' });
    }
    
    // Get alliance details
    const alliance = query('SELECT * FROM alliances WHERE alliance_id = ?', [alliance_id])[0];
    if (!alliance) {
      return res.status(404).json({ error: 'Alliance not found' });
    }
    
    // Roll the dice!
    const roll = Math.random();
    const success = roll < choice.success_chance;
    const pointsChange = success ? choice.success_points : choice.failure_points;
    
    // Fates do NOT get building bonuses - apply points directly
    run('UPDATE alliances SET total_points = total_points + ? WHERE alliance_id = ?', 
        [pointsChange, alliance_id]);
    
    run(`INSERT INTO point_transactions (alliance_id, amount, category, reason, teacher_id) 
         VALUES (?, ?, ?, ?, ?)`, 
        [alliance_id, pointsChange, 'fate', `Fate: ${fate.fate_name} (${choice.risk_level} choice - ${success ? 'success' : 'failure'})`, teacher_id]);
    
    // Log the fate outcome
    run(`INSERT INTO fate_outcomes (alliance_id, fate_id, outcome_type, choice_made, points_awarded) 
         VALUES (?, ?, ?, ?, ?)`, 
        [alliance_id, fate_id, success ? 'success' : 'failure', choice.risk_level, pointsChange]);
    
    // Log the fate spin
    run(`INSERT INTO fate_spins (alliance_id, fate_id, fate_name, result_type, points_change, teacher_id) 
         VALUES (?, ?, ?, ?, ?, ?)`, 
        [alliance_id, fate_id, fate.fate_name, 'choice', pointsChange, teacher_id]);
    
    // Get updated alliance
    const updatedAlliance = query('SELECT * FROM alliances WHERE alliance_id = ?', [alliance_id])[0];
    
    res.json({
      success,
      pointsChange,
      choice,
      fate,
      updatedAlliance,
      roll: (roll * 100).toFixed(1) // Return roll percentage for display
    });
  } catch (err) {
    console.error('Process fate choice error:', err);
    res.status(500).json({ error: 'Failed to process fate choice' });
  }
});

// Check if alliance has reverse card
app.get('/api/teacher/check-reverse-card/:alliance_id', authenticateToken, (req, res) => {
  try {
    const { alliance_id } = req.params;
    const alliance = query('SELECT reverse_cards FROM alliances WHERE alliance_id = ?', [alliance_id])[0];
    
    if (!alliance) {
      return res.status(404).json({ error: 'Alliance not found' });
    }
    
    const cardCount = alliance.reverse_cards || 0;
    res.json({
      hasCard: cardCount > 0,
      cardCount
    });
  } catch (err) {
    console.error('Check reverse card error:', err);
    res.status(500).json({ error: 'Failed to check reverse card' });
  }
});

// Award reverse card to alliance
app.post('/api/teacher/award-reverse-card/:alliance_id', authenticateToken, (req, res) => {
  try {
    const { alliance_id } = req.params;
    
    // Add one reverse card
    run('UPDATE alliances SET reverse_cards = COALESCE(reverse_cards, 0) + 1 WHERE alliance_id = ?', [alliance_id]);
    
    const alliance = query('SELECT * FROM alliances WHERE alliance_id = ?', [alliance_id])[0];
    
    res.json({
      success: true,
      message: 'Reverse card awarded!',
      cardCount: alliance.reverse_cards
    });
  } catch (err) {
    console.error('Award reverse card error:', err);
    res.status(500).json({ error: 'Failed to award reverse card' });
  }
});

// Use reverse card
app.post('/api/teacher/use-reverse-card/:alliance_id', authenticateToken, (req, res) => {
  try {
    const { alliance_id } = req.params;
    
    // Remove one reverse card
    run('UPDATE alliances SET reverse_cards = COALESCE(reverse_cards, 0) - 1 WHERE alliance_id = ? AND reverse_cards > 0', [alliance_id]);
    
    const alliance = query('SELECT * FROM alliances WHERE alliance_id = ?', [alliance_id])[0];
    
    res.json({
      success: true,
      message: 'Reverse card used!',
      cardCount: alliance.reverse_cards
    });
  } catch (err) {
    console.error('Use reverse card error:', err);
    res.status(500).json({ error: 'Failed to use reverse card' });
  }
});

app.post('/api/teacher/spin-fate', authenticateToken, (req, res) => {
  try {
    const { alliance_id, fate_id } = req.body;
    const teacher_id = req.user.id;
    
    // Get fate details
    const fate = query('SELECT * FROM fates_ref WHERE fate_id = ?', [fate_id])[0];
    if (!fate) {
      return res.status(404).json({ error: 'Fate not found' });
    }
    
    // Get alliance details
    const alliance = query('SELECT * FROM alliances WHERE alliance_id = ?', [alliance_id])[0];
    if (!alliance) {
      return res.status(404).json({ error: 'Alliance not found' });
    }
    
    let result = {
      fate,
      alliance,
      pointsChange: 0,
      resultType: fate.fate_type
    };
    
    // Process fate based on type
    if (fate.fate_type === 'simple_points') {
      // Simple point addition/subtraction
      const pointsChange = fate.point_effect || 0;
      run('UPDATE alliances SET total_points = total_points + ? WHERE alliance_id = ?', 
          [pointsChange, alliance_id]);
      
      run(`INSERT INTO point_transactions (alliance_id, amount, category, reason, teacher_id) 
           VALUES (?, ?, ?, ?, ?)`, 
          [alliance_id, pointsChange, 'fate', `Fate: ${fate.fate_name}`, teacher_id]);
      
      result.pointsChange = pointsChange;
    } 
    else if (fate.fate_type === 'interactive') {
      // Steals from or gives to other alliances
      const allAlliances = query('SELECT alliance_id, total_points FROM alliances WHERE alliance_id != ?', [alliance_id]);
      const transferAmount = fate.transfer_amount || 0;
      
      if (fate.steals_from_others) {
        // This alliance gains from each other alliance
        const totalGain = transferAmount * allAlliances.length;
        run('UPDATE alliances SET total_points = total_points + ? WHERE alliance_id = ?', 
            [totalGain, alliance_id]);
        
        allAlliances.forEach(other => {
          run('UPDATE alliances SET total_points = total_points - ? WHERE alliance_id = ?', 
              [transferAmount, other.alliance_id]);
          run(`INSERT INTO point_transactions (alliance_id, amount, category, reason, teacher_id) 
               VALUES (?, ?, ?, ?, ?)`, 
              [other.alliance_id, -transferAmount, 'fate', `Fate: ${fate.fate_name} (stolen by ${alliance.alliance_name})`, teacher_id]);
        });
        
        run(`INSERT INTO point_transactions (alliance_id, amount, category, reason, teacher_id) 
             VALUES (?, ?, ?, ?, ?)`, 
            [alliance_id, totalGain, 'fate', `Fate: ${fate.fate_name} (stole from each alliance)`, teacher_id]);
        
        result.pointsChange = totalGain;
      } 
      else if (fate.gives_to_others) {
        // This alliance loses to each other alliance
        const totalLoss = transferAmount * allAlliances.length;
        run('UPDATE alliances SET total_points = total_points - ? WHERE alliance_id = ?', 
            [totalLoss, alliance_id]);
        
        allAlliances.forEach(other => {
          run('UPDATE alliances SET total_points = total_points + ? WHERE alliance_id = ?', 
              [transferAmount, other.alliance_id]);
          run(`INSERT INTO point_transactions (alliance_id, amount, category, reason, teacher_id) 
               VALUES (?, ?, ?, ?, ?)`, 
              [other.alliance_id, transferAmount, 'fate', `Fate: ${fate.fate_name} (gift from ${alliance.alliance_name})`, teacher_id]);
        });
        
        run(`INSERT INTO point_transactions (alliance_id, amount, category, reason, teacher_id) 
             VALUES (?, ?, ?, ?, ?)`, 
            [alliance_id, -totalLoss, 'fate', `Fate: ${fate.fate_name} (gave to each alliance)`, teacher_id]);
        
        result.pointsChange = -totalLoss;
      }
    }
    else if (fate.fate_type === 'battle') {
      // Battle will be handled by separate endpoint
      result.needsBattle = true;
      result.battleInfo = {
        threatPercent: fate.battle_threat_percent,
        winPoints: fate.battle_win_points,
        losePoints: fate.battle_lose_points,
        description: fate.battle_description
      };
    }
    else if (fate.fate_type === 'special') {
      // Special fates (Countdown, Reverse Card) handled manually by teacher
      result.specialInstructions = fate.description;
    }
    
    // Log the fate spin
    run(`INSERT INTO fate_spins (alliance_id, fate_id, fate_name, result_type, points_change, teacher_id) 
         VALUES (?, ?, ?, ?, ?, ?)`, 
        [alliance_id, fate_id, fate.fate_name, fate.fate_type, result.pointsChange, teacher_id]);
    
    // Get updated alliance
    const updatedAlliance = query('SELECT * FROM alliances WHERE alliance_id = ?', [alliance_id])[0];
    result.updatedAlliance = updatedAlliance;
    
    res.json(result);
  } catch (err) {
    console.error('Spin fate error:', err);
    res.status(500).json({ error: 'Failed to spin fate' });
  }
});

// Roll Battle
app.post('/api/teacher/roll-battle', authenticateToken, (req, res) => {
  try {
    const { alliance_id, fate_id } = req.body;
    const teacher_id = req.user.id;
    
    // Get alliance
    const alliance = query('SELECT * FROM alliances WHERE alliance_id = ?', [alliance_id])[0];
    if (!alliance) {
      return res.status(404).json({ error: 'Alliance not found' });
    }
    
    // Get fate for battle info
    const fate = query('SELECT * FROM fates_ref WHERE fate_id = ?', [fate_id])[0];
    if (!fate || !fate.is_battle) {
      return res.status(400).json({ error: 'Not a battle fate' });
    }
    
    // Use fate.fate_name instead of req.body.fate_name
    const fate_name = fate.fate_name;
    
    // Calculate alliance power (with bonuses)
    let alliancePower = alliance.total_points;
    
    // Apply technology bonuses (multiplicative)
    const members = query('SELECT student_id, technologies_unlocked FROM students WHERE alliance_id = ?', [alliance_id]);
    let techMultiplier = 1.0;
    members.forEach(member => {
      const techs = JSON.parse(member.technologies_unlocked || '[]');
      const techDetails = query(`SELECT bonus_value, bonus_type FROM technologies_ref WHERE tech_name IN (${techs.map(() => '?').join(',')})`, techs);
      
      techDetails.forEach(tech => {
        if (tech.bonus_type === 'earning_multiplier') {
          techMultiplier *= (1 + tech.bonus_value);
        }
      });
    });
    
    alliancePower = Math.floor(alliancePower * techMultiplier);
    
    // Apply building bonuses (additive) - track for display
    const buildingsOwned = JSON.parse(alliance.buildings_owned || '[]');
    let wallBonus = 0;
    let wallType = null;
    
    if (buildingsOwned.includes('Stone Wall')) {
      wallBonus = 100;
      wallType = 'Stone Wall';
      alliancePower += 100;
    } else if (buildingsOwned.includes('Wooden Wall')) {
      wallBonus = 50;
      wallType = 'Wooden Wall';
      alliancePower += 50;
    }
    
    // Get all alliances to determine underdog status
    const allAlliances = query('SELECT alliance_id, total_points FROM alliances WHERE is_disbanded = 0 ORDER BY total_points DESC');
    
    // Calculate threat power based on CURRENT ALLIANCE's points (80% of their own points)
    const threatPercent = fate.battle_threat_percent || 0.80;
    const threatPower = Math.floor(alliance.total_points * threatPercent);
    
    // Apply Underdog Blessing (bottom team in each class period gets +25% power boost)
    // Get alliances in same period, sorted by points ascending (lowest first)
    const periodAlliances = query(
      'SELECT alliance_id, total_points FROM alliances WHERE class_period = ? AND is_disbanded = 0 ORDER BY total_points ASC',
      [alliance.class_period]
    );
    
    // Bottom team in the period is the first one (lowest points)
    const isUnderdog = periodAlliances.length > 0 && periodAlliances[0].alliance_id === alliance_id;
    
    if (isUnderdog) {
      alliancePower = Math.floor(alliancePower * 1.25);
    }
    
    // Update underdog blessing status
    run('UPDATE alliances SET underdog_blessing = ? WHERE alliance_id = ?', 
        [isUnderdog ? 1 : 0, alliance_id]);
    
    // Roll dice
    const allianceRoll = Math.floor(Math.random() * (alliancePower + 1));
    const threatRoll = Math.floor(Math.random() * (threatPower + 1));
    
    // Determine victory
    const victory = allianceRoll > threatRoll;
    const pointsChange = victory ? fate.battle_win_points : fate.battle_lose_points;
    
    // Apply points
    run('UPDATE alliances SET total_points = total_points + ? WHERE alliance_id = ?', 
        [pointsChange, alliance_id]);
    
    // Log transaction
    const battleResult = victory ? 'Victory' : 'Defeat';
    run(`INSERT INTO point_transactions (alliance_id, amount, category, reason, teacher_id) 
         VALUES (?, ?, ?, ?, ?)`, 
        [alliance_id, pointsChange, 'battle', `Battle ${battleResult}: ${fate_name}`, teacher_id]);
    
    // Log battle
    run(`INSERT INTO battle_events (alliance_id, fate_name, alliance_power, threat_power, alliance_roll, threat_roll, victory, points_change, teacher_id) 
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`, 
        [alliance_id, fate_name, alliancePower, threatPower, allianceRoll, threatRoll, victory ? 1 : 0, pointsChange, teacher_id]);
    
    // Get updated alliance
    const updatedAlliance = query('SELECT * FROM alliances WHERE alliance_id = ?', [alliance_id])[0];
    
    res.json({
      victory,
      alliancePower,
      basePower: alliance.total_points,
      wallBonus,
      wallType,
      threatPower,
      allianceRoll,
      threatRoll,
      pointsChange,
      updatedAlliance,
      isUnderdog,
      leaderPoints
    });
  } catch (err) {
    console.error('Roll battle error:', err);
    res.status(500).json({ error: 'Failed to roll battle' });
  }
});

// Get today's fate spins
app.get('/api/teacher/fates-today', authenticateToken, (req, res) => {
  try {
    const today = new Date().toISOString().split('T')[0];
    const spins = query(`
      SELECT 
        fs.*,
        a.alliance_name
      FROM fate_spins fs
      JOIN alliances a ON fs.alliance_id = a.alliance_id
      WHERE DATE(fs.spun_at) = ?
      ORDER BY fs.spun_at DESC
    `, [today]);
    
    res.json(spins);
  } catch (err) {
    console.error('Get fates today error:', err);
    res.status(500).json({ error: 'Failed to get fate spins' });
  }
});

// Get all fates for wheel
app.get('/api/teacher/fates', authenticateToken, (req, res) => {
  try {
    const age = req.query.age || 'Archaic';
    const fates = query('SELECT * FROM fates_ref WHERE age_available = ? ORDER BY fate_number', [age]);
    res.json(fates);
  } catch (err) {
    console.error('Get fates error:', err);
    res.status(500).json({ error: 'Failed to get fates' });
  }
});

// Get student personal contributions
app.get('/api/student/my-contributions', authenticateToken, (req, res) => {
  try {
    const student_id = req.user.id;
    
    // Get student's alliance
    const student = query('SELECT alliance_id FROM students WHERE student_id = ?', [student_id])[0];
    
    if (!student || !student.alliance_id) {
      return res.json({
        contributions: [],
        totalContribution: 0,
        allianceTotal: 0
      });
    }
    
    const alliance_id = student.alliance_id;
    
    // Get all transactions: personal + alliance-wide (fates/battles)
    const contributions = query(`
      SELECT 
        pt.amount,
        pt.category,
        pt.reason,
        pt.timestamp,
        pt.student_id,
        CASE 
          WHEN pt.student_id = ? THEN 'personal'
          ELSE 'alliance'
        END as source
      FROM point_transactions pt
      WHERE (pt.student_id = ? OR (pt.alliance_id = ? AND pt.student_id IS NULL))
      ORDER BY pt.timestamp DESC
      LIMIT 50
    `, [student_id, student_id, alliance_id]);
    
    // Get total personal contribution (only this student's)
    const personalTotal = query(`
      SELECT SUM(amount) as total
      FROM point_transactions
      WHERE student_id = ?
    `, [student_id])[0];
    
    // Get alliance total
    const alliance = query('SELECT total_points FROM alliances WHERE alliance_id = ?', [alliance_id])[0];
    
    res.json({
      contributions,
      totalContribution: personalTotal.total || 0,
      allianceTotal: alliance.total_points || 0
    });
  } catch (err) {
    console.error('Get contributions error:', err);
    res.status(500).json({ error: 'Failed to get contributions' });
  }
});

// ====================
// SIDE QUEST SYSTEM
// ====================

// Get all side quests with student's completion status
app.get('/api/student/side-quests', authenticateToken, (req, res) => {
  try {
    const student_id = req.user.id;
    const student = query('SELECT alliance_id FROM students WHERE student_id = ?', [student_id])[0];
    
    if (!student || !student.alliance_id) {
      return res.json({ error: 'Not in an alliance', hasAlliance: false, quests: [] });
    }
    
    // Get all side quests
    const quests = query('SELECT * FROM side_quests_ref ORDER BY quest_id');
    
    // Get this student's completions
    const myCompletions = query(
      'SELECT quest_id, status FROM side_quest_completions WHERE student_id = ?',
      [student_id]
    );
    const myCompletionMap = {};
    myCompletions.forEach(c => { myCompletionMap[c.quest_id] = c.status; });
    
    // Get all alliance members
    const allianceMembers = query(
      'SELECT student_id, name FROM students WHERE alliance_id = ?',
      [student.alliance_id]
    );
    const memberCount = allianceMembers.length;
    
    // Get alliance completions for each quest
    const questsWithStatus = quests.map(quest => {
      // Get all approved completions for this quest in this alliance
      const approvedCompletions = query(
        `SELECT sqc.student_id, s.name 
         FROM side_quest_completions sqc
         JOIN students s ON sqc.student_id = s.student_id
         WHERE sqc.quest_id = ? AND sqc.alliance_id = ? AND sqc.status = 'approved'`,
        [quest.quest_id, student.alliance_id]
      );
      
      const pendingCompletions = query(
        `SELECT sqc.student_id, s.name 
         FROM side_quest_completions sqc
         JOIN students s ON sqc.student_id = s.student_id
         WHERE sqc.quest_id = ? AND sqc.alliance_id = ? AND sqc.status = 'pending'`,
        [quest.quest_id, student.alliance_id]
      );
      
      const completedCount = approvedCompletions.length;
      const allComplete = completedCount === memberCount;
      
      // Check if alliance has earned this reward
      const rewardEarned = allComplete;
      
      return {
        ...quest,
        my_status: myCompletionMap[quest.quest_id] || 'not_started',
        completed_members: approvedCompletions.map(c => c.name),
        pending_members: pendingCompletions.map(c => c.name),
        completed_count: completedCount,
        member_count: memberCount,
        all_complete: allComplete,
        reward_earned: rewardEarned
      };
    });
    
    // Get alliance's earned technologies
    const earnedTechs = query(
      'SELECT tech_name FROM alliance_technologies WHERE alliance_id = ?',
      [student.alliance_id]
    ).map(t => t.tech_name);
    
    res.json({
      hasAlliance: true,
      quests: questsWithStatus,
      earned_technologies: earnedTechs,
      alliance_members: allianceMembers.map(m => m.name)
    });
  } catch (err) {
    console.error('Get side quests error:', err);
    res.status(500).json({ error: 'Failed to fetch side quests' });
  }
});

// Student: Submit side quest completion for approval
app.post('/api/student/submit-side-quest', authenticateToken, (req, res) => {
  try {
    const { quest_id } = req.body;
    const student_id = req.user.id;
    
    console.log('Student submitting side quest:', { student_id, quest_id });
    
    const student = query('SELECT alliance_id, name FROM students WHERE student_id = ?', [student_id])[0];
    if (!student || !student.alliance_id) {
      return res.status(400).json({ error: 'You must be in an alliance to submit side quests' });
    }
    
    // Check if quest exists
    const quest = query('SELECT * FROM side_quests_ref WHERE quest_id = ?', [quest_id])[0];
    if (!quest) {
      console.log('Quest not found:', quest_id);
      return res.status(404).json({ error: 'Side quest not found' });
    }
    
    // Check if already submitted
    const existing = query(
      'SELECT * FROM side_quest_completions WHERE student_id = ? AND quest_id = ?',
      [student_id, quest_id]
    );
    if (existing.length > 0) {
      console.log('Already submitted:', existing[0]);
      return res.status(400).json({ error: 'You have already submitted this quest' });
    }
    
    // Create submission
    run(`INSERT INTO side_quest_completions (student_id, quest_id, alliance_id, status)
         VALUES (?, ?, ?, 'pending')`,
        [student_id, quest_id, student.alliance_id]);
    
    // Save database
    saveDatabase();
    
    console.log('Side quest submission created successfully');
    
    res.json({ 
      success: true, 
      message: `Quest completion submitted! Awaiting teacher approval.` 
    });
  } catch (err) {
    console.error('Submit side quest error:', err);
    res.status(500).json({ error: 'Failed to submit side quest' });
  }
});

// Teacher: Get pending side quest approvals
app.get('/api/teacher/side-quest-approvals', authenticateToken, (req, res) => {
  try {
    const teacher_id = req.user.id;
    const { period } = req.query;
    
    let pendingQuery = `
      SELECT sqc.*, sq.quest_name, sq.god_associated, sq.reward_name,
             s.name as student_name, s.class_period, a.alliance_name
      FROM side_quest_completions sqc
      JOIN side_quests_ref sq ON sqc.quest_id = sq.quest_id
      JOIN students s ON sqc.student_id = s.student_id
      JOIN alliances a ON sqc.alliance_id = a.alliance_id
      WHERE sqc.status = 'pending'
    `;
    
    if (period && period !== 'all') {
      pendingQuery += ` AND s.class_period = '${period}'`;
    }
    
    pendingQuery += ' ORDER BY sqc.submitted_at DESC';
    
    const pending = query(pendingQuery);
    
    res.json({ pending });
  } catch (err) {
    console.error('Get side quest approvals error:', err);
    res.status(500).json({ error: 'Failed to fetch side quest approvals' });
  }
});

// Teacher: Approve side quest completion
app.post('/api/teacher/approve-side-quest', authenticateToken, (req, res) => {
  try {
    const { completion_id } = req.body;
    const teacher_id = req.user.id;
    
    console.log('Approving side quest completion:', completion_id);
    
    const completion = query('SELECT * FROM side_quest_completions WHERE completion_id = ?', [completion_id])[0];
    if (!completion) {
      return res.status(404).json({ error: 'Completion not found' });
    }
    
    console.log('Completion found:', completion);
    
    if (completion.status !== 'pending') {
      return res.status(400).json({ error: `Completion already reviewed (status: ${completion.status})` });
    }
    
    // Approve the completion
    run(`UPDATE side_quest_completions 
         SET status = 'approved', reviewed_at = CURRENT_TIMESTAMP, reviewed_by_teacher_id = ?
         WHERE completion_id = ?`,
        [teacher_id, completion_id]);
    
    // Save to persist
    saveDatabase();
    
    // Check if ALL alliance members have now completed this quest
    const quest = query('SELECT * FROM side_quests_ref WHERE quest_id = ?', [completion.quest_id])[0];
    const allianceMembers = query('SELECT student_id FROM students WHERE alliance_id = ?', [completion.alliance_id]);
    const approvedCompletions = query(
      `SELECT * FROM side_quest_completions 
       WHERE quest_id = ? AND alliance_id = ? AND status = 'approved'`,
      [completion.quest_id, completion.alliance_id]
    );
    
    console.log(`Alliance members: ${allianceMembers.length}, Approved completions: ${approvedCompletions.length}`);
    
    let rewardGranted = false;
    if (approvedCompletions.length === allianceMembers.length) {
      // All members completed! Grant the reward
      const existingTech = query(
        'SELECT * FROM alliance_technologies WHERE alliance_id = ? AND tech_name = ?',
        [completion.alliance_id, quest.reward_name]
      );
      
      if (existingTech.length === 0) {
        run(`INSERT INTO alliance_technologies (alliance_id, tech_name, source_quest_id)
             VALUES (?, ?, ?)`,
            [completion.alliance_id, quest.reward_name, quest.quest_id]);
        saveDatabase();
        rewardGranted = true;
        console.log('Reward granted:', quest.reward_name);
      }
    }
    
    const student = query('SELECT name FROM students WHERE student_id = ?', [completion.student_id])[0];
    const alliance = query('SELECT alliance_name FROM alliances WHERE alliance_id = ?', [completion.alliance_id])[0];
    
    res.json({ 
      success: true, 
      message: `Approved ${student.name}'s completion of ${quest.quest_name}`,
      reward_granted: rewardGranted,
      reward_name: rewardGranted ? quest.reward_name : null
    });
  } catch (err) {
    console.error('Approve side quest error:', err);
    res.status(500).json({ error: 'Failed to approve side quest' });
  }
});

// Teacher: Reject side quest completion
app.post('/api/teacher/reject-side-quest', authenticateToken, (req, res) => {
  try {
    const { completion_id, teacher_notes } = req.body;
    const teacher_id = req.user.id;
    
    const completion = query('SELECT * FROM side_quest_completions WHERE completion_id = ?', [completion_id])[0];
    if (!completion) {
      return res.status(404).json({ error: 'Completion not found' });
    }
    
    if (completion.status !== 'pending') {
      return res.status(400).json({ error: 'Completion already reviewed' });
    }
    
    // Reject - delete the record so they can resubmit
    run('DELETE FROM side_quest_completions WHERE completion_id = ?', [completion_id]);
    
    res.json({ 
      success: true, 
      message: 'Side quest completion rejected. Student can resubmit.' 
    });
  } catch (err) {
    console.error('Reject side quest error:', err);
    res.status(500).json({ error: 'Failed to reject side quest' });
  }
});

// Get alliance technologies (for applying bonuses)
app.get('/api/alliance/technologies/:alliance_id', authenticateToken, (req, res) => {
  try {
    const { alliance_id } = req.params;
    
    const technologies = query(
      'SELECT * FROM alliance_technologies WHERE alliance_id = ?',
      [alliance_id]
    );
    
    res.json({ technologies });
  } catch (err) {
    console.error('Get alliance technologies error:', err);
    res.status(500).json({ error: 'Failed to fetch technologies' });
  }
});

// ====================
// BATTLE ARENA SYSTEM
// ====================

// BATTLE TIMING CONSTANTS (in milliseconds)
const BATTLE_TIMING = {
  DEPLOY_PHASE: 12000,    // God selection phase: 12 seconds
  QUESTION_PHASE: 20000,  // Question answering phase: 20 seconds
  RESULTS_PHASE: 5000,    // Results display phase: 5 seconds
  ANSWER_FEEDBACK: 3000,  // Time to show correct/wrong after answering: 3 seconds
  SYNC_DELAY: 2000,       // Delay after both ready before showing question/results: 2 seconds
  SUDDEN_DEATH_DEPLOY: 12000  // Sudden death god selection
};

// GOD POWERS CONFIGURATION
const GOD_POWERS = {
  // OFFENSIVE GODS
  zeus: {
    type: 'offensive',
    name: 'Lightning Strike',
    description: 'Screen flash blinds opponent',
    baseEffect: 2, // seconds
    bonusEffect: 3, // with 50% bonus
    counteredBy: 'hera',
    emoji: '⚡'
  },
  poseidon: {
    type: 'offensive',
    name: 'Tidal Wave',
    description: 'Answers swim around screen',
    baseEffect: 3,
    bonusEffect: 4.5,
    counteredBy: 'athena',
    emoji: '🔱'
  },
  ares: {
    type: 'offensive',
    name: 'War Cry',
    description: 'Screen shake and loud sound',
    baseEffect: 2,
    bonusEffect: 3,
    counteredBy: 'aphrodite',
    emoji: '⚔️'
  },
  hades: {
    type: 'offensive',
    name: 'Darkness',
    description: 'Screen goes dark',
    baseEffect: 2,
    bonusEffect: 3,
    counteredBy: 'apollo',
    emoji: '💀'
  },
  hephaestus: {
    type: 'offensive',
    name: 'Forge Fire',
    description: 'Answers appear on fire (hard to read)',
    baseEffect: 2,
    bonusEffect: 3,
    counteredBy: 'artemis',
    emoji: '🔨'
  },
  hermes: {
    type: 'offensive',
    name: 'Speed Steal',
    description: 'Opponent clicks delayed',
    baseEffect: 1,
    bonusEffect: 1.5,
    counteredBy: 'demeter',
    emoji: '🪽'
  },
  // SPECIAL GOD
  prometheus: {
    type: 'special',
    name: 'Gift of Fire',
    description: 'See question early (once per day)',
    baseEffect: 2, // seconds early
    bonusEffect: 3,
    counteredBy: null, // cannot be blocked
    emoji: '🔥',
    oncePerDay: true
  },
  // DEFENSIVE GODS
  hera: {
    type: 'defensive',
    name: 'Queen\'s Shield',
    description: 'Blocks Zeus lightning',
    blocks: 'zeus',
    passive: 'Opponent\'s click delayed 1 sec',
    passiveEffect: 1,
    bonusPassiveEffect: 1.5,
    emoji: '🦚'
  },
  athena: {
    type: 'defensive',
    name: 'Wisdom',
    description: 'Blocks Poseidon wave',
    blocks: 'poseidon',
    passive: 'Remove 1 wrong answer',
    passiveEffect: 1, // answers removed
    bonusPassiveEffect: 2, // 50/50
    emoji: '🦉'
  },
  apollo: {
    type: 'defensive',
    name: 'Light of Truth',
    description: 'Blocks Hades darkness',
    blocks: 'hades',
    passive: 'Correct answer glows for 1 sec',
    passiveEffect: 1,
    bonusPassiveEffect: 1.5,
    emoji: '☀️'
  },
  artemis: {
    type: 'defensive',
    name: 'Hunter\'s Focus',
    description: 'Blocks Hephaestus fire',
    blocks: 'hephaestus',
    passive: 'Answer in first 5 sec = +0.5 battle score',
    passiveEffect: 0.5,
    bonusPassiveEffect: 0.75,
    emoji: '🏹'
  },
  aphrodite: {
    type: 'defensive',
    name: 'Charm',
    description: 'Blocks Ares war cry',
    blocks: 'ares',
    passive: 'If wrong, 3 sec to retry (if opponent hasn\'t won)',
    passiveEffect: 3,
    bonusPassiveEffect: 4.5,
    emoji: '💕'
  },
  demeter: {
    type: 'defensive',
    name: 'Harvest Shield',
    description: 'Blocks Hermes speed steal',
    blocks: 'hermes',
    passive: 'Enemy effects last 50% shorter',
    passiveEffect: 0.5, // multiplier
    bonusPassiveEffect: 0.25, // 75% shorter
    emoji: '🌾'
  }
};

// Helper function to check if student has god bonus completed
function hasGodBonus(student_id, godName) {
  try {
    const colName = `pantheon_${godName.toLowerCase()}_bonus_seen`;
    const progress = query(`SELECT ${colName} FROM student_achievement_progress WHERE student_id = ?`, [student_id])[0];
    return progress && progress[colName] === 1;
  } catch (err) {
    return false;
  }
}

// Helper function to check if student has god unlocked
function hasGodUnlocked(student_id, godName) {
  try {
    const colName = `pantheon_${godName.toLowerCase()}_unlocked`;
    const progress = query(`SELECT ${colName} FROM student_achievement_progress WHERE student_id = ?`, [student_id])[0];
    return progress && progress[colName] === 1;
  } catch (err) {
    return false;
  }
}

// Helper function to check if Prometheus was used today
function prometheusUsedToday(student_id) {
  const today = new Date().toISOString().split('T')[0];
  const stats = query('SELECT prometheus_used_date FROM arena_battle_stats WHERE student_id = ?', [student_id])[0];
  return stats && stats.prometheus_used_date === today;
}

// Helper function to count total battles today (as challenger OR defender)
function countBattlesToday(student_id) {
  const today = new Date().toISOString().split('T')[0];
  const result = query(`
    SELECT COUNT(*) as count FROM arena_battles 
    WHERE (challenger_id = ? OR defender_id = ?)
    AND status IN ('in_progress', 'completed')
    AND DATE(started_at) = ?
  `, [student_id, student_id, today])[0];
  return result ? result.count : 0;
}

// Maximum battles per student per day
const MAX_BATTLES_PER_DAY = 3;

// Get arena status - shows requirements clearly if not met
app.get('/api/arena/status', authenticateToken, (req, res) => {
  try {
    const student_id = req.user.id;
    
    // Get student info
    const student = query('SELECT * FROM students WHERE student_id = ?', [student_id])[0];
    if (!student) {
      return res.json({ 
        arena_unlocked: false, 
        reason: 'Student account not found',
        requirements: { hasAlliance: false, hasTownCenter: false, hasHouse: false }
      });
    }
    
    // Check alliance
    if (!student.alliance_id) {
      return res.json({ 
        arena_unlocked: false, 
        reason: 'You must join an alliance first to enter the Battle Arena.',
        requirements: { hasAlliance: false, hasTownCenter: false, hasHouse: false }
      });
    }
    
    const alliance = query('SELECT * FROM alliances WHERE alliance_id = ? AND is_disbanded = 0', [student.alliance_id])[0];
    if (!alliance) {
      return res.json({ 
        arena_unlocked: false, 
        reason: 'Your alliance was disbanded.',
        requirements: { hasAlliance: false, hasTownCenter: false, hasHouse: false }
      });
    }
    
    // Check buildings - handle both array format and string format
    let buildings = [];
    try {
      const rawBuildings = alliance.buildings_owned || '[]';
      buildings = typeof rawBuildings === 'string' ? JSON.parse(rawBuildings) : rawBuildings;
    } catch (e) {
      console.log('Building parse error:', e.message, 'Raw:', alliance.buildings_owned);
      buildings = [];
    }
    
    // Check for Town Center and House (handle different formats)
    const hasTownCenter = buildings.some(b => 
      (b.name === 'Town Center') || 
      (b.building_name === 'Town Center') ||
      (typeof b === 'string' && b.includes('Town Center'))
    );
    const hasHouse = buildings.some(b => 
      (b.name === 'House') || 
      (b.building_name === 'House') ||
      (typeof b === 'string' && b.includes('House'))
    );
    
    if (!hasTownCenter || !hasHouse) {
      return res.json({ 
        arena_unlocked: false, 
        reason: 'Your alliance needs to build a Town Center (175 pts) and a House (40 pts) to unlock the Battle Arena.',
        requirements: { 
          hasAlliance: true, 
          hasTownCenter, 
          hasHouse,
          allianceName: alliance.alliance_name,
          alliancePoints: alliance.total_points
        }
      });
    }
    
    // Arena is unlocked! Check if enabled
    const globalSetting = query("SELECT setting_value FROM arena_settings WHERE setting_type = 'global' AND setting_key = 'enabled'")[0];
    const arenaEnabled = !globalSetting || globalSetting.setting_value !== 'false';
    
    if (!arenaEnabled) {
      return res.json({
        arena_unlocked: true,
        arena_enabled: false,
        reason: 'The Battle Arena is currently disabled by your teacher.'
      });
    }
    
    // Check per-student disable
    const studentSetting = query("SELECT setting_value FROM arena_settings WHERE setting_type = 'student' AND setting_key = ?", [String(student_id)])[0];
    if (studentSetting && studentSetting.setting_value === 'false') {
      return res.json({
        arena_unlocked: true,
        arena_enabled: false,
        reason: 'Your access to the Battle Arena has been temporarily disabled by your teacher.'
      });
    }
    
    // Get battle stats
    let stats = query('SELECT * FROM arena_battle_stats WHERE student_id = ?', [student_id])[0];
    if (!stats) {
      run('INSERT INTO arena_battle_stats (student_id) VALUES (?)', [student_id]);
      stats = { total_battles: 0, wins: 0, losses: 0, current_streak: 0, best_streak: 0, battles_today: 0 };
    }
    
    // Get today's date for queries
    const today = new Date().toISOString().split('T')[0];
    
    // Get pending challenges
    run(`UPDATE arena_battles SET status = 'expired' WHERE status = 'pending' AND datetime(created_at, '+60 seconds') < datetime('now')`);
    
    const pendingChallenges = query(`
      SELECT ab.*, s.name as challenger_name, a.alliance_name as challenger_alliance
      FROM arena_battles ab
      JOIN students s ON ab.challenger_id = s.student_id
      JOIN alliances a ON ab.challenger_alliance_id = a.alliance_id
      WHERE ab.defender_id = ? AND ab.status = 'pending'
      ORDER BY ab.created_at DESC
    `, [student_id]);
    
    // Get active battle
    const activeBattle = query(`
      SELECT * FROM arena_battles 
      WHERE (challenger_id = ? OR defender_id = ?) AND status IN ('accepted', 'in_progress')
    `, [student_id, student_id])[0];
    
    // Get available opponents (same period, different alliance, has arena access)
    const opponentsRaw = query(`
      SELECT s.student_id, s.name, s.class_period, a.alliance_name, a.alliance_id,
             (SELECT wins FROM arena_battle_stats WHERE student_id = s.student_id) as wins,
             (SELECT losses FROM arena_battle_stats WHERE student_id = s.student_id) as losses
      FROM students s
      JOIN alliances a ON s.alliance_id = a.alliance_id
      WHERE s.class_period = ? 
        AND s.alliance_id != ?
        AND a.is_disbanded = 0
        AND a.buildings_owned LIKE '%Town Center%'
        AND a.buildings_owned LIKE '%House%'
        AND s.student_id NOT IN (
          SELECT CASE WHEN challenger_id = ? THEN defender_id ELSE challenger_id END
          FROM arena_battles 
          WHERE (challenger_id = ? OR defender_id = ?)
            AND DATE(created_at) = ?
            AND status NOT IN ('declined', 'expired')
        )
      ORDER BY a.alliance_name, s.name
    `, [student.class_period, student.alliance_id, student_id, student_id, student_id, today]);
    
    // Add battles_today count for each opponent
    const opponents = opponentsRaw.map(opp => ({
      ...opp,
      battles_today: countBattlesToday(opp.student_id)
    }));
    
    // Get unlocked gods with bonus status
    const progress = query('SELECT * FROM student_achievement_progress WHERE student_id = ?', [student_id])[0];
    const godList = ['zeus', 'poseidon', 'hera', 'athena', 'apollo', 'artemis', 'aphrodite', 'ares', 'hephaestus', 'hermes', 'demeter', 'prometheus', 'hades'];
    const prometheusUsed = prometheusUsedToday(student_id);
    
    const unlockedGods = godList.filter(g => progress && progress[`pantheon_${g}_unlocked`] === 1)
      .map(g => {
        const godPower = GOD_POWERS[g];
        const hasBonus = progress[`pantheon_${g}_bonus_seen`] === 1;
        return { 
          name: g, 
          displayName: g.charAt(0).toUpperCase() + g.slice(1),
          hasBonus: hasBonus,
          type: godPower.type,
          powerName: godPower.name,
          description: godPower.description,
          emoji: godPower.emoji,
          passive: godPower.passive || null,
          blocks: godPower.blocks || null,
          counteredBy: godPower.counteredBy || null,
          // For Prometheus, check if used today
          usedToday: g === 'prometheus' ? prometheusUsed : false,
          // Show effect values based on bonus status
          effectValue: hasBonus ? (godPower.bonusEffect || godPower.bonusPassiveEffect) : (godPower.baseEffect || godPower.passiveEffect)
        };
      });
    
    res.json({
      arena_unlocked: true,
      arena_enabled: true,
      stats: {
        total_battles: stats.total_battles || 0,
        wins: stats.wins || 0,
        losses: stats.losses || 0,
        current_streak: stats.current_streak || 0,
        best_streak: stats.best_streak || 0
      },
      battles_today: countBattlesToday(student_id),
      max_battles_per_day: MAX_BATTLES_PER_DAY,
      pending_challenges: pendingChallenges,
      active_battle: activeBattle,
      available_opponents: opponents,
      unlocked_gods: unlockedGods,
      god_powers: GOD_POWERS, // Send full powers config for info modal
      prometheus_used_today: prometheusUsed
    });
  } catch (err) {
    console.error('Arena status error:', err);
    res.status(500).json({ error: 'Failed to load arena status: ' + err.message });
  }
});

// Challenge another student
app.post('/api/arena/challenge', authenticateToken, (req, res) => {
  try {
    const challenger_id = req.user.id;
    const { defender_id, point_stakes } = req.body;
    
    if (!point_stakes || point_stakes < 1 || point_stakes > 10) {
      return res.status(400).json({ error: 'Point stakes must be between 1 and 10' });
    }
    
    // Check challenger's daily battle limit
    const challengerBattlesToday = countBattlesToday(challenger_id);
    if (challengerBattlesToday >= MAX_BATTLES_PER_DAY) {
      return res.status(400).json({ error: `You have reached your daily limit of ${MAX_BATTLES_PER_DAY} battles.` });
    }
    
    // Check defender's daily battle limit
    const defenderBattlesToday = countBattlesToday(defender_id);
    if (defenderBattlesToday >= MAX_BATTLES_PER_DAY) {
      return res.status(400).json({ error: 'This player has reached their daily battle limit.' });
    }
    
    const challenger = query('SELECT * FROM students WHERE student_id = ?', [challenger_id])[0];
    const defender = query('SELECT * FROM students WHERE student_id = ?', [defender_id])[0];
    
    if (!challenger || !defender) {
      return res.status(400).json({ error: 'Invalid players' });
    }
    
    if (challenger.alliance_id === defender.alliance_id) {
      return res.status(400).json({ error: 'You cannot battle members of your own alliance' });
    }
    
    run(`INSERT INTO arena_battles (challenger_id, defender_id, challenger_alliance_id, defender_alliance_id, point_stakes, class_period, status)
        VALUES (?, ?, ?, ?, ?, ?, 'pending')`,
      [challenger_id, defender_id, challenger.alliance_id, defender.alliance_id, point_stakes, challenger.class_period]);
    
    res.json({ success: true, message: `Challenge sent to ${defender.name}!` });
  } catch (err) {
    console.error('Challenge error:', err);
    res.status(500).json({ error: 'Failed to send challenge' });
  }
});

// Respond to challenge
app.post('/api/arena/respond', authenticateToken, (req, res) => {
  try {
    const defender_id = req.user.id;
    const { battle_id, accept } = req.body;
    
    const battle = query('SELECT * FROM arena_battles WHERE battle_id = ? AND defender_id = ? AND status = ?', 
      [battle_id, defender_id, 'pending'])[0];
    
    if (!battle) {
      return res.status(404).json({ error: 'Challenge not found or expired' });
    }
    
    if (!accept) {
      run("UPDATE arena_battles SET status = 'declined' WHERE battle_id = ?", [battle_id]);
      return res.json({ success: true, message: 'Challenge declined' });
    }
    
    // Check defender's daily battle limit before accepting
    const defenderBattlesToday = countBattlesToday(defender_id);
    if (defenderBattlesToday >= MAX_BATTLES_PER_DAY) {
      return res.status(400).json({ error: `You have reached your daily limit of ${MAX_BATTLES_PER_DAY} battles. Challenge auto-declined.` });
    }
    
    // Also re-check challenger's limit (they might have battled since sending)
    const challengerBattlesToday = countBattlesToday(battle.challenger_id);
    if (challengerBattlesToday >= MAX_BATTLES_PER_DAY) {
      run("UPDATE arena_battles SET status = 'expired' WHERE battle_id = ?", [battle_id]);
      return res.status(400).json({ error: 'The challenger has reached their daily battle limit. Challenge expired.' });
    }
    
    run("UPDATE arena_battles SET status = 'accepted' WHERE battle_id = ?", [battle_id]);
    res.json({ success: true, message: 'Challenge accepted!' });
  } catch (err) {
    console.error('Respond error:', err);
    res.status(500).json({ error: 'Failed to respond' });
  }
});

// Select gods for battle
app.post('/api/arena/select-gods', authenticateToken, (req, res) => {
  try {
    const student_id = req.user.id;
    const { battle_id, gods } = req.body;
    
    const battle = query('SELECT * FROM arena_battles WHERE battle_id = ? AND status = ?', [battle_id, 'accepted'])[0];
    if (!battle) {
      return res.status(404).json({ error: 'Battle not found or not in accepted state' });
    }
    
    const isChallenger = battle.challenger_id === student_id;
    if (!isChallenger && battle.defender_id !== student_id) {
      return res.status(403).json({ error: 'You are not part of this battle' });
    }
    
    const selectedGods = gods || [];
    
    // Validate max 3 gods
    if (selectedGods.length > 3) {
      return res.status(400).json({ error: 'Maximum 3 gods allowed' });
    }
    
    // Validate each god is unlocked
    for (const god of selectedGods) {
      if (!hasGodUnlocked(student_id, god)) {
        return res.status(400).json({ error: `You have not unlocked ${god}` });
      }
    }
    
    // Check Prometheus daily limit
    if (selectedGods.includes('prometheus')) {
      if (prometheusUsedToday(student_id)) {
        return res.status(400).json({ error: 'You have already used Prometheus today. He can only be used once per day.' });
      }
      // Mark Prometheus as used for today
      const today = new Date().toISOString().split('T')[0];
      run('UPDATE arena_battle_stats SET prometheus_used_date = ? WHERE student_id = ?', [today, student_id]);
    }
    
    // Build god data with bonus status
    const godData = selectedGods.map(g => ({
      name: g,
      hasBonus: hasGodBonus(student_id, g)
    }));
    
    // Save gods and mark as ready
    const godsCol = isChallenger ? 'challenger_gods' : 'defender_gods';
    const readyCol = isChallenger ? 'challenger_gods_ready' : 'defender_gods_ready';
    const cooldownCol = isChallenger ? 'challenger_god_cooldowns' : 'defender_god_cooldowns';
    
    // Initialize cooldowns
    const cooldowns = {};
    selectedGods.forEach(g => cooldowns[g] = 0);
    
    console.log(`🎮 Saving god selection for ${isChallenger ? 'challenger' : 'defender'}: ${readyCol} = 1`);
    
    run(`UPDATE arena_battles SET ${godsCol} = ?, ${readyCol} = 1, ${cooldownCol} = ? WHERE battle_id = ?`, 
      [JSON.stringify(godData), JSON.stringify(cooldowns), battle_id]);
    
    saveDatabase(); // Save immediately after update
    
    // Check if BOTH players are ready
    const updated = query('SELECT * FROM arena_battles WHERE battle_id = ?', [battle_id])[0];
    
    console.log(`📊 After update - challenger_gods_ready: ${updated.challenger_gods_ready}, defender_gods_ready: ${updated.defender_gods_ready}`);
    
    if (updated.challenger_gods_ready === 1 && updated.defender_gods_ready === 1) {
      // BOTH ready - start battle with deploy phase
      // Get all available questions and pick one randomly (more reliable than SQLite RANDOM())
      const allQuestions = query('SELECT question_id FROM battle_questions WHERE is_active = 1');
      const question = allQuestions.length > 0 ? allQuestions[Math.floor(Math.random() * allQuestions.length)] : null;
      
      if (question) {
        // Set synchronized start time - 1 second from now for both players
        const roundStartsAt = new Date(Date.now() + 1000).toISOString();
        const phaseEndsAt = new Date(Date.now() + 1000 + BATTLE_TIMING.DEPLOY_PHASE).toISOString();
        
        run("UPDATE arena_battles SET status = 'in_progress', started_at = CURRENT_TIMESTAMP, current_round = 1 WHERE battle_id = ?", [battle_id]);
        run(`INSERT INTO arena_battle_rounds (battle_id, round_number, question_id, phase, phase_ends_at, started_at) 
             VALUES (?, 1, ?, 'deploy', ?, ?)`,
          [battle_id, question.question_id, phaseEndsAt, roundStartsAt]);
        
        console.log(`⏱️ Round 1 created - starts at ${roundStartsAt}, question_id: ${question.question_id}`);
      }
      
      saveDatabase();
      return res.json({ success: true, battle_started: true });
    }
    
    saveDatabase();
    res.json({ success: true, waiting_for_opponent: true, your_gods: godData });
  } catch (err) {
    console.error('Select gods error:', err);
    res.status(500).json({ error: 'Failed to select gods' });
  }
});

// Get battle state
app.get('/api/arena/battle/:battle_id', authenticateToken, (req, res) => {
  try {
    const student_id = req.user.id;
    const { battle_id } = req.params;
    
    const battle = query('SELECT * FROM arena_battles WHERE battle_id = ?', [battle_id])[0];
    if (!battle) {
      return res.status(404).json({ error: 'Battle not found' });
    }
    
    const isChallenger = battle.challenger_id === student_id;
    const challenger = query('SELECT name FROM students WHERE student_id = ?', [battle.challenger_id])[0];
    const defender = query('SELECT name FROM students WHERE student_id = ?', [battle.defender_id])[0];
    
    // Parse god data
    const myGods = JSON.parse(isChallenger ? (battle.challenger_gods || '[]') : (battle.defender_gods || '[]'));
    const myCooldowns = JSON.parse(isChallenger ? (battle.challenger_god_cooldowns || '{}') : (battle.defender_god_cooldowns || '{}'));
    
    let question = null;
    let roundData = null;
    let phaseInfo = null;
    const currentRound = query('SELECT * FROM arena_battle_rounds WHERE battle_id = ? AND round_number = ?', 
      [battle_id, battle.current_round])[0];
    
    if (currentRound && battle.status === 'in_progress') {
      // Calculate time remaining in current phase
      const now = new Date();
      const phaseEndsAt = currentRound.phase_ends_at ? new Date(currentRound.phase_ends_at) : null;
      const phaseTimeRemaining = phaseEndsAt ? Math.max(0, Math.floor((phaseEndsAt - now) / 1000)) : 0;
      
      // Auto-advance phase if time expired
      if (phaseEndsAt && now > phaseEndsAt) {
        if (currentRound.phase === 'deploy') {
          // Move to question phase with synchronized start time
          const questionStartsAt = new Date(Date.now() + BATTLE_TIMING.TRANSITION_DELAY).toISOString();
          const newPhaseEnds = new Date(Date.now() + BATTLE_TIMING.TRANSITION_DELAY + BATTLE_TIMING.QUESTION_PHASE).toISOString();
          run("UPDATE arena_battle_rounds SET phase = 'question', question_starts_at = ?, phase_ends_at = ? WHERE round_id = ?", 
            [questionStartsAt, newPhaseEnds, currentRound.round_id]);
          currentRound.phase = 'question';
          currentRound.question_starts_at = questionStartsAt;
          currentRound.phase_ends_at = newPhaseEnds;
          console.log(`⏱️ Deploy timeout - Question synced: starts at ${questionStartsAt}`);
        } else if (currentRound.phase === 'question') {
          // Time's up - auto-submit wrong answers for anyone who hasn't answered
          if (!currentRound.challenger_answer) {
            run("UPDATE arena_battle_rounds SET challenger_answer = 'timeout', challenger_time_ms = ? WHERE round_id = ?", 
              [BATTLE_TIMING.QUESTION_PHASE, currentRound.round_id]);
          }
          if (!currentRound.defender_answer) {
            run("UPDATE arena_battle_rounds SET defender_answer = 'timeout', defender_time_ms = ? WHERE round_id = ?", 
              [BATTLE_TIMING.QUESTION_PHASE, currentRound.round_id]);
          }
        } else if (currentRound.phase === 'results') {
          // Results phase ended - create next round
          const nextRoundNum = battle.current_round + 1;
          
          // Check if battle should continue (less than 5 rounds or tied at 5)
          if (nextRoundNum <= 5 || (battle.challenger_score === battle.defender_score)) {
            // Get all unused questions and pick one randomly
            const usedQuestions = query('SELECT question_id FROM arena_battle_rounds WHERE battle_id = ?', [battle_id]);
            const usedIds = usedQuestions.map(q => q.question_id);
            const availableQuestions = query('SELECT question_id FROM battle_questions WHERE is_active = 1')
              .filter(q => !usedIds.includes(q.question_id));
            const nextQ = availableQuestions.length > 0 ? availableQuestions[Math.floor(Math.random() * availableQuestions.length)] : null;
            
            if (nextQ) {
              const isSuddenDeath = nextRoundNum > 5;
              const newPhase = isSuddenDeath ? 'question' : 'deploy';
              const phaseDuration = isSuddenDeath ? BATTLE_TIMING.QUESTION_PHASE : BATTLE_TIMING.DEPLOY_PHASE;
              
              // Set a synchronized start time - 1 second from now
              // This ensures both clients wait until this moment before showing the new round
              const roundStartsAt = new Date(Date.now() + 1000).toISOString();
              const newPhaseEnds = new Date(Date.now() + 1000 + phaseDuration).toISOString();
              
              console.log(`⏱️ Round ${nextRoundNum} created - question_id: ${nextQ.question_id}`);
              
              run('UPDATE arena_battles SET current_round = ? WHERE battle_id = ?', [nextRoundNum, battle_id]);
              
              // For sudden death, also set question_starts_at
              if (isSuddenDeath) {
                const questionStartsAt = new Date(Date.now() + 1000 + BATTLE_TIMING.SYNC_DELAY).toISOString();
                run(`INSERT INTO arena_battle_rounds (battle_id, round_number, question_id, phase, phase_ends_at, question_starts_at, started_at) 
                     VALUES (?, ?, ?, ?, ?, ?, ?)`,
                  [battle_id, nextRoundNum, nextQ.question_id, newPhase, newPhaseEnds, questionStartsAt, roundStartsAt]);
              } else {
                run(`INSERT INTO arena_battle_rounds (battle_id, round_number, question_id, phase, phase_ends_at, started_at) 
                     VALUES (?, ?, ?, ?, ?, ?)`,
                  [battle_id, nextRoundNum, nextQ.question_id, newPhase, newPhaseEnds, roundStartsAt]);
              }
              
              console.log(`⏱️ Round ${nextRoundNum} created - starts at ${roundStartsAt}`);
              
              // Re-query to get the new round
              battle.current_round = nextRoundNum;
              saveDatabase();
            }
          }
        }
      }
      
      // Only show question during question phase (or results phase)
      if (currentRound.phase === 'question' || currentRound.phase === 'results') {
        const q = query('SELECT * FROM battle_questions WHERE question_id = ?', [currentRound.question_id])[0];
        if (q) {
          const seed = currentRound.round_id;
          const answers = [
            { text: q.correct_answer, isCorrect: true },
            { text: q.wrong_answer_1, isCorrect: false },
            { text: q.wrong_answer_2, isCorrect: false },
            { text: q.wrong_answer_3, isCorrect: false }
          ];
          for (let i = answers.length - 1; i > 0; i--) {
            const j = Math.floor(((seed * (i + 1) * 9301 + 49297) % 233280) / 233280 * (i + 1));
            [answers[i], answers[j]] = [answers[j], answers[i]];
          }
          
          question = {
            question_id: q.question_id,
            question_text: q.question_text,
            god_associated: q.god_associated,
            shuffled_answers: answers.map((a, i) => ({ index: i, text: a.text, isCorrect: a.isCorrect }))
          };
        }
      }
      
      // Check if I've deployed a god this round
      const myDeployReady = isChallenger ? currentRound.challenger_deploy_ready : currentRound.defender_deploy_ready;
      const opponentDeployReady = isChallenger ? currentRound.defender_deploy_ready : currentRound.challenger_deploy_ready;
      
      roundData = {
        round_number: currentRound.round_number,
        phase: currentRound.phase || 'deploy',
        phase_time_remaining: phaseTimeRemaining,
        question_starts_at: currentRound.question_starts_at || null,
        round_started_at: currentRound.started_at || null,
        challenger_god_deployed: currentRound.challenger_god_deployed,
        defender_god_deployed: currentRound.defender_god_deployed,
        challenger_answered: currentRound.challenger_answer !== null,
        defender_answered: currentRound.defender_answer !== null,
        challenger_god_blocked: currentRound.challenger_god_blocked === 1,
        defender_god_blocked: currentRound.defender_god_blocked === 1,
        my_god_deployed: isChallenger ? currentRound.challenger_god_deployed : currentRound.defender_god_deployed,
        opponent_god_deployed: isChallenger ? currentRound.defender_god_deployed : currentRound.challenger_god_deployed,
        my_deploy_ready: myDeployReady === 1,
        opponent_deploy_ready: opponentDeployReady === 1,
        both_deployed: (currentRound.challenger_deploy_ready === 1 && currentRound.defender_deploy_ready === 1)
      };
    }
    
    const myAnswer = currentRound ? (isChallenger ? currentRound.challenger_answer : currentRound.defender_answer) : null;
    
    // Calculate which gods are available (not on cooldown)
    const availableGods = myGods.filter(g => {
      const godName = typeof g === 'string' ? g : g.name;
      return !myCooldowns[godName] || myCooldowns[godName] <= 0;
    });
    
    res.json({
      battle_id: battle.battle_id,
      status: battle.status,
      point_stakes: battle.point_stakes,
      current_round: battle.current_round,
      challenger_score: battle.challenger_score,
      defender_score: battle.defender_score,
      challenger_id: battle.challenger_id,
      defender_id: battle.defender_id,
      challenger_name: challenger?.name,
      defender_name: defender?.name,
      is_challenger: isChallenger,
      my_answer: myAnswer,
      question,
      round_data: roundData,
      winner_id: battle.winner_id,
      // God info (minimal - god_powers already loaded from arena/status)
      my_gods: myGods,
      my_cooldowns: myCooldowns,
      available_gods: availableGods
    });
  } catch (err) {
    console.error('Get battle error:', err);
    res.status(500).json({ error: 'Failed to get battle' });
  }
});

// Deploy god for current round
app.post('/api/arena/deploy-god', authenticateToken, (req, res) => {
  try {
    const student_id = req.user.id;
    const { battle_id, god_name } = req.body; // god_name can be null for "no power"
    
    const battle = query("SELECT * FROM arena_battles WHERE battle_id = ? AND status = 'in_progress'", [battle_id])[0];
    if (!battle) {
      return res.status(404).json({ error: 'Battle not found or not in progress' });
    }
    
    const isChallenger = battle.challenger_id === student_id;
    const currentRound = query('SELECT * FROM arena_battle_rounds WHERE battle_id = ? AND round_number = ?',
      [battle_id, battle.current_round])[0];
    
    if (!currentRound) {
      return res.status(400).json({ error: 'No active round' });
    }
    
    // Check we're in deploy phase
    if (currentRound.phase !== 'deploy') {
      return res.status(400).json({ error: 'Not in deploy phase' });
    }
    
    // Check if already deployed this round
    const deployReadyCol = isChallenger ? 'challenger_deploy_ready' : 'defender_deploy_ready';
    if (currentRound[deployReadyCol] === 1) {
      return res.status(400).json({ error: 'Already made your selection this round' });
    }
    
    // Validate god selection
    if (god_name) {
      // Check if god is in player's selected gods
      const myGods = JSON.parse(isChallenger ? (battle.challenger_gods || '[]') : (battle.defender_gods || '[]'));
      const godNames = myGods.map(g => typeof g === 'string' ? g : g.name);
      if (!godNames.includes(god_name)) {
        return res.status(400).json({ error: 'You did not select this god for battle' });
      }
      
      // Check cooldown
      const myCooldowns = JSON.parse(isChallenger ? (battle.challenger_god_cooldowns || '{}') : (battle.defender_god_cooldowns || '{}'));
      if (myCooldowns[god_name] && myCooldowns[god_name] > 0) {
        return res.status(400).json({ error: `${god_name} is on cooldown for ${myCooldowns[god_name]} more round(s)` });
      }
      
      // Set cooldown (2 rounds)
      const cooldownCol = isChallenger ? 'challenger_god_cooldowns' : 'defender_god_cooldowns';
      myCooldowns[god_name] = 2;
      run(`UPDATE arena_battles SET ${cooldownCol} = ? WHERE battle_id = ?`, [JSON.stringify(myCooldowns), battle_id]);
    }
    
    // Deploy the god and mark as ready
    const deployedCol = isChallenger ? 'challenger_god_deployed' : 'defender_god_deployed';
    run(`UPDATE arena_battle_rounds SET ${deployedCol} = ?, ${deployReadyCol} = 1 WHERE round_id = ?`, 
      [god_name || null, currentRound.round_id]);
    
    // Check if both have made their choices
    const updatedRound = query('SELECT * FROM arena_battle_rounds WHERE round_id = ?', [currentRound.round_id])[0];
    
    if (updatedRound.challenger_deploy_ready === 1 && updatedRound.defender_deploy_ready === 1) {
      // Both ready - check for counters and move to question phase
      const challengerGod = updatedRound.challenger_god_deployed;
      const defenderGod = updatedRound.defender_god_deployed;
      
      // Check for counters
      if (challengerGod && defenderGod && GOD_POWERS[challengerGod] && GOD_POWERS[defenderGod]) {
        const challengerPower = GOD_POWERS[challengerGod];
        const defenderPower = GOD_POWERS[defenderGod];
        
        if (challengerPower.counteredBy === defenderGod) {
          run('UPDATE arena_battle_rounds SET challenger_god_blocked = 1 WHERE round_id = ?', [currentRound.round_id]);
        }
        if (defenderPower.counteredBy === challengerGod) {
          run('UPDATE arena_battle_rounds SET defender_god_blocked = 1 WHERE round_id = ?', [currentRound.round_id]);
        }
      }
      
      // CRITICAL: Set question_starts_at to EXACTLY 2 seconds from now
      // Both clients will poll and see this timestamp, then wait until it arrives
      const questionStartsAt = new Date(Date.now() + BATTLE_TIMING.SYNC_DELAY).toISOString();
      const phaseEndsAt = new Date(Date.now() + BATTLE_TIMING.SYNC_DELAY + BATTLE_TIMING.QUESTION_PHASE).toISOString();
      
      run("UPDATE arena_battle_rounds SET phase = 'question', question_starts_at = ?, phase_ends_at = ? WHERE round_id = ?", 
        [questionStartsAt, phaseEndsAt, currentRound.round_id]);
      
      console.log(`⏱️ BOTH READY! Question starts at ${questionStartsAt} (in ${BATTLE_TIMING.SYNC_DELAY}ms)`);
      
      saveDatabase();
      
      // Return the timestamp to this player - they need to wait for it
      return res.json({ 
        success: true, 
        both_ready: true, 
        question_starts_at: questionStartsAt,
        wait_ms: BATTLE_TIMING.SYNC_DELAY
      });
    }
    
    saveDatabase();
    res.json({ success: true, god_deployed: god_name, waiting_for_opponent: true });
    
  } catch (err) {
    console.error('Deploy god error:', err);
    res.status(500).json({ error: 'Failed to deploy god' });
  }
});

// Submit answer
app.post('/api/arena/answer', authenticateToken, (req, res) => {
  try {
    const student_id = req.user.id;
    const { battle_id, answer_index, time_ms } = req.body;
    
    console.log(`🎯 Answer submission: battle=${battle_id}, student=${student_id}, answer=${answer_index}, time=${time_ms}`);
    
    const battle = query("SELECT * FROM arena_battles WHERE battle_id = ? AND status = 'in_progress'", [battle_id])[0];
    if (!battle) {
      console.log('❌ Battle not found or not in progress');
      return res.status(404).json({ error: 'Battle not found' });
    }
    
    const isChallenger = battle.challenger_id === student_id;
    const currentRound = query('SELECT * FROM arena_battle_rounds WHERE battle_id = ? AND round_number = ?',
      [battle_id, battle.current_round])[0];
    
    if (!currentRound) {
      console.log('❌ No current round found');
      return res.status(400).json({ error: 'No active round' });
    }
    
    console.log(`📊 Current round: ${currentRound.round_number}, phase: ${currentRound.phase}, challenger_ans: ${currentRound.challenger_answer}, defender_ans: ${currentRound.defender_answer}`);
    
    // Check phase - must be in question phase to answer
    if (currentRound.phase !== 'question') {
      console.log(`⚠️ Tried to answer in wrong phase: ${currentRound.phase}`);
      return res.status(400).json({ error: 'Not in question phase' });
    }
    
    // Check if already answered
    const existingAnswer = isChallenger ? currentRound.challenger_answer : currentRound.defender_answer;
    if (existingAnswer) {
      console.log(`⚠️ Already answered: ${existingAnswer}`);
      return res.status(400).json({ error: 'Already answered this round' });
    }
    
    // Get question and use seeded shuffle to match battle state
    const question = query('SELECT * FROM battle_questions WHERE question_id = ?', [currentRound.question_id])[0];
    
    if (!question) {
      console.error('Question not found for round:', currentRound.round_id, 'question_id:', currentRound.question_id);
      return res.status(400).json({ error: 'Question not found for this round' });
    }
    
    const seed = currentRound.round_id;
    const answers = [
      { text: question.correct_answer, isCorrect: true },
      { text: question.wrong_answer_1, isCorrect: false },
      { text: question.wrong_answer_2, isCorrect: false },
      { text: question.wrong_answer_3, isCorrect: false }
    ];
    // Seeded shuffle - MUST match the one in battle state endpoint
    for (let i = answers.length - 1; i > 0; i--) {
      const j = Math.floor(((seed * (i + 1) * 9301 + 49297) % 233280) / 233280 * (i + 1));
      [answers[i], answers[j]] = [answers[j], answers[i]];
    }
    
    const isCorrect = answer_index >= 0 && answer_index < 4 && answers[answer_index]?.isCorrect;
    
    // Check for Artemis bonus (answered correctly in first 5 seconds)
    let artemisBonus = 0;
    const myGod = isChallenger ? currentRound.challenger_god_deployed : currentRound.defender_god_deployed;
    const myGodBlocked = isChallenger ? currentRound.challenger_god_blocked : currentRound.defender_god_blocked;
    
    if (myGod === 'artemis' && !myGodBlocked && isCorrect && time_ms <= 5000) {
      // Check if has bonus
      const myGods = JSON.parse(isChallenger ? (battle.challenger_gods || '[]') : (battle.defender_gods || '[]'));
      const artemisData = myGods.find(g => (typeof g === 'string' ? g : g.name) === 'artemis');
      const hasBonus = artemisData && typeof artemisData === 'object' && artemisData.hasBonus;
      artemisBonus = hasBonus ? 0.75 : 0.5;
    }
    
    const answerCol = isChallenger ? 'challenger_answer' : 'defender_answer';
    const timeCol = isChallenger ? 'challenger_time_ms' : 'defender_time_ms';
    const artemisCol = isChallenger ? 'artemis_bonus_challenger' : 'artemis_bonus_defender';
    
    run(`UPDATE arena_battle_rounds SET ${answerCol} = ?, ${timeCol} = ?, ${artemisCol} = ? WHERE round_id = ?`,
      [isCorrect ? 'correct' : 'wrong', time_ms || 15000, artemisBonus, currentRound.round_id]);
    
    // Check if both answered
    const updated = query('SELECT * FROM arena_battle_rounds WHERE round_id = ?', [currentRound.round_id])[0];
    
    console.log(`📝 Answer submitted - Round ${currentRound.round_number}, Challenger: ${updated.challenger_answer}, Defender: ${updated.defender_answer}`);
    
    if (updated.challenger_answer && updated.defender_answer) {
      console.log(`✅ Both answered - processing round results...`);
      // Determine round winner
      let roundWinner = null;
      let challengerScore = 0;
      let defenderScore = 0;
      
      // Base scoring: correct answer = 1 point
      if (updated.challenger_answer === 'correct') challengerScore = 1;
      if (updated.defender_answer === 'correct') defenderScore = 1;
      
      // Add Artemis bonuses
      challengerScore += (updated.artemis_bonus_challenger || 0);
      defenderScore += (updated.artemis_bonus_defender || 0);
      
      // Determine winner (if both correct, faster wins; if scores differ, higher wins)
      if (updated.challenger_answer === 'correct' && updated.defender_answer !== 'correct') {
        roundWinner = battle.challenger_id;
      } else if (updated.defender_answer === 'correct' && updated.challenger_answer !== 'correct') {
        roundWinner = battle.defender_id;
      } else if (updated.challenger_answer === 'correct' && updated.defender_answer === 'correct') {
        // Both correct - check Artemis bonus first, then time
        if (challengerScore > defenderScore) {
          roundWinner = battle.challenger_id;
        } else if (defenderScore > challengerScore) {
          roundWinner = battle.defender_id;
        } else {
          // Same score - fastest wins
          roundWinner = updated.challenger_time_ms < updated.defender_time_ms ? battle.challenger_id : battle.defender_id;
        }
      }
      // If both wrong, no winner (roundWinner stays null)
      
      run('UPDATE arena_battle_rounds SET round_winner_id = ?, completed_at = CURRENT_TIMESTAMP WHERE round_id = ?',
        [roundWinner, currentRound.round_id]);
      
      // Update battle scores
      let newChallengerScore = battle.challenger_score || 0;
      let newDefenderScore = battle.defender_score || 0;
      if (roundWinner === battle.challenger_id) newChallengerScore++;
      if (roundWinner === battle.defender_id) newDefenderScore++;
      
      run('UPDATE arena_battles SET challenger_score = ?, defender_score = ? WHERE battle_id = ?',
        [newChallengerScore, newDefenderScore, battle_id]);
      
      // Decrement cooldowns for next round
      const challengerCooldowns = JSON.parse(battle.challenger_god_cooldowns || '{}');
      const defenderCooldowns = JSON.parse(battle.defender_god_cooldowns || '{}');
      Object.keys(challengerCooldowns).forEach(g => { if (challengerCooldowns[g] > 0) challengerCooldowns[g]--; });
      Object.keys(defenderCooldowns).forEach(g => { if (defenderCooldowns[g] > 0) defenderCooldowns[g]--; });
      run('UPDATE arena_battles SET challenger_god_cooldowns = ?, defender_god_cooldowns = ? WHERE battle_id = ?',
        [JSON.stringify(challengerCooldowns), JSON.stringify(defenderCooldowns), battle_id]);
      
      // Check for battle end (first to 3, or after 5 rounds check for tie)
      const isSuddenDeath = battle.current_round > 5; // Rounds 6+ are sudden death
      const regularBattleOver = (newChallengerScore >= 3 || newDefenderScore >= 3) || 
                                (battle.current_round >= 5 && newChallengerScore !== newDefenderScore);
      const suddenDeathOver = isSuddenDeath && roundWinner !== null;
      
      if (regularBattleOver || suddenDeathOver) {
        const winner = newChallengerScore > newDefenderScore ? battle.challenger_id : 
                       newDefenderScore > newChallengerScore ? battle.defender_id : null;
        
        run("UPDATE arena_battles SET status = 'completed', winner_id = ?, completed_at = CURRENT_TIMESTAMP WHERE battle_id = ?",
          [winner, battle_id]);
        
        // Transfer points based on who won
        if (winner) {
          const challengerWon = winner === battle.challenger_id;
          const stakes = battle.point_stakes || 0;
          
          console.log(`⚔️ BATTLE COMPLETE - Winner: ${winner}, Stakes: ${stakes}, ChallengerWon: ${challengerWon}`);
          
          if (challengerWon) {
            // Challenger wins: +full stakes, defender loses half
            console.log(`   Challenger alliance ${battle.challenger_alliance_id} gets +${stakes}`);
            console.log(`   Defender alliance ${battle.defender_alliance_id} loses -${Math.floor(stakes / 2)}`);
            run('UPDATE alliances SET total_points = total_points + ? WHERE alliance_id = ?', 
              [stakes, battle.challenger_alliance_id]);
            run('UPDATE alliances SET total_points = MAX(0, total_points - ?) WHERE alliance_id = ?', 
              [Math.floor(stakes / 2), battle.defender_alliance_id]);
          } else {
            // Defender wins: +full stakes, challenger loses full stakes
            console.log(`   Defender alliance ${battle.defender_alliance_id} gets +${stakes}`);
            console.log(`   Challenger alliance ${battle.challenger_alliance_id} loses -${stakes}`);
            run('UPDATE alliances SET total_points = total_points + ? WHERE alliance_id = ?', 
              [stakes, battle.defender_alliance_id]);
            run('UPDATE alliances SET total_points = MAX(0, total_points - ?) WHERE alliance_id = ?', 
              [stakes, battle.challenger_alliance_id]);
          }
          
          // Verify the update
          const challAlliance = query('SELECT alliance_name, total_points FROM alliances WHERE alliance_id = ?', [battle.challenger_alliance_id])[0];
          const defAlliance = query('SELECT alliance_name, total_points FROM alliances WHERE alliance_id = ?', [battle.defender_alliance_id])[0];
          console.log(`   After update: ${challAlliance?.alliance_name}=${challAlliance?.total_points}, ${defAlliance?.alliance_name}=${defAlliance?.total_points}`);
        }
        
        // Update battle stats
        const today = new Date().toISOString().split('T')[0];
        [battle.challenger_id, battle.defender_id].forEach(pid => {
          const isWinner = pid === winner;
          const isTie = winner === null;
          run(`UPDATE arena_battle_stats SET 
            total_battles = total_battles + 1,
            wins = wins + ?,
            losses = losses + ?,
            current_streak = CASE WHEN ? = 1 THEN current_streak + 1 ELSE 0 END,
            best_streak = CASE WHEN ? = 1 AND current_streak + 1 > best_streak THEN current_streak + 1 ELSE best_streak END,
            battles_today = CASE WHEN last_battle_date = ? THEN battles_today + 1 ELSE 1 END,
            last_battle_date = ?
            WHERE student_id = ?`,
            [isWinner ? 1 : 0, (isTie || isWinner) ? 0 : 1, isWinner ? 1 : 0, isWinner ? 1 : 0, today, today, pid]);
        });
        
        saveDatabase();
      } else if (battle.current_round >= 5 && newChallengerScore === newDefenderScore) {
        // Tied after 5 rounds - go to sudden death
        const nextRound = battle.current_round + 1;
        
        // Get unused questions and pick randomly
        const usedQuestions = query('SELECT question_id FROM arena_battle_rounds WHERE battle_id = ?', [battle_id]);
        const usedIds = usedQuestions.map(q => q.question_id);
        const availableQuestions = query('SELECT question_id FROM battle_questions WHERE is_active = 1')
          .filter(q => !usedIds.includes(q.question_id));
        const nextQ = availableQuestions.length > 0 ? availableQuestions[Math.floor(Math.random() * availableQuestions.length)] : null;
        
        if (nextQ) {
          // Sudden death - skip deploy phase, go straight to question
          // Add 3 second transition for the "SUDDEN DEATH" intro screen
          const questionStartsAt = new Date(Date.now() + 3000).toISOString();
          const phaseEndsAt = new Date(Date.now() + 3000 + BATTLE_TIMING.QUESTION_PHASE).toISOString();
          run('UPDATE arena_battles SET current_round = ? WHERE battle_id = ?', [nextRound, battle_id]);
          run(`INSERT INTO arena_battle_rounds (battle_id, round_number, question_id, phase, phase_ends_at, question_starts_at, started_at) 
               VALUES (?, ?, ?, 'question', ?, ?, CURRENT_TIMESTAMP)`,
            [battle_id, nextRound, nextQ.question_id, phaseEndsAt, questionStartsAt]);
          console.log(`⏱️ SUDDEN DEATH Round ${nextRound} - question_id: ${nextQ.question_id}`);
        }
        saveDatabase();
      } else {
        // Set results phase for current round
        // Add ANSWER_FEEDBACK time (3s) + RESULTS_PHASE time (5s) = 8 seconds total
        // This gives players time to see correct/wrong, hear sounds, then see round results
        const resultsEndsAt = new Date(Date.now() + BATTLE_TIMING.ANSWER_FEEDBACK + BATTLE_TIMING.RESULTS_PHASE).toISOString();
        run("UPDATE arena_battle_rounds SET phase = 'results', phase_ends_at = ? WHERE round_id = ?",
          [resultsEndsAt, currentRound.round_id]);
        
        console.log(`⏱️ Answer feedback + Results phase: ${BATTLE_TIMING.ANSWER_FEEDBACK + BATTLE_TIMING.RESULTS_PHASE}ms`);
        
        // DON'T create next round yet - wait for results phase to end
        // The next round will be created when the client polls and sees results phase has ended
        saveDatabase();
      }
    }
    
    saveDatabase();
    res.json({ success: true, was_correct: isCorrect, artemis_bonus: artemisBonus });
  } catch (err) {
    console.error('Submit answer error:', err);
    res.status(500).json({ error: 'Failed to submit answer' });
  }
});

// Forfeit/Withdraw from battle
app.post('/api/arena/forfeit', authenticateToken, (req, res) => {
  try {
    const student_id = req.user.id;
    const { battle_id } = req.body;
    
    const battle = query('SELECT * FROM arena_battles WHERE battle_id = ?', [battle_id])[0];
    if (!battle) {
      return res.status(404).json({ error: 'Battle not found' });
    }
    
    const isChallenger = battle.challenger_id === student_id;
    const isDefender = battle.defender_id === student_id;
    
    if (!isChallenger && !isDefender) {
      return res.status(403).json({ error: 'You are not part of this battle' });
    }
    
    // Only allow forfeit if battle is pending, accepted, or in_progress
    if (!['pending', 'accepted', 'in_progress'].includes(battle.status)) {
      return res.status(400).json({ error: 'Cannot forfeit a completed battle' });
    }
    
    const winner_id = isChallenger ? battle.defender_id : battle.challenger_id;
    const loser_id = student_id;
    
    // Mark battle as complete with forfeit
    run("UPDATE arena_battles SET status = 'complete', winner_id = ?, completed_at = CURRENT_TIMESTAMP WHERE battle_id = ?",
      [winner_id, battle_id]);
    
    // Get alliances
    const winner = query('SELECT alliance_id FROM students WHERE student_id = ?', [winner_id])[0];
    const loser = query('SELECT alliance_id FROM students WHERE student_id = ?', [loser_id])[0];
    
    // Apply point penalty for forfeit (loser loses full stakes, winner gets half)
    if (winner && loser && battle.point_stakes > 0) {
      const stakes = battle.point_stakes;
      run('UPDATE alliances SET total_points = total_points + ? WHERE alliance_id = ?', [Math.floor(stakes / 2), winner.alliance_id]);
      run('UPDATE alliances SET total_points = MAX(0, total_points - ?) WHERE alliance_id = ?', [stakes, loser.alliance_id]);
      
      console.log(`🏳️ Battle ${battle_id} forfeited by student ${loser_id}. Winner: ${winner_id}`);
    }
    
    saveDatabase();
    res.json({ success: true, message: 'Battle forfeited' });
  } catch (err) {
    console.error('Forfeit error:', err);
    res.status(500).json({ error: 'Failed to forfeit battle' });
  }
});

// Teacher: Toggle arena
app.post('/api/teacher/arena/toggle', authenticateToken, (req, res) => {
  try {
    const { enabled } = req.body;
    run("INSERT OR REPLACE INTO arena_settings (setting_type, setting_key, setting_value) VALUES ('global', 'enabled', ?)",
      [enabled ? 'true' : 'false']);
    saveDatabase();
    res.json({ success: true, message: `Arena ${enabled ? 'enabled' : 'disabled'}` });
  } catch (err) {
    res.status(500).json({ error: 'Failed to toggle arena' });
  }
});

// Teacher: Toggle arena for specific student
app.post('/api/teacher/arena/toggle-student', authenticateToken, (req, res) => {
  try {
    const { student_id, enabled } = req.body;
    run("INSERT OR REPLACE INTO arena_settings (setting_type, setting_key, setting_value) VALUES ('student', ?, ?)",
      [String(student_id), enabled ? 'true' : 'false']);
    saveDatabase();
    res.json({ success: true, message: `Arena ${enabled ? 'enabled' : 'disabled'} for student` });
  } catch (err) {
    res.status(500).json({ error: 'Failed to toggle arena for student' });
  }
});

// Teacher: Get arena settings
app.get('/api/teacher/arena/settings', authenticateToken, (req, res) => {
  try {
    const globalSetting = query("SELECT setting_value FROM arena_settings WHERE setting_type = 'global' AND setting_key = 'enabled'")[0];
    const studentSettings = query("SELECT setting_key as student_id, setting_value FROM arena_settings WHERE setting_type = 'student'");
    
    res.json({
      global_enabled: !globalSetting || globalSetting.setting_value !== 'false',
      student_settings: studentSettings.reduce((acc, s) => {
        acc[s.student_id] = s.setting_value === 'true';
        return acc;
      }, {})
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to get arena settings' });
  }
});

// Abandon/dismiss stuck battle
app.post('/api/arena/abandon-battle', authenticateToken, (req, res) => {
  try {
    const student_id = req.user.id;
    const { battle_id } = req.body;
    
    // Only allow abandoning battles the user is part of
    const battle = query('SELECT * FROM arena_battles WHERE battle_id = ? AND (challenger_id = ? OR defender_id = ?)',
      [battle_id, student_id, student_id])[0];
    
    if (!battle) {
      return res.status(404).json({ error: 'Battle not found' });
    }
    
    // Mark as expired/abandoned
    run("UPDATE arena_battles SET status = 'expired' WHERE battle_id = ?", [battle_id]);
    saveDatabase();
    
    res.json({ success: true, message: 'Battle abandoned' });
  } catch (err) {
    console.error('Abandon battle error:', err);
    res.status(500).json({ error: 'Failed to abandon battle' });
  }
});

// Auto-expire old stuck battles (run on server start and periodically)
function cleanupStuckBattles() {
  if (!dbReady) return; // Don't run if database not ready
  try {
    // Expire battles that have been in_progress for more than 10 minutes
    const result = run(`UPDATE arena_battles SET status = 'expired' 
      WHERE status IN ('pending', 'accepted', 'in_progress') 
      AND datetime(COALESCE(started_at, created_at), '+10 minutes') < datetime('now')`);
    console.log('✅ Cleaned up stuck battles');
  } catch (err) {
    console.log('Cleanup note:', err.message);
  }
}

// Run cleanup every 5 minutes (startup cleanup happens in app.listen)
setInterval(cleanupStuckBattles, 5 * 60 * 1000);

// Get god powers info (public endpoint for info modal)
app.get('/api/arena/god-powers', authenticateToken, (req, res) => {
  try {
    res.json({ god_powers: GOD_POWERS });
  } catch (err) {
    res.status(500).json({ error: 'Failed to get god powers' });
  }
});

// ====================
// HEALTH CHECK
// ====================

app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'ok', 
    database: dbReady ? 'ready' : 'initializing' 
  });
});

// Start server
app.listen(PORT, () => {
  console.log(`\n🏛️  ODYSSEY TO OLYMPUS SERVER RUNNING 🏛️`);
  console.log(`\n📍 Server: http://localhost:${PORT}`);
  console.log(`\n✅ Phase 2: FATE WHEEL & BATTLES`);
  console.log(`   - Fate Wheel: 20 Archaic Age Fates`);
  console.log(`   - Battle Arena: God Powers System`);
  console.log(`   - My Contributions: Personal tracking`);
  console.log(`   - Red/Orange/Gold theme for fates\n`);
  
  // Run cleanup after server starts (database is ready)
  setTimeout(cleanupStuckBattles, 1000);
});
